// ── Version data：截止批次 = 下一版本开始批次的前一批次，区间不重合 ──
const MAJORS = {
  finance:    { code: 'FIN', name: 'Finance', nameZh: '金融学', school: 'School of Economics & Management', degree: '经济学学士', duration: 4 },
  chinese:    { code: 'CHS', name: 'Chinese Studies', nameZh: '中国研究', school: 'School of Humanities and Social Sciences', degree: '文学学士', duration: 3 },
  accounting: { code: 'ACC', name: 'Accounting', nameZh: '会计学', school: 'School of Economics & Management', degree: '管理学学士', duration: 4 }
};

/** 入学批次顺序：每年 02 → 04 → 09 */
const INTAKE_BATCH_TYPES = ['02', '04', '09'];

function parseIntakeBatch(code) {
  if (!code || code.length < 6) return null;
  return { year: parseInt(code.slice(0, 4), 10), type: code.slice(4) };
}

function formatIntakeBatch(year, type) {
  return `${year}${type}`;
}

/** 展示格式：201602 → 2016/02 */
function formatBatchDisplay(batchCode) {
  if (!batchCode) return '—';
  const p = parseIntakeBatch(String(batchCode).replace(/\//g, ''));
  if (!p) return batchCode;
  return `${p.year}/${p.type}`;
}

/** 输入归一化：2025/09 → 202509 */
function normalizeBatchCode(input) {
  if (!input) return '';
  return String(input).trim().replace(/\//g, '');
}

/** 前一个入学批次，如 202602 → 202509 */
function getPreviousIntakeBatch(batchCode) {
  const p = parseIntakeBatch(batchCode);
  if (!p) return '';
  const idx = INTAKE_BATCH_TYPES.indexOf(p.type);
  if (idx > 0) {
    return formatIntakeBatch(p.year, INTAKE_BATCH_TYPES[idx - 1]);
  }
  return formatIntakeBatch(p.year - 1, INTAKE_BATCH_TYPES[INTAKE_BATCH_TYPES.length - 1]);
}

/** 下一个入学批次，如 202509 → 202602 */
function getNextIntakeBatch(batchCode) {
  const p = parseIntakeBatch(batchCode);
  if (!p) return '';
  const idx = INTAKE_BATCH_TYPES.indexOf(p.type);
  if (idx >= 0 && idx < INTAKE_BATCH_TYPES.length - 1) {
    return formatIntakeBatch(p.year, INTAKE_BATCH_TYPES[idx + 1]);
  }
  return formatIntakeBatch(p.year + 1, INTAKE_BATCH_TYPES[0]);
}

/** 新版本保存时：上一版本截止批次 = 新版本开始批次的前一批次 */
function getPreviousVersionEndBatch(newStartBatch) {
  return getPreviousIntakeBatch(newStartBatch);
}

const VERSIONS = [
  { id: 1, majorKey: 'chinese', name: 'Course Structure of Chinese Studies (201602 Version)', version: '201602', startBatch: '201602', endBatch: '201809', duration: 3, degree: '文学学士', disabled: true, locked: true, status: 'approved' },
  { id: 2, majorKey: 'chinese', name: 'Course Structure of Chinese Studies (201902 Version)', version: '201902', startBatch: '201902', endBatch: '202204', duration: 3, degree: '文学学士', disabled: false, locked: false, status: 'approved' },
  { id: 3, majorKey: 'chinese', name: 'Course Structure of Chinese Studies (202209 Version)', version: '202209', startBatch: '202209', endBatch: '202404', duration: 3, degree: '文学学士', disabled: false, locked: false, status: 'approved' },
  { id: 4, majorKey: 'chinese', name: 'Course Structure of Chinese Studies (202409 Version)', version: '202409', startBatch: '202409', endBatch: '202504', duration: 3, degree: '文学学士', disabled: false, locked: false, status: 'approved' },
  { id: 5, majorKey: 'chinese', name: 'Course Structure of Chinese Studies (202509 Version)', version: '202509', startBatch: '202509', endBatch: '', duration: 3, degree: '文学学士', disabled: false, locked: false, status: 'approved' },

  { id: 10, majorKey: 'finance', name: 'Course Structure of Finance (201602 Version)', version: '201602', startBatch: '201602', endBatch: '201809', duration: 4, degree: '经济学学士', disabled: false, locked: false, status: 'approved' },
  { id: 11, majorKey: 'finance', name: 'Course Structure of Finance (201902 Version)', version: '201902', startBatch: '201902', endBatch: '202204', duration: 4, degree: '经济学学士', disabled: false, locked: false, status: 'approved' },
  { id: 12, majorKey: 'finance', name: 'Course Structure of Finance (202209 Version)', version: '202209', startBatch: '202209', endBatch: '202404', duration: 4, degree: '经济学学士', disabled: false, locked: false, status: 'approved' },
  { id: 13, majorKey: 'finance', name: 'Course Structure of Finance (202409 Version)', version: '202409', startBatch: '202409', endBatch: '', duration: 4, degree: '经济学学士', disabled: false, locked: false, status: 'approved' },
  { id: 14, majorKey: 'finance', name: 'Course Structure of Finance (202509 Version)', version: '202509', startBatch: '202509', endBatch: '', duration: 4, degree: '经济学学士', disabled: false, locked: false, status: 'pending' },

  { id: 20, majorKey: 'accounting', name: 'Course Structure of Accounting (201602 Version)', version: '201602', startBatch: '201602', endBatch: '201809', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'approved' },
  { id: 21, majorKey: 'accounting', name: 'Course Structure of Accounting (201902 Version)', version: '201902', startBatch: '201902', endBatch: '202204', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'approved' },
  { id: 22, majorKey: 'accounting', name: 'Course Structure of Accounting (202209 Version)', version: '202209', startBatch: '202209', endBatch: '202404', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'approved' },
  { id: 23, majorKey: 'accounting', name: 'Course Structure of Accounting (202409 Version)', version: '202409', startBatch: '202409', endBatch: '202504', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'approved' },
  { id: 24, majorKey: 'accounting', name: 'Course Structure of Accounting (202509 Version)', version: '202509', startBatch: '202509', endBatch: '', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'approved' },
  { id: 25, majorKey: 'accounting', name: 'Course Structure of Accounting (202602 Version)', version: '202602', startBatch: '202602', endBatch: '', duration: 4, degree: '管理学学士', disabled: false, locked: false, status: 'draft' }
];

/** 批次执行计划：关联已审批培养方案版本（versionId） */
const EXEC_PLANS = [
  { id: 1, planCode: 'EP-Finance-202502', majorKey: 'finance', intakeBatch: '202502', versionId: 13, status: 'published', isLocked: true, isOffering: true },
  { id: 3, planCode: 'EP-ChineseStudies-202409', majorKey: 'chinese', intakeBatch: '202409', versionId: 4, status: 'published', isLocked: true, isOffering: true },
  { id: 4, planCode: 'EP-ChineseStudies-202502', majorKey: 'chinese', intakeBatch: '202502', versionId: 4, status: 'published', isLocked: true, isOffering: true },
  { id: 5, planCode: 'EP-ChineseStudies-202509', majorKey: 'chinese', intakeBatch: '202509', versionId: 5, status: 'published', isLocked: true, isOffering: false },
  { id: 6, planCode: 'EP-Accounting-202509', majorKey: 'accounting', intakeBatch: '202509', versionId: 24, status: 'published', isLocked: true, isOffering: true },
  { id: 7, planCode: 'EP-Accounting-202602', majorKey: 'accounting', intakeBatch: '202602', versionId: 24, status: 'draft', isLocked: false, isOffering: false }
];

/** 各执行计划独立的分类树 / 课程 / 选修矩阵（由关联版本模板复制） */
const EXEC_CONTENT_STORE = {};
let currentExecPlan = null;
let selectedExecPlanIds = new Set();

/** 方案变更申请：审批通过后覆盖目标版本内容，不影响已生成执行计划 */
const CHANGE_APPLICATIONS = [
  {
    id: 'ca-fin-13-pending',
    versionId: 13,
    majorKey: 'finance',
    name: 'Course Structure of Finance (202409 Version)',
    version: '202409',
    startBatch: '202409',
    totalCredits: 125,
    status: 'pending',
    submitter: '张老师',
    submitTime: '2025-06-01 09:30',
    reviewTime: '',
    reviewComment: '',
    currentStageLevel: 1,
    stages: [
      { level: 1, role: 'Programme Office', status: 'pending' },
      { level: 2, role: 'Academic Affairs', status: 'waiting' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ca-acc-24-progress',
    versionId: 24,
    majorKey: 'accounting',
    name: 'Course Structure of Accounting (202509 Version)',
    version: '202509',
    startBatch: '202509',
    totalCredits: 128,
    status: 'pending',
    submitter: '王老师',
    submitTime: '2025-05-28 14:10',
    reviewTime: '',
    reviewComment: '',
    currentStageLevel: 2,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2025-05-28 16:00', comment: '结构完整' },
      { level: 2, role: 'Academic Affairs', status: 'pending' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ca-chs-5-history',
    versionId: 5,
    majorKey: 'chinese',
    name: 'Course Structure of Chinese Studies (202509 Version)',
    version: '202509',
    startBatch: '202509',
    totalCredits: 120,
    status: 'approved',
    submitter: '陈老师',
    submitTime: '2025-04-20 10:00',
    reviewTime: '2025-04-25 09:00',
    reviewComment: 'Approved',
    currentStageLevel: 3,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2025-04-20 15:00', comment: '' },
      { level: 2, role: 'Academic Affairs', status: 'approved', reviewer: '王处长', time: '2025-04-22 11:00', comment: 'OK' },
      { level: 3, role: 'Senate', status: 'approved', reviewer: 'Senate Sec', time: '2025-04-25 09:00', comment: 'Approved' }
    ]
  }
];
const CHANGE_CONTENT_STORE = {};
let currentChangeApplication = null;
let pendingSubmitChangeId = null;
let changeReviewActiveTab = 'pending';
let pendingChangeReviewId = null;
let selectedChangeReviewIds = new Set();
let batchChangeReviewIds = [];

let currentEditVersion = null;
let versionEditReadonly = false;
let versionEditReturnPage = 'version-list';
/** 各版本独立的分类树 / 课程 / 选修矩阵数据 */
const VERSION_CONTENT_STORE = {};

function isVersionEditReadonly() {
  return versionEditReadonly;
}

function applyVersionEditReadonly(readonly) {
  versionEditReadonly = readonly;
  const page = document.getElementById('page-version-edit');
  if (page) page.classList.toggle('version-readonly', readonly);
  const banner = document.getElementById('version-readonly-banner');
  if (banner) banner.style.display = readonly ? 'block' : 'none';
  const btnSave = document.getElementById('btn-save');
  const btnSubmit = document.getElementById('btn-submit');
  if (btnSave) btnSave.style.display = readonly ? 'none' : '';
  if (btnSubmit) btnSubmit.style.display = readonly ? 'none' : '';
}

function getVersionReadonlyStatusLabel(status) {
  const map = {
    approved: '已通过（只读）',
    pending: '进行中（只读）',
    draft: '草稿（只读）',
    rejected: '已驳回（只读）'
  };
  return map[status] || '只读';
}

function statusLabel(s) {
  return { draft: '草稿', pending: '进行中', approved: '已通过', rejected: '已驳回' }[s] || s;
}

function statusClass(s) {
  return {
    draft: 'draft-solid',
    pending: 'in-progress',
    approved: 'approved-solid',
    rejected: 'rejected'
  }[s] || 'draft-solid';
}

function getVersionsByMajor(majorKey) {
  return VERSIONS
    .filter(v => v.majorKey === majorKey)
    .sort((a, b) => a.startBatch.localeCompare(b.startBatch));
}

/** 按开始批次排序后，仅根据已审批通过的下一版回填截止批次 */
function syncVersionEndBatches(majorKey) {
  const list = getVersionsByMajor(majorKey);
  const approved = list.filter(v => v.status === 'approved');

  list.forEach(v => {
    if (v.status !== 'approved') v.endBatch = '';
  });

  approved.forEach((v, i) => {
    const nextApproved = approved[i + 1];
    v.endBatch = nextApproved
      ? getPreviousVersionEndBatch(nextApproved.startBatch)
      : '';
  });
}

function syncAllVersionEndBatches() {
  Object.keys(MAJORS).forEach(syncVersionEndBatches);
}

function isVersionChainValid(majorKey) {
  const approved = getVersionsByMajor(majorKey).filter(v => v.status === 'approved');
  for (let i = 0; i < approved.length - 1; i++) {
    const cur = approved[i];
    const next = approved[i + 1];
    const expectedEnd = getPreviousVersionEndBatch(next.startBatch);
    if (cur.endBatch !== expectedEnd) return false;
    if (cur.endBatch >= next.startBatch) return false;
    if (getNextIntakeBatch(cur.endBatch) !== next.startBatch) return false;
  }
  return true;
}

function versionCoversBatch(version, intakeBatch) {
  if (intakeBatch < version.startBatch) return false;
  if (version.endBatch && intakeBatch > version.endBatch) return false;
  return true;
}

function getCurrentVersion(majorKey) {
  const approved = getVersionsByMajor(majorKey).filter(v => v.status === 'approved');
  return approved.filter(v => !v.endBatch).sort((a, b) => b.startBatch.localeCompare(a.startBatch))[0]
    || approved[approved.length - 1]
    || null;
}

function isCurrentEffectiveVersion(v) {
  if (v.status !== 'approved' || v.endBatch) return false;
  const current = getCurrentVersion(v.majorKey);
  return current?.id === v.id;
}

function finalizeProgrammeVersionApproval(versionId) {
  const v = findVersionById(versionId);
  if (!v || v.status === 'approved') return;
  v.status = 'approved';
  syncVersionEndBatches(v.majorKey);
  filterVersions();
}

function matchVersionByIntake(majorKey, intakeBatch, { approvedOnly = false } = {}) {
  return getVersionsByMajor(majorKey).find(v => {
    if (approvedOnly && v.status !== 'approved') return false;
    return versionCoversBatch(v, intakeBatch);
  });
}

function resolveExecVersionMatch(majorKey, intakeBatch) {
  if (!intakeBatch) return { ok: false, reason: 'empty' };
  const matched = matchVersionByIntake(majorKey, intakeBatch);
  if (!matched) return { ok: false, reason: 'no-match' };
  if (matched.status !== 'approved') {
    return { ok: false, reason: 'not-approved', version: matched };
  }
  return { ok: true, version: matched };
}

function isVersionReferencableByExecPlan(v) {
  return v?.status === 'approved';
}

function formatVersionRange(v) {
  if (!v.endBatch) return `${formatBatchDisplay(v.startBatch)} ~ 至今`;
  return `${formatBatchDisplay(v.startBatch)} ~ ${formatBatchDisplay(v.endBatch)}`;
}

function getExecPlansByVersionId(versionId) {
  return EXEC_PLANS.filter(ep => ep.versionId === versionId);
}

function formatMajorBatchCode(majorKey, intakeBatch) {
  const major = MAJORS[majorKey];
  if (!major || !intakeBatch) return '—';
  return `${major.code}-${formatBatchDisplay(intakeBatch)}`;
}

function findExecPlanById(id) {
  return EXEC_PLANS.find(ep => ep.id === Number(id));
}

function renderExecLockStatus(isLocked) {
  return isLocked
    ? '<span class="exec-status exec-status-lock-yes">是</span>'
    : '<span class="exec-status exec-status-lock-no">否</span>';
}

function renderExecOfferingStatusLabel(isOffering) {
  return isOffering
    ? '<span class="exec-status exec-status-offering-yes">已开课</span>'
    : '<span class="exec-status exec-status-offering-no">未开课</span>';
}

function canEditExecPlan(ep) {
  return ep && !ep.isLocked && !ep.isOffering;
}

function canDeleteExecPlan(ep) {
  return ep && !ep.isLocked && !ep.isOffering;
}

function updateExecSelection() {
  selectedExecPlanIds = new Set(
    Array.from(document.querySelectorAll('.exec-row-check:checked')).map(el => Number(el.value))
  );
  const btnLock = document.getElementById('btn-exec-lock');
  const btnUnlock = document.getElementById('btn-exec-unlock');
  const btnDelete = document.getElementById('btn-exec-delete');
  const hasSelection = selectedExecPlanIds.size > 0;
  if (btnLock) btnLock.disabled = !hasSelection;
  if (btnUnlock) btnUnlock.disabled = !hasSelection;
  if (btnDelete) btnDelete.disabled = !hasSelection;
  const checkAll = document.getElementById('exec-check-all');
  const selectable = document.querySelectorAll('.exec-row-check');
  if (checkAll && selectable.length) {
    checkAll.checked = selectable.length > 0 && selectedExecPlanIds.size === selectable.length;
    checkAll.indeterminate = selectedExecPlanIds.size > 0 && selectedExecPlanIds.size < selectable.length;
  }
}

function toggleExecCheckAll(checked) {
  document.querySelectorAll('.exec-row-check').forEach(el => { el.checked = checked; });
  updateExecSelection();
}

function syncExecSelectionFromDom() {
  selectedExecPlanIds = new Set(
    Array.from(document.querySelectorAll('.exec-row-check:checked')).map(el => Number(el.value))
  );
}

function getSelectedExecPlans() {
  syncExecSelectionFromDom();
  return Array.from(selectedExecPlanIds).map(id => findExecPlanById(id)).filter(Boolean);
}

function showExecNotice(title, message) {
  const titleEl = document.getElementById('exec-notice-title');
  const msgEl = document.getElementById('exec-notice-msg');
  if (titleEl) titleEl.textContent = title;
  if (msgEl) msgEl.textContent = message;
  openModal('modal-exec-notice');
}

function requestLockSelectedExecPlans() {
  syncExecSelectionFromDom();
  const selected = getSelectedExecPlans();
  if (!selected.length) {
    alert('请至少勾选一条执行计划');
    return;
  }
  const lockable = selected.filter(ep => !ep.isLocked && !ep.isOffering);
  if (!lockable.length) {
    if (selected.some(ep => ep.isOffering)) {
      alert('所选执行计划已开课，无法提交。');
    } else {
      alert('所选执行计划均已提交，无需重复提交。');
    }
    return;
  }
  const msg = document.getElementById('exec-lock-msg');
  const hint = document.getElementById('exec-lock-hint');
  if (msg) {
    msg.innerHTML = `确定提交 <strong>${lockable.length}</strong> 条执行计划吗？`;
  }
  if (hint) {
    hint.textContent = lockable.map(ep => formatMajorBatchCode(ep.majorKey, ep.intakeBatch)).join('；')
      + '。提交后不可编辑，提交后方可进行开课。';
  }
  openModal('modal-exec-lock');
}

function cancelExecLockConfirm() {
  closeModal('modal-exec-lock');
}

function confirmLockSelectedExecPlans() {
  closeModal('modal-exec-lock');
  const selected = getSelectedExecPlans();
  let locked = 0;
  selected.forEach(ep => {
    if (ep.isLocked || ep.isOffering) return;
    ep.isLocked = true;
    locked += 1;
  });
  selectedExecPlanIds.clear();
  renderExecList();
  if (locked) {
    alert(`已提交 ${locked} 条执行计划。提交后方可进行开课。`);
  }
}

function requestUnlockSelectedExecPlans() {
  syncExecSelectionFromDom();
  const selected = getSelectedExecPlans();
  if (!selected.length) {
    showExecNotice('提示', '请至少勾选一条执行计划');
    return;
  }
  const offeringPlans = selected.filter(ep => ep.isOffering);
  if (offeringPlans.length) {
    const names = offeringPlans.map(ep => formatMajorBatchCode(ep.majorKey, ep.intakeBatch)).join('、');
    showExecNotice(
      '无法撤回',
      offeringPlans.length === selected.length
        ? '当前计划已开课，无法撤回，需先删除开课任务'
        : `所选计划中 ${names} 已开课，无法撤回，需先删除开课任务。请取消勾选已开课计划后再试。`
    );
    return;
  }
  const unlockable = selected.filter(ep => ep.isLocked);
  if (!unlockable.length) {
    alert('所选执行计划尚未提交，无需撤回。');
    return;
  }
  const msg = document.getElementById('exec-unlock-msg');
  const hint = document.getElementById('exec-unlock-hint');
  if (msg) {
    msg.innerHTML = `确定撤回 <strong>${unlockable.length}</strong> 条执行计划吗？`;
  }
  if (hint) {
    hint.textContent = unlockable.map(ep => formatMajorBatchCode(ep.majorKey, ep.intakeBatch)).join('；')
      + '。撤回后可重新编辑执行计划。';
  }
  openModal('modal-exec-unlock');
}

function cancelExecUnlockConfirm() {
  closeModal('modal-exec-unlock');
}

function confirmUnlockSelectedExecPlans() {
  closeModal('modal-exec-unlock');
  syncExecSelectionFromDom();
  const selected = getSelectedExecPlans();
  if (selected.some(ep => ep.isOffering)) {
    showExecNotice('无法撤回', '当前计划已开课，无法撤回，需先删除开课任务');
    return;
  }
  let unlocked = 0;
  selected.forEach(ep => {
    if (!ep.isLocked || ep.isOffering) return;
    ep.isLocked = false;
    unlocked += 1;
  });
  selectedExecPlanIds.clear();
  renderExecList();
  if (unlocked) {
    alert(`已撤回 ${unlocked} 条执行计划。`);
  }
}

function requestDeleteSelectedExecPlans() {
  syncExecSelectionFromDom();
  const selected = getSelectedExecPlans();
  if (!selected.length) {
    alert('请至少勾选一条执行计划');
    return;
  }
  const deletable = selected.filter(canDeleteExecPlan);
  if (!deletable.length) {
    if (selected.some(ep => ep.isOffering)) {
      showExecNotice('无法删除', '已开课的执行计划不可删除，需先删除开课任务。');
    } else if (selected.some(ep => ep.isLocked)) {
      alert('已提交的执行计划不可删除，请先撤回后再删除。');
    }
    return;
  }
  if (deletable.length < selected.length) {
    const blocked = selected.filter(ep => !canDeleteExecPlan(ep));
    const names = blocked.map(ep => formatMajorBatchCode(ep.majorKey, ep.intakeBatch)).join('、');
    showExecNotice(
      '部分计划不可删除',
      `${names} 已提交或已开课，无法删除。请取消勾选后再试，或仅删除未提交且未开课的计划。`
    );
    return;
  }
  const msg = document.getElementById('exec-delete-msg');
  const hint = document.getElementById('exec-delete-hint');
  if (msg) {
    msg.innerHTML = `确定删除 <strong>${deletable.length}</strong> 条执行计划吗？此操作不可撤销。`;
  }
  if (hint) {
    hint.textContent = deletable.map(ep => formatMajorBatchCode(ep.majorKey, ep.intakeBatch)).join('；')
      + '。仅未提交且未开课的执行计划可删除。';
  }
  openModal('modal-exec-delete');
}

function cancelExecDeleteConfirm() {
  closeModal('modal-exec-delete');
}

function confirmDeleteSelectedExecPlans() {
  closeModal('modal-exec-delete');
  syncExecSelectionFromDom();
  const selected = getSelectedExecPlans();
  const deletableIds = new Set(
    selected.filter(canDeleteExecPlan).map(ep => ep.id)
  );
  if (!deletableIds.size) return;

  for (let i = EXEC_PLANS.length - 1; i >= 0; i -= 1) {
    if (deletableIds.has(EXEC_PLANS[i].id)) {
      delete EXEC_CONTENT_STORE[EXEC_PLANS[i].id];
      EXEC_PLANS.splice(i, 1);
    }
  }
  if (currentExecPlan && deletableIds.has(currentExecPlan.id)) {
    currentExecPlan = null;
  }
  selectedExecPlanIds.clear();
  renderExecList();
  alert(`已删除 ${deletableIds.size} 条执行计划。`);
}

function renderExecPlanActions(ep) {
  const actions = [`<a href="#" onclick="goExecEdit(${ep.id}, false);return false">查看</a>`];
  if (canEditExecPlan(ep)) {
    actions.push(`<a href="#" onclick="goExecEdit(${ep.id}, true);return false">编辑</a>`);
  }
  return actions.join('');
}

function renderExecPlanRow(ep) {
  const major = MAJORS[ep.majorKey];
  return `<tr>
    <td class="col-check"><input type="checkbox" class="exec-row-check" value="${ep.id}" onchange="updateExecSelection()"></td>
    <td>${escapeHtml(major?.code || '—')}</td>
    <td>${escapeHtml(major?.name || '—')}</td>
    <td>${escapeHtml(formatMajorBatchCode(ep.majorKey, ep.intakeBatch))}</td>
    <td>${escapeHtml(major?.school || '—')}</td>
    <td>${formatBatchDisplay(ep.intakeBatch)}</td>
    <td>${renderExecOfferingStatusLabel(!!ep.isOffering)}</td>
    <td>${renderExecLockStatus(!!ep.isLocked)}</td>
    <td class="actions">${renderExecPlanActions(ep)}</td>
  </tr>`;
}

function renderExecList() {
  const tbody = document.getElementById('exec-list-tbody');
  if (!tbody) return;
  tbody.innerHTML = EXEC_PLANS.map(renderExecPlanRow).join('');
  selectedExecPlanIds.clear();
  const checkAll = document.getElementById('exec-check-all');
  if (checkAll) {
    checkAll.checked = false;
    checkAll.indeterminate = false;
  }
  updateExecSelection();
}

function renderVersionRefCell(v) {
  const count = isVersionReferencableByExecPlan(v) ? getExecPlansByVersionId(v.id).length : 0;
  const title = isVersionReferencableByExecPlan(v)
    ? ''
    : ' title="版本尚未审批通过，不可被批次执行计划引用"';
  return `<td class="col-ref"><a href="#" class="ref-count-link${count ? '' : ' ref-count-zero'}"${title} onclick="openVersionRefModal(${v.id});return false">${count}</a></td>`;
}

function openVersionRefModal(versionId) {
  const v = findVersionById(versionId);
  if (!v) return;
  const refs = getExecPlansByVersionId(versionId);
  const major = MAJORS[v.majorKey];
  const title = document.getElementById('version-ref-title');
  const summary = document.getElementById('version-ref-summary');
  const tbody = document.getElementById('version-ref-tbody');
  if (title) title.textContent = '版本引用情况';
  if (summary) {
    const refNote = isVersionReferencableByExecPlan(v)
      ? `共 ${refs.length} 个批次执行计划引用`
      : '该版本尚未审批通过，不可被批次执行计划引用';
    summary.textContent = `${major.name} ${major.nameZh} · 版本 ${formatBatchDisplay(v.version)} · ${refNote}`;
  }
  if (tbody) {
    if (!isVersionReferencableByExecPlan(v)) {
      tbody.innerHTML = `<tr><td colspan="4" class="matrix-empty">版本状态为「${statusLabel(v.status)}」，审批通过后方可被批次执行计划引用</td></tr>`;
    } else if (!refs.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="matrix-empty">暂无引用该版本的批次执行计划</td></tr>';
    } else {
      tbody.innerHTML = refs.map(ep => {
        const m = MAJORS[ep.majorKey];
        const st = ep.status === 'published' ? 'approved' : 'draft';
        const stLabel = ep.status === 'published' ? '已发布' : '草稿';
        return `<tr>
          <td><strong>${escapeHtml(ep.planCode)}</strong></td>
          <td>${escapeHtml(m.name)} ${escapeHtml(m.nameZh)}</td>
          <td><code>${formatBatchDisplay(ep.intakeBatch)}</code></td>
          <td><span class="status ${st}">${stLabel}</span></td>
        </tr>`;
      }).join('');
    }
  }
  openModal('modal-version-refs');
}

function canSubmitVersion(v) {
  return v && (v.status === 'draft' || v.status === 'rejected') && !v.disabled;
}

function renderVersionRow(v, { showActions = true, showCheckbox = false } = {}) {
  const major = MAJORS[v.majorKey];
  const canEdit = v.status === 'draft' || v.status === 'rejected';

  let actions = '';
  if (showActions) {
    if (canEdit && !v.disabled) {
      actions = `<a href="#" onclick="goEditVersion(${v.id});return false">编辑</a>
        <a href="#" onclick="requestSubmitVersion(${v.id});return false">提交</a>`;
    } else if (v.status === 'pending') {
      actions = `<a href="#" onclick="goPage('approval-list');return false">查看</a>`;
    } else {
      actions = `<a href="#" onclick="goEditVersion(${v.id}, true);return false">查看</a>`;
    }
    if (canEdit) actions += `<a href="#" class="danger" onclick="requestDeleteVersion(${v.id});return false">删除</a>`;
  } else {
    actions = `<a href="#" onclick="goEditVersion(${v.id}, true);return false">查看详情</a>`;
  }

  const checkCell = showCheckbox
    ? `<td class="col-check"><input type="checkbox" class="version-row-check" value="${v.id}" onchange="updateVersionSelection()"></td>`
    : '';

  return `<tr data-major="${v.majorKey}" data-version="${v.version}" class="${isCurrentEffectiveVersion(v) ? 'row-current' : ''}">
    ${checkCell}
    <td class="col-name"><a href="#" class="link-name" onclick="goEditVersion(${v.id}, ${!canEdit});return false">${v.name}</a></td>
    <td><span class="status ${statusClass(v.status)}">${statusLabel(v.status)}</span></td>
    <td><code>${major.code}</code></td>
    <td>${v.duration}</td>
    <td><code>${formatBatchDisplay(v.version)}</code></td>
    <td><code class="batch-code batch-start">${formatBatchDisplay(v.startBatch)}</code></td>
    <td>${v.endBatch ? `<code class="batch-code batch-end">${formatBatchDisplay(v.endBatch)}</code>` : '<span class="text-muted">—</span>'}</td>
    <td>${v.degree}</td>
    ${renderVersionRefCell(v)}
    <td class="actions">${actions}</td>
  </tr>`;
}

let pendingSubmitVersionId = null;
let pendingBatchSubmitVersionIds = [];
let pendingDeleteVersionId = null;
let selectedVersionIds = new Set();

function findVersionById(id) {
  return VERSIONS.find(v => v.id === id);
}

function runWithVersionContent(versionId, fn) {
  saveCurrentEditContent();
  const backup = {
    classificationTree: cloneJson(CLASSIFICATION_TREE),
    programCourses: cloneJson(PROGRAM_COURSES),
    electiveSemesterRequirements: cloneJson(ELECTIVE_SEMESTER_REQUIREMENTS)
  };
  loadVersionContent(versionId);
  const result = fn();
  applyVersionContent(backup);
  return result;
}

function canBatchSubmitSelectedVersions() {
  if (!selectedVersionIds.size) return false;
  return Array.from(selectedVersionIds).every(id => canSubmitVersion(findVersionById(id)));
}

function updateVersionSelection() {
  selectedVersionIds = new Set(
    Array.from(document.querySelectorAll('.version-row-check:checked')).map(el => Number(el.value))
  );
  const btn = document.getElementById('btn-batch-submit-version');
  if (btn) btn.disabled = !canBatchSubmitSelectedVersions();
  const checkAll = document.getElementById('version-check-all');
  const selectable = document.querySelectorAll('.version-row-check');
  if (checkAll && selectable.length) {
    checkAll.checked = selectable.length > 0 && selectedVersionIds.size === selectable.length;
    checkAll.indeterminate = selectedVersionIds.size > 0 && selectedVersionIds.size < selectable.length;
  }
}

function toggleVersionCheckAll(checked) {
  document.querySelectorAll('.version-row-check').forEach(el => { el.checked = checked; });
  updateVersionSelection();
}

function openBatchSubmitVersion() {
  if (!canBatchSubmitSelectedVersions()) {
    alert('所选版本中包含不可提交的记录（仅草稿或已驳回版本可提交审批）');
    return;
  }
  const ids = Array.from(selectedVersionIds);
  pendingBatchSubmitVersionIds = ids;
  const msg = document.getElementById('batch-submit-version-msg');
  const hint = document.getElementById('batch-submit-version-hint');
  if (msg) {
    msg.innerHTML = `确定提交 <strong>${ids.length}</strong> 个培养方案版本进行审批吗？`;
  }
  if (hint) {
    const names = ids.map(id => findVersionById(id)?.name).filter(Boolean);
    hint.textContent = names.join('；') + '。提交后将进入审批流程，待审批期间不可编辑。';
  }
  openModal('modal-batch-submit-version');
}

function cancelBatchSubmitVersion() {
  pendingBatchSubmitVersionIds = [];
  closeModal('modal-batch-submit-version');
}

function confirmBatchSubmitVersion() {
  const ids = [...pendingBatchSubmitVersionIds];
  pendingBatchSubmitVersionIds = [];
  closeModal('modal-batch-submit-version');
  if (!ids.length) return;

  const failed = [];
  let submitted = 0;
  ids.forEach(id => {
    const v = findVersionById(id);
    if (!canSubmitVersion(v)) return;
    const check = runWithVersionContent(id, () => validateCompulsoryMinCreditsForSubmit());
    if (!check.ok) {
      failed.push(`「${v.name}」：${check.message}`);
      return;
    }
    v.status = 'pending';
    submitted += 1;
  });

  selectedVersionIds.clear();
  filterVersions();

  if (failed.length && !submitted) {
    alert(`批量提交失败：\n${failed.join('\n\n')}`);
    return;
  }
  if (failed.length) {
    alert(`已提交 ${submitted} 个版本。\n以下版本未通过校验：\n${failed.join('\n\n')}`);
    return;
  }
  alert(`已提交 ${submitted} 个版本审批（原型）`);
}

function requestSubmitVersion(id) {
  const v = findVersionById(id);
  if (!v || (v.status !== 'draft' && v.status !== 'rejected') || v.disabled) return;
  pendingSubmitVersionId = id;
  const major = MAJORS[v.majorKey];
  const msg = document.getElementById('submit-version-msg');
  const hint = document.getElementById('submit-version-hint');
  if (msg) {
    msg.innerHTML = `确定提交培养方案「<strong>${escapeHtml(v.name)}</strong>」进行审批吗？`;
  }
  if (hint) {
    hint.textContent = `${major?.nameZh || ''} · 版本 ${formatBatchDisplay(v.version)} · 开始批次 ${formatBatchDisplay(v.startBatch)}。提交后将进入审批流程，待审批期间不可编辑。`;
  }
  openModal('modal-submit-version');
}

function cancelSubmitVersion() {
  pendingSubmitVersionId = null;
  closeModal('modal-submit-version');
}

function confirmSubmitVersion() {
  const v = findVersionById(pendingSubmitVersionId);
  if (!v) {
    pendingSubmitVersionId = null;
    closeModal('modal-submit-version');
    return;
  }
  const minCheck = runWithVersionContent(v.id, () => validateCompulsoryMinCreditsForSubmit());
  if (!minCheck.ok) {
    alert(minCheck.message);
    return;
  }
  pendingSubmitVersionId = null;
  closeModal('modal-submit-version');
  v.status = 'pending';
  filterVersions();
  alert('已提交审批（原型）');
}

function requestDeleteVersion(id) {
  const v = findVersionById(id);
  if (!v || (v.status !== 'draft' && v.status !== 'rejected')) return;
  pendingDeleteVersionId = id;
  const major = MAJORS[v.majorKey];
  const msg = document.getElementById('delete-version-msg');
  const hint = document.getElementById('delete-version-hint');
  if (msg) {
    msg.innerHTML = `确定删除培养方案「<strong>${escapeHtml(v.name)}</strong>」吗？此操作不可撤销。`;
  }
  if (hint) {
    hint.textContent = `${major?.nameZh || ''} · 版本 ${formatBatchDisplay(v.version)} · 开始批次 ${formatBatchDisplay(v.startBatch)}。`;
  }
  openModal('modal-delete-version');
}

function cancelDeleteVersion() {
  pendingDeleteVersionId = null;
  closeModal('modal-delete-version');
}

function confirmDeleteVersion() {
  const id = pendingDeleteVersionId;
  pendingDeleteVersionId = null;
  closeModal('modal-delete-version');
  const idx = VERSIONS.findIndex(v => v.id === id);
  if (idx >= 0) {
    VERSIONS.splice(idx, 1);
    delete VERSION_CONTENT_STORE[id];
    filterVersions();
  }
}

function filterVersions() {
  syncAllVersionEndBatches();
  const major = document.getElementById('filter-major')?.value || '';
  let list = [...VERSIONS].sort((a, b) => {
    if (a.majorKey !== b.majorKey) return a.majorKey.localeCompare(b.majorKey);
    return a.startBatch.localeCompare(b.startBatch);
  });
  if (major) list = list.filter(v => v.majorKey === major);

  const tbody = document.getElementById('version-table-body');
  if (tbody) {
    tbody.innerHTML = list.map(v => renderVersionRow(v, { showCheckbox: true })).join('');
    document.getElementById('version-count').textContent = list.length;
    selectedVersionIds.clear();
    const checkAll = document.getElementById('version-check-all');
    if (checkAll) {
      checkAll.checked = false;
      checkAll.indeterminate = false;
    }
    updateVersionSelection();
  }

  const queryBody = document.getElementById('version-query-body');
  if (queryBody) {
    queryBody.innerHTML = list.filter(v => v.status === 'approved').map(v => renderVersionRow(v, { showActions: false })).join('');
  }
}

// ── New version modal ──
function getMinimumNewStartBatch(majorKey) {
  const list = getVersionsByMajor(majorKey);
  if (!list.length) return null;
  const latest = list[list.length - 1];
  const anchorBatch = latest.endBatch || latest.startBatch;
  return getNextIntakeBatch(anchorBatch);
}

function isValidNewVersionStartBatch(majorKey, startBatch) {
  const min = getMinimumNewStartBatch(majorKey);
  if (!min) return true;
  return startBatch >= min;
}

/** 新增版本可选的开始批次（不早于当前有效版本的下一批次） */
function getAllowedNewStartBatches(majorKey, yearsAhead = 3) {
  const min = getMinimumNewStartBatch(majorKey);
  const startYear = min ? parseInt(min.slice(0, 4), 10) : new Date().getFullYear();
  const endYear = startYear + yearsAhead;
  const all = [];
  for (let y = startYear; y <= endYear; y++) {
    INTAKE_BATCH_TYPES.forEach(t => all.push(formatIntakeBatch(y, t)));
  }
  if (!min) return all;
  return all.filter(b => b >= min);
}

function rebuildStartBatchSelect(majorKey) {
  const sel = document.getElementById('new-start-batch');
  const hintEl = document.getElementById('min-batch-hint');
  if (!sel) return;

  const current = getCurrentVersion(majorKey);
  const min = getMinimumNewStartBatch(majorKey);
  const allowed = getAllowedNewStartBatches(majorKey);
  const latest = getVersionsByMajor(majorKey).slice(-1)[0];

  sel.innerHTML = allowed.map(b =>
    `<option value="${b}">${formatBatchDisplay(b)}</option>`
  ).join('');

  if (hintEl) {
    if (!latest) {
      hintEl.textContent = '暂无历史版本，可选择任意开始批次';
    } else if (latest.endBatch) {
      hintEl.textContent = `上一版本 ${formatBatchDisplay(latest.version)} 截止批次 ${formatBatchDisplay(latest.endBatch)}，新版本开始批次最早为 ${formatBatchDisplay(min)}`;
    } else {
      hintEl.textContent = `当前有效版本 ${formatBatchDisplay(current?.version || latest.version)}（${formatBatchDisplay(latest.startBatch)} 起），新版本开始批次最早为 ${formatBatchDisplay(min)}`;
    }
  }
}

function openNewVersionModal() {
  document.getElementById('new-major').value = '';
  document.getElementById('new-duration').value = '';
  document.getElementById('new-degree').value = '';
  document.getElementById('cascade-preview').style.display = 'none';
  document.getElementById('new-programme-name').value = '';
  document.getElementById('new-version-code').value = '';
  document.getElementById('min-batch-hint').textContent = '';
  const batchSel = document.getElementById('new-start-batch');
  if (batchSel) batchSel.innerHTML = '';
  openModal('modal-new-version');
}

function onNewMajorChange() {
  const majorKey = document.getElementById('new-major').value;
  const durationEl = document.getElementById('new-duration');
  const degreeEl = document.getElementById('new-degree');
  if (!majorKey) {
    document.getElementById('cascade-preview').style.display = 'none';
    document.getElementById('min-batch-hint').textContent = '';
    if (durationEl) durationEl.value = '';
    if (degreeEl) degreeEl.value = '';
    return;
  }
  const major = MAJORS[majorKey];
  if (durationEl) durationEl.value = major.duration;
  if (degreeEl) degreeEl.value = major.degree;
  rebuildStartBatchSelect(majorKey);
  onStartBatchChange();
}

function onStartBatchChange() {
  const majorKey = document.getElementById('new-major').value;
  if (!majorKey) return;

  const startBatch = document.getElementById('new-start-batch')?.value;
  if (!startBatch) return;

  const min = getMinimumNewStartBatch(majorKey);
  if (min && startBatch < min) {
    rebuildStartBatchSelect(majorKey);
    return;
  }

  const prevEndBatch = getPreviousVersionEndBatch(startBatch);
  const major = MAJORS[majorKey];
  const prev = getCurrentVersion(majorKey);

  document.getElementById('new-version-code').value = formatBatchDisplay(startBatch);
  document.getElementById('new-programme-name').value =
    `Course Structure of ${major.name} (${formatBatchDisplay(startBatch)} Version)`;

  document.getElementById('cascade-preview').style.display = 'block';
  document.getElementById('prev-version-label').textContent =
    prev ? `${formatBatchDisplay(prev.version)} (${prev.name.split('(')[1]?.replace(')', '') || ''})` : '（无上一版本）';
  document.getElementById('prev-end-batch').textContent = prev ? formatBatchDisplay(prevEndBatch) : '—';
  document.getElementById('curr-version-label').textContent = `${formatBatchDisplay(startBatch)} Version`;
  document.getElementById('curr-start-batch').textContent = formatBatchDisplay(startBatch);

  const hint = document.getElementById('batch-cascade-hint');
  if (hint) {
    hint.textContent = prevEndBatch
      ? `新版本审批通过后，上一版本截止批次将设为 ${formatBatchDisplay(prevEndBatch)}（当前保持不变）；${formatBatchDisplay(startBatch)} 起启用新版本`
      : '';
  }
}

function nextVersionId() {
  return VERSIONS.reduce((max, v) => Math.max(max, v.id), 0) + 1;
}

function confirmNewVersion() {
  const majorKey = document.getElementById('new-major').value;
  if (!majorKey) { alert('请选择专业'); return; }
  const startBatch = document.getElementById('new-start-batch')?.value;
  if (!startBatch) { alert('请选择开始批次'); return; }
  const min = getMinimumNewStartBatch(majorKey);
  const current = getCurrentVersion(majorKey);
  const latest = getVersionsByMajor(majorKey).slice(-1)[0];
  if (min && startBatch < min) {
    const prevEnd = latest?.endBatch ? formatBatchDisplay(latest.endBatch) : formatBatchDisplay(getPreviousVersionEndBatch(min));
    alert(`新版本开始批次须晚于上一版本截止批次。最早可选 ${formatBatchDisplay(min)}（上一版本截止 ${prevEnd}）`);
    return;
  }
  const major = MAJORS[majorKey];
  const prev = current;
  const newId = nextVersionId();
  const newVersion = {
    id: newId,
    majorKey,
    name: document.getElementById('new-programme-name').value,
    version: startBatch,
    startBatch,
    endBatch: '',
    duration: major.duration,
    degree: major.degree,
    disabled: false,
    locked: false,
    status: 'draft'
  };
  VERSIONS.push(newVersion);
  VERSION_CONTENT_STORE[newId] = getEmptyVersionContent();
  closeModal('modal-new-version');
  filterVersions();
  goEdit('draft', newVersion);
  const prevEnd = getPreviousVersionEndBatch(startBatch);
  alert(`已创建新版本 ${formatBatchDisplay(startBatch)}（待审批通过后生效）\n上一版本 ${prev ? formatBatchDisplay(prev.version) : '—'} 的截止批次将在新版本审批通过后设为 ${formatBatchDisplay(prevEnd)}（当前保持不变）`);
}

// ── Exec plan version match ──
function getExistingExecPlanBatchSet(majorKey) {
  return new Set(
    EXEC_PLANS.filter(ep => ep.majorKey === majorKey).map(ep => ep.intakeBatch)
  );
}

function getAvailableExecIntakeBatches(majorKey) {
  const existing = getExistingExecPlanBatchSet(majorKey);
  const approved = getVersionsByMajor(majorKey).filter(v => v.status === 'approved');
  if (!approved.length) return [];

  const minStart = approved[0].startBatch;
  const openVersion = approved.find(v => !v.endBatch);
  const startYear = parseInt(minStart.slice(0, 4), 10);
  const endYear = openVersion
    ? startYear + 6
    : parseInt((approved[approved.length - 1].endBatch || approved[approved.length - 1].startBatch).slice(0, 4), 10) + 1;

  const batches = [];
  for (let y = startYear; y <= endYear; y += 1) {
    INTAKE_BATCH_TYPES.forEach(t => {
      const batch = formatIntakeBatch(y, t);
      if (batch < minStart) return;
      if (existing.has(batch)) return;
      if (!resolveExecVersionMatch(majorKey, batch).ok) return;
      batches.push(batch);
    });
  }
  return batches.sort();
}

function initExecMajorSelect() {
  const sel = document.getElementById('exec-major');
  if (!sel) return;
  sel.innerHTML = Object.entries(MAJORS).map(([key, major]) =>
    `<option value="${key}">${escapeHtml(major.name)} ${escapeHtml(major.nameZh)}</option>`
  ).join('');
}

function rebuildExecIntakeBatchSelect(majorKey) {
  const sel = document.getElementById('exec-intake-batch');
  const hintEl = document.getElementById('exec-intake-batch-hint');
  if (!sel) return;

  const batches = getAvailableExecIntakeBatches(majorKey);
  if (!batches.length) {
    sel.innerHTML = '<option value="">暂无可选批次</option>';
    sel.disabled = true;
    if (hintEl) {
      hintEl.textContent = '该专业暂无可生成的入学批次（可能均已生成执行计划，或无可引用的已审批版本）';
    }
    return;
  }

  sel.disabled = false;
  sel.innerHTML = batches.map(batch =>
    `<option value="${batch}">${formatBatchDisplay(batch)}</option>`
  ).join('');
  if (hintEl) {
    hintEl.textContent = `共 ${batches.length} 个可选批次，均为尚未生成执行计划的入学批次`;
  }
}

function onExecMajorChange() {
  const majorKey = document.getElementById('exec-major')?.value || 'finance';
  rebuildExecIntakeBatchSelect(majorKey);
  onExecBatchInput();
}

function onExecBatchInput() {
  const majorKey = document.getElementById('exec-major')?.value || 'finance';
  const batch = normalizeBatchCode(document.getElementById('exec-intake-batch')?.value);
  const result = batch ? resolveExecVersionMatch(majorKey, batch) : { ok: false, reason: 'empty' };
  const el = document.getElementById('exec-matched-version');
  const range = document.getElementById('exec-match-range');
  const hint = document.getElementById('exec-match-hint');
  const statusEl = document.getElementById('exec-match-status');
  const box = document.getElementById('exec-version-match');
  const submitBtn = document.getElementById('btn-gen-exec-submit');
  if (!el) return;

  box?.classList.remove('is-error', 'is-ok');

  if (result.ok) {
    const matched = result.version;
    el.textContent = formatBatchDisplay(matched.version);
    if (range) range.textContent = `生效区间：${formatVersionRange(matched)}`;
    if (statusEl) {
      statusEl.className = 'status approved';
      statusEl.textContent = statusLabel('approved');
    }
    if (box) box.classList.add('is-ok');
    const nextStart = matched.endBatch ? getNextIntakeBatch(matched.endBatch) : null;
    if (hint) {
      hint.textContent = nextStart
        ? `入学批次 ${formatBatchDisplay(batch)} 匹配已审批版本 ${formatBatchDisplay(matched.version)}；下一版本从 ${formatBatchDisplay(nextStart)} 起`
        : `入学批次 ${formatBatchDisplay(batch)} 匹配已审批版本 ${formatBatchDisplay(matched.version)}（${formatVersionRange(matched)}）`;
    }
    if (submitBtn) submitBtn.disabled = false;
    return;
  }

  if (submitBtn) submitBtn.disabled = true;

  if (result.reason === 'not-approved') {
    const v = result.version;
    el.textContent = formatBatchDisplay(v.version);
    if (range) range.textContent = `生效区间：${formatVersionRange(v)}`;
    if (statusEl) {
      statusEl.className = `status ${statusClass(v.status)}`;
      statusEl.textContent = statusLabel(v.status);
    }
    if (box) box.classList.add('is-error');
    if (hint) {
      hint.textContent = `入学批次 ${formatBatchDisplay(batch)} 虽匹配版本 ${formatBatchDisplay(v.version)}，但该版本为「${statusLabel(v.status)}」，尚未审批通过，无法生成批次执行计划。`;
    }
    return;
  }

  el.textContent = '未匹配';
  if (range) range.textContent = '请检查入学批次是否在已审批版本的有效区间内';
  if (statusEl) {
    statusEl.className = 'status draft';
    statusEl.textContent = '—';
  }
  if (hint) {
    hint.textContent = batch
      ? `入学批次 ${formatBatchDisplay(batch)} 未落在任何已审批版本的生效区间内`
      : '请选择入学批次';
  }
}

function confirmGenerateExecPlan() {
  const majorKey = document.getElementById('exec-major')?.value || 'finance';
  const batch = normalizeBatchCode(document.getElementById('exec-intake-batch')?.value);
  const result = resolveExecVersionMatch(majorKey, batch);
  if (!result.ok) {
    if (result.reason === 'not-approved') {
      alert(`培养方案版本 ${formatBatchDisplay(result.version.version)} 尚未审批通过（${statusLabel(result.version.status)}），无法被批次执行计划引用。`);
    } else if (result.reason === 'no-match') {
      alert('未匹配到已审批通过的有效培养方案版本，请调整入学批次或等待版本审批完成。');
    } else {
      alert('请选择入学批次');
    }
    return;
  }
  closeModal('modal-gen-exec');
  let ep = EXEC_PLANS.find(p => p.majorKey === majorKey && p.intakeBatch === batch);
  if (!ep) {
    ep = {
      id: Date.now(),
      planCode: `EP-${majorKey}-${batch}`,
      majorKey,
      intakeBatch: batch,
      versionId: result.version.id,
      status: 'draft',
      isLocked: false,
      isOffering: false
    };
    EXEC_PLANS.push(ep);
    renderExecList();
  }
  goExecEdit(ep.id, true);
}

// ── Programme change applications (方案变更申请) ──
function nextChangeApplicationId() {
  return `ca-${Date.now()}`;
}

function findChangeApplication(id) {
  return CHANGE_APPLICATIONS.find(ca => ca.id === id);
}

function getChangeApplicationStatusLabel(status, readonly = false) {
  const map = {
    draft: readonly ? '查看模式' : '变更草稿',
    pending: '进行中',
    approved: '已通过',
    rejected: '已驳回'
  };
  return map[status] || status;
}

function changeApplicationStatusClass(status) {
  return status === 'approved' ? 'approved-solid'
    : status === 'rejected' ? 'rejected'
    : status === 'pending' ? 'in-progress'
    : 'draft';
}

function hasActiveChangeForVersion(versionId) {
  return CHANGE_APPLICATIONS.some(ca =>
    ca.versionId === versionId && (ca.status === 'draft' || ca.status === 'pending')
  );
}

function getApprovedVersionsForChangeApply(majorKey) {
  if (!majorKey) return [];
  return getVersionsByMajor(majorKey).filter(v => v.status === 'approved');
}

function openNewChangeApplyModal() {
  const majorSel = document.getElementById('change-apply-major');
  const versionSel = document.getElementById('change-apply-version');
  const hint = document.getElementById('change-apply-version-hint');
  const preview = document.getElementById('change-apply-preview');
  if (majorSel) majorSel.value = '';
  if (versionSel) {
    versionSel.innerHTML = '<option value="">请先选择专业</option>';
    versionSel.disabled = true;
  }
  if (hint) hint.textContent = '请先选择专业';
  if (preview) preview.style.display = 'none';
  openModal('modal-new-change-apply');
}

function onChangeApplyMajorChange() {
  rebuildChangeApplyVersionSelect();
  onChangeApplyVersionChange();
}

function rebuildChangeApplyVersionSelect() {
  const majorKey = document.getElementById('change-apply-major')?.value || '';
  const sel = document.getElementById('change-apply-version');
  const hint = document.getElementById('change-apply-version-hint');
  if (!sel) return;

  if (!majorKey) {
    sel.innerHTML = '<option value="">请先选择专业</option>';
    sel.disabled = true;
    if (hint) hint.textContent = '请先选择专业';
    return;
  }

  const versions = getApprovedVersionsForChangeApply(majorKey);
  if (!versions.length) {
    sel.innerHTML = '<option value="">暂无已审批版本</option>';
    sel.disabled = true;
    if (hint) hint.textContent = '该专业暂无已审批通过的培养方案版本';
    return;
  }

  sel.disabled = false;
  sel.innerHTML = versions.map(v => {
    const busy = hasActiveChangeForVersion(v.id);
    const execCount = getExecPlansByVersionId(v.id).length;
    const suffix = busy ? ' · 已有进行中变更' : (execCount ? ` · 已生成 ${execCount} 个执行计划` : ' · 尚无执行计划');
    return `<option value="${v.id}"${busy ? ' disabled' : ''}>${escapeHtml(v.name)}${escapeHtml(suffix)}</option>`;
  }).join('');
  if (hint) {
    hint.textContent = '仅可选择已审批通过的版本；已有草稿/进行中变更的版本不可重复申请';
  }
}

function onChangeApplyVersionChange() {
  const versionId = Number(document.getElementById('change-apply-version')?.value);
  const preview = document.getElementById('change-apply-preview');
  if (!versionId) {
    if (preview) preview.style.display = 'none';
    return;
  }
  const v = findVersionById(versionId);
  if (!v || !preview) return;

  const execPlans = getExecPlansByVersionId(v.id);
  const futureBatches = getAvailableExecIntakeBatches(v.majorKey).length;
  document.getElementById('change-preview-version-name').textContent = v.name;
  document.getElementById('change-preview-version-range').textContent = formatVersionRange(v);
  document.getElementById('change-preview-exec-count').textContent = execPlans.length
    ? `${execPlans.length} 个（${execPlans.map(ep => formatBatchDisplay(ep.intakeBatch)).join('、')}）`
    : '无';
  document.getElementById('change-preview-future-hint').textContent = futureBatches
    ? `尚有 ${futureBatches} 个入学批次未生成执行计划；变更审批通过后，这些批次生成时将引用最新版本内容。`
    : '当前专业暂无可新生成的入学批次。';
  preview.style.display = 'block';
}

function confirmNewChangeApply() {
  const majorKey = document.getElementById('change-apply-major')?.value;
  const versionId = Number(document.getElementById('change-apply-version')?.value);
  if (!majorKey) { alert('请选择专业'); return; }
  if (!versionId) { alert('请选择目标培养方案版本'); return; }
  const v = findVersionById(versionId);
  if (!v || v.status !== 'approved') {
    alert('只能选择已审批通过的培养方案版本');
    return;
  }
  if (hasActiveChangeForVersion(versionId)) {
    alert('该版本已有进行中的变更申请，请完成或撤回后再新建');
    return;
  }

  const change = {
    id: nextChangeApplicationId(),
    versionId: v.id,
    majorKey: v.majorKey,
    name: v.name,
    version: v.version,
    startBatch: v.startBatch,
    totalCredits: 130,
    status: 'draft',
    submitter: '当前用户',
    submitTime: '',
    reviewTime: '',
    reviewComment: ''
  };
  CHANGE_APPLICATIONS.unshift(change);
  CHANGE_CONTENT_STORE[change.id] = cloneJson(getVersionContentSnapshot(v.id));
  closeModal('modal-new-change-apply');
  renderChangeApplyList();
  goChangeEdit(change.id);
}

function renderChangeApplyList() {
  const tbody = document.getElementById('change-apply-list-body');
  const empty = document.getElementById('change-apply-list-empty');
  if (!tbody) return;

  const majorFilter = document.getElementById('change-apply-filter-major')?.value || '';
  const statusFilter = document.getElementById('change-apply-filter-status')?.value || '';
  const items = CHANGE_APPLICATIONS.filter(ca => {
    if (majorFilter && ca.majorKey !== majorFilter) return false;
    if (statusFilter && ca.status !== statusFilter) return false;
    return true;
  });

  if (!items.length) {
    tbody.innerHTML = '';
    if (empty) empty.style.display = 'block';
    return;
  }
  if (empty) empty.style.display = 'none';

  tbody.innerHTML = items.map(ca => {
    const major = MAJORS[ca.majorKey];
    const actions = [];
    if (ca.status === 'draft' || ca.status === 'rejected') {
      actions.push(`<a href="#" onclick="goChangeEdit('${ca.id}');return false">编辑</a>`);
    } else {
      actions.push(`<a href="#" onclick="goChangeEdit('${ca.id}', true);return false">查看</a>`);
    }
    if (ca.status === 'draft') {
      actions.push(`<a href="#" onclick="requestSubmitChangeApplication('${ca.id}');return false">提交审批</a>`);
    }
    if (ca.status === 'draft' || ca.status === 'rejected') {
      actions.push(`<a href="#" onclick="deleteChangeApplication('${ca.id}');return false">删除</a>`);
    }
    return `<tr>
      <td><a href="#" class="link-name" onclick="goChangeEdit('${ca.id}', ${ca.status !== 'draft' && ca.status !== 'rejected'});return false">${escapeHtml(ca.name)}</a></td>
      <td>${escapeHtml(major?.name || '—')}</td>
      <td><code>${formatBatchDisplay(ca.version)}</code></td>
      <td><span class="status ${changeApplicationStatusClass(ca.status)}">${getChangeApplicationStatusLabel(ca.status)}</span></td>
      <td>${escapeHtml(ca.submitter || '—')}</td>
      <td>${escapeHtml(ca.submitTime || '—')}</td>
      <td class="actions">${actions.join('')}</td>
    </tr>`;
  }).join('');
}

function createChangeApprovalStages() {
  return [
    { level: 1, role: 'Programme Office', status: 'pending' },
    { level: 2, role: 'Academic Affairs', status: 'waiting' },
    { level: 3, role: 'Senate', status: 'waiting' }
  ];
}

function initChangeApprovalWorkflow(ca) {
  ca.currentStageLevel = 1;
  ca.stages = createChangeApprovalStages();
  ca.status = 'pending';
  ca.reviewTime = '';
  ca.reviewComment = '';
}

function getChangeReviewQueueItems() {
  return CHANGE_APPLICATIONS.filter(ca => ca.status !== 'draft');
}

function resolveChangeReviewBucket(ca) {
  if (ca.status === 'approved' || ca.status === 'rejected') return 'history';
  if (!ca.stages?.length) return 'pending';

  if (ca.stages.some(s => s.status === 'rejected' || s.status === 'update_required')) return 'history';
  if (ca.stages.every(s => s.status === 'approved')) return 'history';

  const current = ca.stages.find(s => s.level === ca.currentStageLevel);
  if (current?.status === 'pending') return 'pending';
  return 'in-progress';
}

function getChangeReviewTabs() {
  return [
    { id: 'pending', label: 'Pending' },
    { id: 'in-progress', label: 'In Progress' },
    { id: 'history', label: 'History' }
  ];
}

function getChangeReviewOverallStatus(ca) {
  if (ca.status === 'approved') return { label: 'Approved', cls: 'approved-solid' };
  if (ca.status === 'rejected') {
    const updateRequired = ca.stages?.some(s => s.status === 'update_required');
    return updateRequired
      ? { label: 'Update Required', cls: 'pending' }
      : { label: 'Rejected', cls: 'rejected' };
  }
  if (ca.stages?.some(s => s.status === 'update_required')) {
    return { label: 'Update Required', cls: 'pending' };
  }
  return { label: 'In-Progress', cls: 'in-progress' };
}

function getChangeReviewStageDisplay(ca) {
  if (ca.status === 'approved') {
    const last = ca.stages?.[ca.stages.length - 1];
    return last?.role || 'Approved';
  }
  if (ca.status === 'rejected') {
    const updateRequired = ca.stages?.find(s => s.status === 'update_required');
    if (updateRequired) return updateRequired.role;
    const rejected = ca.stages?.find(s => s.status === 'rejected');
    return rejected?.role || 'Rejected';
  }
  const current = ca.stages?.find(s => s.level === ca.currentStageLevel);
  return current?.role || '—';
}

function canReviewChangeItem(ca, tab) {
  return tab === 'pending' && resolveChangeReviewBucket(ca) === 'pending';
}

function renderChangeReviewTabs() {
  const bar = document.getElementById('change-review-tab-bar');
  if (!bar) return;
  const tabs = getChangeReviewTabs();
  if (!tabs.some(t => t.id === changeReviewActiveTab)) changeReviewActiveTab = tabs[0].id;

  const counts = {};
  tabs.forEach(t => { counts[t.id] = 0; });
  getChangeReviewQueueItems().forEach(ca => {
    const bucket = resolveChangeReviewBucket(ca);
    if (counts[bucket] != null) counts[bucket] += 1;
  });

  bar.innerHTML = tabs.map(t => {
    const badge = t.id === 'pending' && counts[t.id] > 0
      ? `<span class="approval-tab-badge">${counts[t.id]}</span>`
      : '';
    return `<button type="button" class="approval-tab${t.id === changeReviewActiveTab ? ' active' : ''}" data-change-review-tab="${t.id}" onclick="setChangeReviewTab('${t.id}')">${t.label}${badge}</button>`;
  }).join('');
}

function setChangeReviewTab(tabId) {
  changeReviewActiveTab = tabId;
  renderChangeReviewList();
}

function updateChangeReviewSelection() {
  const checks = Array.from(document.querySelectorAll('.change-review-row-check:not(:disabled)'));
  selectedChangeReviewIds = new Set(
    checks.filter(c => c.checked).map(c => c.value)
  );
  const checkAll = document.getElementById('change-review-check-all');
  const reviewableCount = checks.length;
  const selectedCount = selectedChangeReviewIds.size;
  if (checkAll) {
    checkAll.indeterminate = selectedCount > 0 && selectedCount < reviewableCount;
    checkAll.checked = reviewableCount > 0 && selectedCount === reviewableCount;
  }
  const btn = document.getElementById('btn-batch-change-review');
  const hint = document.getElementById('change-review-selection-hint');
  if (btn) btn.disabled = selectedCount === 0;
  if (hint) {
    hint.textContent = selectedCount
      ? `已选 ${selectedCount} 项，可批量 Review`
      : 'Pending 页勾选待办后可批量 Review';
  }
}

function toggleChangeReviewCheckAll(checked) {
  document.querySelectorAll('.change-review-row-check:not(:disabled)').forEach(el => {
    el.checked = checked;
  });
  updateChangeReviewSelection();
}

function openBatchChangeReview() {
  const ids = Array.from(selectedChangeReviewIds);
  if (!ids.length) {
    alert('请至少勾选一条待审批记录');
    return;
  }
  batchChangeReviewIds = ids.filter(id => {
    const ca = findChangeApplication(id);
    return ca && canReviewChangeItem(ca, changeReviewActiveTab);
  });
  if (!batchChangeReviewIds.length) {
    alert('所选记录当前不可审批');
    return;
  }
  const summary = document.getElementById('batch-change-review-summary');
  const list = document.getElementById('batch-change-review-list');
  const comment = document.getElementById('batch-change-review-comment');
  if (summary) {
    summary.textContent = `共 ${batchChangeReviewIds.length} 项待审批`;
  }
  if (list) {
    list.innerHTML = batchChangeReviewIds.map(id => {
      const ca = findChangeApplication(id);
      if (!ca) return '';
      const major = MAJORS[ca.majorKey];
      return `<li><strong>${escapeHtml(ca.name)}</strong><div class="item-meta">${escapeHtml(major?.name || '—')} · ${formatBatchDisplay(ca.version)} · ${escapeHtml(ca.submitter)}</div></li>`;
    }).join('');
  }
  if (comment) comment.value = '';
  openModal('modal-batch-change-review');
}

function renderChangeReviewActions(ca, tab) {
  const parts = [
    `<a href="#" onclick="openChangeReviewView('${ca.id}');return false">View</a>`
  ];
  if (canReviewChangeItem(ca, tab)) {
    parts.push(`<a href="#" onclick="openChangeReviewModal('${ca.id}');return false">Review</a>`);
  }
  parts.push(`<a href="#" onclick="openChangeReviewLog('${ca.id}');return false">Approval Log</a>`);
  return parts.join('');
}

function renderChangeReviewList() {
  renderChangeReviewTabs();
  const tbody = document.getElementById('change-review-list-body');
  const empty = document.getElementById('change-review-list-empty');
  const toolbar = document.getElementById('change-review-list-toolbar');
  const table = document.querySelector('.change-review-table');
  const showBatch = changeReviewActiveTab === 'pending';
  if (toolbar) toolbar.style.display = showBatch ? 'flex' : 'none';
  if (table) table.classList.toggle('batch-mode', showBatch);
  selectedChangeReviewIds = new Set();
  if (!tbody) return;

  const items = getChangeReviewQueueItems().filter(ca =>
    resolveChangeReviewBucket(ca) === changeReviewActiveTab
  );
  if (!items.length) {
    tbody.innerHTML = '';
    if (empty) empty.style.display = 'block';
    updateChangeReviewSelection();
    return;
  }
  if (empty) empty.style.display = 'none';

  tbody.innerHTML = items.map(ca => {
    const major = MAJORS[ca.majorKey];
    const st = getChangeReviewOverallStatus(ca);
    const canReview = canReviewChangeItem(ca, changeReviewActiveTab);
    const checkCell = showBatch && canReview
      ? `<td class="col-check"><input type="checkbox" class="change-review-row-check" value="${ca.id}" onchange="updateChangeReviewSelection()"></td>`
      : '<td class="col-check"></td>';
    return `<tr>
      ${checkCell}
      <td><a href="#" class="link-name" onclick="openChangeReviewView('${ca.id}');return false">${escapeHtml(ca.name)}</a></td>
      <td><span class="status ${st.cls}">${st.label}</span></td>
      <td>${escapeHtml(getChangeReviewStageDisplay(ca))}</td>
      <td>${escapeHtml(major?.name || '—')}</td>
      <td><code>${formatBatchDisplay(ca.version)}</code></td>
      <td><code>${formatBatchDisplay(ca.startBatch || ca.version)}</code></td>
      <td>${ca.totalCredits || '—'}</td>
      <td>${escapeHtml(ca.submitter || '—')}</td>
      <td>${escapeHtml(ca.submitTime || '—')}</td>
      <td class="actions">${renderChangeReviewActions(ca, changeReviewActiveTab)}</td>
    </tr>`;
  }).join('');
  updateChangeReviewSelection();
}

function goChangeEdit(changeId, readonly = false, returnPage = 'change-apply') {
  const ca = findChangeApplication(changeId);
  if (!ca) return;
  const v = findVersionById(ca.versionId);
  if (!v) return;

  saveCurrentEditContent();
  currentExecPlan = null;
  currentChangeApplication = ca;
  currentEditVersion = v;
  versionEditReturnPage = returnPage;
  goPage('version-edit');

  const isReadonly = readonly || ca.status === 'pending' || ca.status === 'approved';
  applyVersionEditReadonly(isReadonly);
  applyEditPageChrome('change');

  const statusEl = document.getElementById('edit-status');
  if (statusEl) {
    statusEl.className = 'status ' + changeApplicationStatusClass(ca.status);
    statusEl.textContent = getChangeApplicationStatusLabel(ca.status, isReadonly);
  }
  document.getElementById('edit-title').textContent =
    `变更 · ${MAJORS[v.majorKey].name} (${formatBatchDisplay(v.version)})`;
  renderChangeInfoStrip(v, ca);
  updateVersionEditBreadcrumb();
  loadChangeContent(changeId);
  activateVersionEditTab('tab-classification');
  updateVersionEditTabStates();
}

function renderChangeInfoStrip(v, ca) {
  const strip = document.getElementById('edit-info-strip');
  if (!strip || !v) return;
  const major = MAJORS[v.majorKey];
  const execCount = getExecPlansByVersionId(v.id).length;
  strip.innerHTML = `
    <span><label>变更目标</label><strong>${escapeHtml(v.name)}</strong></span>
    <span><label>专业</label>${escapeHtml(major.name)} ${escapeHtml(major.nameZh)}</span>
    <span><label>版本</label><strong>${formatBatchDisplay(v.version)}</strong></span>
    <span><label>生效区间</label>${formatVersionRange(v)}</span>
    <span><label>已生成执行计划</label>${execCount ? `${execCount} 个（不受影响）` : '无'}</span>
    <span><label>申请状态</label>${escapeHtml(getChangeApplicationStatusLabel(ca.status))}</span>`;
}

function loadChangeContent(changeId) {
  let content = CHANGE_CONTENT_STORE[changeId];
  const ca = findChangeApplication(changeId);
  if (!content && ca) {
    content = cloneJson(getVersionContentSnapshot(ca.versionId));
    CHANGE_CONTENT_STORE[changeId] = cloneJson(content);
  }
  applyVersionContent(content || getEmptyVersionContent());
}

function deleteChangeApplication(id) {
  const ca = findChangeApplication(id);
  if (!ca) return;
  if (ca.status !== 'draft' && ca.status !== 'rejected') {
    alert('仅草稿或已驳回状态的申请可删除');
    return;
  }
  if (!confirm(`确定删除变更申请「${ca.name}」吗？`)) return;
  const idx = CHANGE_APPLICATIONS.findIndex(x => x.id === id);
  if (idx >= 0) CHANGE_APPLICATIONS.splice(idx, 1);
  delete CHANGE_CONTENT_STORE[id];
  if (currentChangeApplication?.id === id) currentChangeApplication = null;
  renderChangeApplyList();
  renderChangeReviewList();
}

function requestSubmitChangeApplication(id) {
  const ca = id ? findChangeApplication(id) : currentChangeApplication;
  if (!ca || (ca.status !== 'draft' && ca.status !== 'rejected')) return;

  if (currentChangeApplication?.id === ca.id) {
    saveCurrentEditContent();
    const result = validateCompulsoryMinCreditsForSubmit();
    if (!result.ok) {
      alert(result.message);
      return;
    }
  }

  pendingSubmitChangeId = ca.id;
  const msg = document.getElementById('submit-change-msg');
  const hint = document.getElementById('submit-change-hint');
  const major = MAJORS[ca.majorKey];
  if (msg) {
    msg.innerHTML = `确定提交方案变更「<strong>${escapeHtml(ca.name)}</strong>」进行审批吗？`;
  }
  if (hint) {
    const execCount = getExecPlansByVersionId(ca.versionId).length;
    hint.textContent = `${major?.nameZh || ''} · 版本 ${formatBatchDisplay(ca.version)}。审批通过后将覆盖原版本内容；${execCount ? `已有 ${execCount} 个执行计划不受影响` : '尚无执行计划'}；未生成执行计划的批次生成时将引用最新内容。`;
  }
  openModal('modal-submit-change');
}

function cancelSubmitChange() {
  pendingSubmitChangeId = null;
  closeModal('modal-submit-change');
}

function confirmSubmitChange() {
  const ca = findChangeApplication(pendingSubmitChangeId);
  pendingSubmitChangeId = null;
  closeModal('modal-submit-change');
  if (!ca) return;

  if (currentChangeApplication?.id === ca.id) {
    const result = validateCompulsoryMinCreditsForSubmit();
    if (!result.ok) {
      alert(result.message);
      return;
    }
    saveCurrentEditContent();
  }

  ca.status = 'pending';
  ca.submitTime = new Date().toISOString().slice(0, 16).replace('T', ' ');
  initChangeApprovalWorkflow(ca);
  renderChangeApplyList();
  renderChangeReviewList();

  if (currentChangeApplication?.id === ca.id) {
    applyVersionEditReadonly(true);
    const statusEl = document.getElementById('edit-status');
    if (statusEl) {
      statusEl.className = 'status ' + changeApplicationStatusClass('pending');
      statusEl.textContent = getChangeApplicationStatusLabel('pending');
    }
  }
  alert('变更申请已提交审核（原型）');
}

function buildChangeReviewStageInfoHtml(ca) {
  const current = ca.stages?.find(s => s.level === ca.currentStageLevel);
  const nodeLabel = current?.role || getChangeReviewStageDisplay(ca);
  return `
    <div class="approval-stage-field">
      <label>当前审批节点</label>
      <span>${escapeHtml(nodeLabel)}</span>
    </div>`;
}

function openChangeReviewView(id) {
  goChangeEdit(id, true, 'change-review');
}

function openChangeReviewModal(id) {
  const ca = findChangeApplication(id);
  if (!ca) return;
  if (!canReviewChangeItem(ca, changeReviewActiveTab)) {
    alert('当前记录不可审批，请使用「查看」或切换至 Pending 页。');
    return;
  }
  pendingChangeReviewId = id;
  const title = document.getElementById('change-review-title');
  const stageInfo = document.getElementById('change-review-stage-info');
  const comment = document.getElementById('change-review-comment');
  if (title) title.textContent = `Review — ${ca.name}`;
  if (stageInfo) stageInfo.innerHTML = buildChangeReviewStageInfoHtml(ca);
  if (comment) comment.value = '';
  openModal('modal-change-review');
}

function cancelChangeReview() {
  pendingChangeReviewId = null;
  closeModal('modal-change-review');
}

function getChangeReviewDecisionMessage(decision) {
  return {
    approved: 'Approved（原型）',
    rejected: 'Rejected（原型）',
    update_required: 'Update Required — 变更已退回修改（原型）'
  }[decision] || decision;
}

function applyChangeDecisionToItem(ca, decision, comment) {
  if (!ca.stages?.length) return false;
  const level = ca.currentStageLevel;
  const myStage = ca.stages.find(s => s.level === level);
  if (!myStage) return false;
  myStage.status = decision;
  myStage.reviewer = myStage.role || 'Reviewer';
  myStage.time = new Date().toISOString().slice(0, 16).replace('T', ' ');
  myStage.comment = comment || '';

  if (decision === 'approved') {
    const next = ca.stages.find(s => s.level === level + 1);
    if (next) {
      ca.currentStageLevel = next.level;
      next.status = 'pending';
    } else {
      ca.currentStageLevel = level;
      if (ca.stages.every(s => s.status === 'approved')) {
        finalizeChangeApplicationApproval(ca.id);
      }
    }
  } else if (decision === 'update_required' || decision === 'rejected') {
    ca.status = 'rejected';
    ca.reviewTime = myStage.time;
    ca.reviewComment = comment;
    if (decision === 'update_required') {
      ca.stages.forEach(stage => {
        if (stage.level > level) {
          stage.status = 'waiting';
          delete stage.reviewer;
          delete stage.time;
          delete stage.comment;
        }
      });
    }
  }
  return true;
}

function submitChangeReviewDecision(decision) {
  const ca = findChangeApplication(pendingChangeReviewId);
  if (!ca) return;
  applyChangeDecisionToItem(
    ca,
    decision,
    document.getElementById('change-review-comment')?.value.trim() || ''
  );
  pendingChangeReviewId = null;
  closeModal('modal-change-review');
  renderChangeApplyList();
  renderChangeReviewList();
  alert(getChangeReviewDecisionMessage(decision));
}

function submitBatchChangeReviewDecision(decision) {
  if (!batchChangeReviewIds.length) return;
  const comment = document.getElementById('batch-change-review-comment')?.value.trim() || '';
  let count = 0;
  batchChangeReviewIds.forEach(id => {
    const ca = findChangeApplication(id);
    if (ca && applyChangeDecisionToItem(ca, decision, comment)) count += 1;
  });
  batchChangeReviewIds = [];
  selectedChangeReviewIds = new Set();
  closeModal('modal-batch-change-review');
  renderChangeApplyList();
  renderChangeReviewList();
  alert(decision === 'approved'
    ? `已批量通过 ${count} 项（原型）`
    : `已批量驳回 ${count} 项（原型）`);
}

function openChangeReviewLog(id) {
  const ca = findChangeApplication(id);
  if (!ca) return;
  const title = document.getElementById('change-review-log-title');
  const body = document.getElementById('change-review-log-body');
  if (title) title.textContent = `Approval Log — ${ca.name}`;
  if (!body) return;

  const submitRow = `
    <div class="approval-log-item done">
      <div class="approval-log-dot"></div>
      <div>
        <div class="approval-log-head"><strong>Submitted</strong><span class="status draft">Submitted</span></div>
        <div class="approval-log-meta">${escapeHtml(ca.submitter)} · ${escapeHtml(ca.submitTime)}</div>
      </div>
    </div>`;

  const stageRows = (ca.stages || []).map(stage => {
    const st = renderApprovalLogStageStatus(stage);
    const itemCls = stage.status === 'approved' ? 'done'
      : stage.status === 'rejected' || stage.status === 'update_required' ? 'rejected'
      : stage.status === 'pending' ? 'current'
      : '';
    return `
      <div class="approval-log-item ${itemCls}">
        <div class="approval-log-dot"></div>
        <div>
          <div class="approval-log-head">
            <strong>${escapeHtml(stage.role)}</strong>
            <span class="status ${st.cls}">${st.label}</span>
          </div>
          <div class="approval-log-meta">${stage.reviewer ? escapeHtml(stage.reviewer) : '—'}${stage.time ? ` · ${escapeHtml(stage.time)}` : ''}</div>
          ${stage.comment ? `<div class="approval-log-comment">${escapeHtml(stage.comment)}</div>` : ''}
        </div>
      </div>`;
  }).join('');

  body.innerHTML = submitRow + stageRows;
  openModal('modal-change-review-log');
}

function finalizeChangeApplicationApproval(changeId) {
  const ca = findChangeApplication(changeId);
  if (!ca) return;
  const content = CHANGE_CONTENT_STORE[changeId] || getVersionContentSnapshot(ca.versionId);
  VERSION_CONTENT_STORE[ca.versionId] = cloneJson(content);
  ca.status = 'approved';
}

// ── Approval queue (版本审批 · Pending / In Progress / History) ──
const APPROVAL_ROLES = {
  1: { level: 1, name: 'Programme Office', label: '一级审批 · Programme Office' },
  2: { level: 2, name: 'Academic Affairs', label: '二级审批 · Academic Affairs' },
  3: { level: 3, name: 'Senate', label: '三级审批 · Senate' }
};

let approvalActiveTab = 'pending';
let pendingApprovalItemId = null;
let selectedApprovalIds = new Set();
let batchApprovalReviewIds = [];

const APPROVAL_QUEUE = [
  {
    id: 'ap-fin-2509',
    versionId: 14,
    majorKey: 'finance',
    name: 'Course Structure of Finance (202509 Version)',
    major: 'Finance',
    version: '202509',
    startBatch: '202509',
    totalCredits: 130,
    submitter: '张老师',
    submitTime: '2025-05-28 10:15',
    cancelled: false,
    currentStageLevel: 2,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2025-05-28 14:20', comment: '分类结构完整' },
      { level: 2, role: 'Academic Affairs', status: 'pending' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ap-acc-2504',
    versionId: 23,
    majorKey: 'accounting',
    name: 'Course Structure of Accounting (202504 Version)',
    major: 'Accounting',
    version: '202504',
    startBatch: '202504',
    totalCredits: 128,
    submitter: '王老师',
    submitTime: '2025-04-12 09:40',
    cancelled: false,
    currentStageLevel: 2,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2025-04-12 16:00', comment: 'OK' },
      { level: 2, role: 'Academic Affairs', status: 'pending' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ap-chs-2509',
    versionId: 5,
    majorKey: 'chinese',
    name: 'Course Structure of Chinese Studies (202509 Version)',
    major: 'Chinese Studies',
    version: '202509',
    startBatch: '202509',
    totalCredits: 120,
    submitter: '陈老师',
    submitTime: '2025-05-30 11:05',
    cancelled: false,
    currentStageLevel: 1,
    stages: [
      { level: 1, role: 'Programme Office', status: 'pending' },
      { level: 2, role: 'Academic Affairs', status: 'waiting' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ap-fin-2502',
    versionId: 13,
    majorKey: 'finance',
    name: 'Course Structure of Finance (202502 Version)',
    major: 'Finance',
    version: '202502',
    startBatch: '202502',
    totalCredits: 125,
    submitter: '张老师',
    submitTime: '2025-02-18 08:50',
    cancelled: false,
    currentStageLevel: 1,
    stages: [
      { level: 1, role: 'Programme Office', status: 'pending' },
      { level: 2, role: 'Academic Affairs', status: 'waiting' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ap-acc-2502',
    versionId: 23,
    majorKey: 'accounting',
    name: 'Course Structure of Accounting (202502 Version)',
    major: 'Accounting',
    version: '202502',
    startBatch: '202502',
    totalCredits: 126,
    submitter: '赵老师',
    submitTime: '2025-02-10 15:22',
    cancelled: false,
    currentStageLevel: 2,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2025-02-11 10:00', comment: 'Submitted' },
      { level: 2, role: 'Academic Affairs', status: 'pending' },
      { level: 3, role: 'Senate', status: 'waiting' }
    ]
  },
  {
    id: 'ap-fin-2409',
    versionId: 13,
    majorKey: 'finance',
    name: 'Course Structure of Finance (202409 Version)',
    major: 'Finance',
    version: '202409',
    startBatch: '202409',
    totalCredits: 130,
    submitter: '张老师',
    submitTime: '2024-08-20 09:00',
    cancelled: false,
    currentStageLevel: 3,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2024-08-21 11:00', comment: 'OK' },
      { level: 2, role: 'Academic Affairs', status: 'approved', reviewer: '王处长', time: '2024-08-25 16:30', comment: 'Approved' },
      { level: 3, role: 'Senate', status: 'approved', reviewer: 'Senate Sec', time: '2024-09-01 09:00', comment: 'Final approval' }
    ]
  },
  {
    id: 'ap-chs-2404',
    versionId: 4,
    majorKey: 'chinese',
    name: 'Course Structure of Chinese Studies (202404 Version)',
    major: 'Chinese Studies',
    version: '202404',
    startBatch: '202404',
    totalCredits: 118,
    submitter: '陈老师',
    submitTime: '2024-03-15 13:40',
    cancelled: false,
    currentStageLevel: 3,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2024-03-16 10:00', comment: '' },
      { level: 2, role: 'Academic Affairs', status: 'approved', reviewer: '王处长', time: '2024-03-18 14:00', comment: 'Approved' },
      { level: 3, role: 'Senate', status: 'rejected', reviewer: 'Senate Sec', time: '2024-03-22 11:20', comment: 'Elective credits mismatch' }
    ]
  },
  {
    id: 'ap-acc-2409',
    versionId: 23,
    majorKey: 'accounting',
    name: 'Course Structure of Accounting (202409 Version)',
    major: 'Accounting',
    version: '202409',
    startBatch: '202409',
    totalCredits: 128,
    submitter: '王老师',
    submitTime: '2024-07-08 10:30',
    cancelled: true,
    currentStageLevel: 2,
    stages: [
      { level: 1, role: 'Programme Office', status: 'approved', reviewer: '李主任', time: '2024-07-09 09:00', comment: '' },
      { level: 2, role: 'Academic Affairs', status: 'cancelled', reviewer: '—', time: '2024-07-10 08:00', comment: 'Applicant withdrew' }
    ]
  }
];

function findApprovalItem(id) {
  return APPROVAL_QUEUE.find(item => item.id === id);
}

function resolveApprovalVersionId(item) {
  if (!item) return null;
  if (item.versionId) return item.versionId;
  const majorKey = item.majorKey
    || Object.entries(MAJORS).find(([, m]) => m.name === item.major)?.[0];
  if (!majorKey) return null;
  return VERSIONS.find(v => v.majorKey === majorKey && v.version === item.version)?.id ?? null;
}

function updateVersionEditBreadcrumb() {
  const crumb = document.getElementById('version-edit-breadcrumb');
  if (!crumb) return;
  const labels = {
    'approval-list': '培养方案版本审批',
    'exec-list': '批次执行计划',
    'change-apply': '方案变更申请',
    'change-review': '方案变更审核'
  };
  crumb.textContent = labels[versionEditReturnPage] || '方案版本管理';
}

function applyEditPageChrome(mode = 'version') {
  const execBanner = document.getElementById('exec-edit-banner');
  const changeBanner = document.getElementById('change-edit-banner');
  const btnSubmit = document.getElementById('btn-submit');
  if (execBanner) execBanner.style.display = mode === 'exec' ? 'block' : 'none';
  if (changeBanner) changeBanner.style.display = mode === 'change' ? 'block' : 'none';
  if (btnSubmit) {
    if (mode === 'exec') {
      btnSubmit.style.display = 'none';
    } else if (mode === 'change') {
      btnSubmit.textContent = '提交变更审批';
      btnSubmit.style.display = '';
    } else {
      btnSubmit.textContent = '提交审批';
      btnSubmit.style.display = '';
    }
  }
}

function restoreVersionInfoStrip(v) {
  const strip = document.getElementById('edit-info-strip');
  if (!strip || !v) return;
  const major = MAJORS[v.majorKey];
  strip.innerHTML = `
    <span><label>专业</label><span id="info-major">${escapeHtml(major.name)} ${escapeHtml(major.nameZh)}</span></span>
    <span><label>版本</label><strong id="info-version">${formatBatchDisplay(v.version)}</strong></span>
    <span><label>开始批次</label><code id="info-start-batch">${formatBatchDisplay(v.startBatch)}</code></span>
    <span><label>截止批次</label><code id="info-end-batch" class="${v.endBatch ? '' : 'text-muted'}">${v.endBatch ? formatBatchDisplay(v.endBatch) : '—（当前有效版本）'}</code></span>
    <span><label>学制</label>${v.duration} 年</span>
    <span><label>授予学位</label>${escapeHtml(v.degree)}</span>
    <span><label>毕业总学分</label><strong class="text-blue">130</strong></span>`;
}

function renderExecInfoStrip(ep, version) {
  const strip = document.getElementById('edit-info-strip');
  if (!strip) return;
  const major = MAJORS[ep.majorKey];
  strip.innerHTML = `
    <span><label>专业</label>${escapeHtml(major.name)} ${escapeHtml(major.nameZh)}</span>
    <span><label>专业代码</label>${escapeHtml(major.code)}</span>
    <span><label>专业批次</label>${escapeHtml(formatMajorBatchCode(ep.majorKey, ep.intakeBatch))}</span>
    <span><label>入学批次</label>${formatBatchDisplay(ep.intakeBatch)}</span>
    <span><label>关联版本</label>${version ? formatBatchDisplay(version.version) : '—'} <span class="lock-icon" title="按批次自动匹配，不可切换">🔒</span></span>
    <span><label>是否提交</label>${renderExecLockStatus(!!ep.isLocked)}</span>
    <span><label>开课状态</label>${ep.isOffering ? '已开课' : '未开课'}</span>`;
}

function goVersionEditReturn() {
  saveCurrentEditContent();
  currentExecPlan = null;
  currentChangeApplication = null;
  goPage(versionEditReturnPage || 'version-list');
}

function resolveApprovalBucket(item) {
  if (item.cancelled) return 'history';
  if (item.stages.some(s => s.status === 'rejected' || s.status === 'update_required')) return 'history';
  if (item.stages.every(s => s.status === 'approved')) return 'history';

  const current = item.stages.find(s => s.level === item.currentStageLevel);
  if (current?.status === 'pending') return 'pending';
  return 'in-progress';
}

function getApprovalTabs() {
  return [
    { id: 'pending', label: 'Pending' },
    { id: 'in-progress', label: 'In Progress' },
    { id: 'history', label: 'History' }
  ];
}

function getApprovalOverallStatus(item) {
  if (item.cancelled) return { label: 'Cancelled', cls: 'draft' };
  const last = item.stages[item.stages.length - 1];
  if (last?.status === 'approved' && item.currentStageLevel >= last.level) {
    return { label: 'Approved', cls: 'approved' };
  }
  if (item.stages.some(s => s.status === 'update_required')) {
    return { label: 'Update Required', cls: 'pending' };
  }
  if (item.stages.some(s => s.status === 'rejected')) {
    return { label: 'Rejected', cls: 'rejected' };
  }
  return { label: 'In Progress', cls: 'in-progress' };
}

function getApprovalStageDisplay(item) {
  if (item.cancelled) {
    return item.stages.find(s => s.level === item.currentStageLevel)?.role || 'Cancelled';
  }
  const updateRequired = item.stages.find(s => s.status === 'update_required');
  if (updateRequired) return updateRequired.role;
  const rejected = item.stages.find(s => s.status === 'rejected');
  if (rejected) return rejected.role;
  const current = item.stages.find(s => s.level === item.currentStageLevel);
  return current?.role || '—';
}

function canReviewApprovalItem(item, tab) {
  return tab === 'pending' && resolveApprovalBucket(item) === 'pending';
}

function renderApprovalTabs() {
  const bar = document.getElementById('approval-tab-bar');
  if (!bar) return;
  const tabs = getApprovalTabs();
  if (!tabs.some(t => t.id === approvalActiveTab)) approvalActiveTab = tabs[0].id;

  const counts = {};
  tabs.forEach(t => { counts[t.id] = 0; });
  APPROVAL_QUEUE.forEach(item => {
    const bucket = resolveApprovalBucket(item);
    if (counts[bucket] != null) counts[bucket] += 1;
  });

  bar.innerHTML = tabs.map(t => {
    const badge = t.id === 'pending' && counts[t.id] > 0
      ? `<span class="approval-tab-badge">${counts[t.id]}</span>`
      : '';
    return `<button type="button" class="approval-tab${t.id === approvalActiveTab ? ' active' : ''}" data-approval-tab="${t.id}" onclick="setApprovalTab('${t.id}')">${t.label}${badge}</button>`;
  }).join('');
}

function getReviewableApprovalItems(tab = approvalActiveTab) {
  return APPROVAL_QUEUE.filter(item =>
    resolveApprovalBucket(item) === tab &&
    canReviewApprovalItem(item, tab)
  );
}

function updateApprovalSelection() {
  const checks = Array.from(document.querySelectorAll('.approval-row-check:not(:disabled)'));
  selectedApprovalIds = new Set(
    checks.filter(c => c.checked).map(c => c.value)
  );
  const checkAll = document.getElementById('approval-check-all');
  const reviewableCount = checks.length;
  const selectedCount = selectedApprovalIds.size;
  if (checkAll) {
    checkAll.indeterminate = selectedCount > 0 && selectedCount < reviewableCount;
    checkAll.checked = reviewableCount > 0 && selectedCount === reviewableCount;
  }
  const btn = document.getElementById('btn-batch-approval-review');
  const hint = document.getElementById('approval-selection-hint');
  if (btn) btn.disabled = selectedCount === 0;
  if (hint) {
    hint.textContent = selectedCount
      ? `已选 ${selectedCount} 项，可批量 Review`
      : 'Pending 页勾选待办后可批量 Review';
  }
}

function toggleApprovalCheckAll(checked) {
  document.querySelectorAll('.approval-row-check:not(:disabled)').forEach(el => {
    el.checked = checked;
  });
  updateApprovalSelection();
}

function openBatchApprovalReview() {
  const ids = Array.from(selectedApprovalIds);
  if (!ids.length) {
    alert('请至少勾选一条待审批记录');
    return;
  }
  batchApprovalReviewIds = ids.filter(id => {
    const item = findApprovalItem(id);
    return item && canReviewApprovalItem(item, approvalActiveTab);
  });
  if (!batchApprovalReviewIds.length) {
    alert('所选记录当前不可审批');
    return;
  }
  const summary = document.getElementById('batch-approval-review-summary');
  const list = document.getElementById('batch-approval-review-list');
  const comment = document.getElementById('batch-approval-review-comment');
  if (summary) {
    summary.textContent = `共 ${batchApprovalReviewIds.length} 项待审批`;
  }
  if (list) {
    list.innerHTML = batchApprovalReviewIds.map(id => {
      const item = findApprovalItem(id);
      if (!item) return '';
      return `<li><strong>${escapeHtml(item.name)}</strong><div class="item-meta">${escapeHtml(item.major)} · ${formatBatchDisplay(item.version)} · ${escapeHtml(item.submitter)}</div></li>`;
    }).join('');
  }
  if (comment) comment.value = '';
  openModal('modal-batch-approval-review');
}

function applyApprovalDecisionToItem(item, decision, comment) {
  const level = item.currentStageLevel;
  const myStage = item.stages.find(s => s.level === level);
  if (!myStage) return false;
  myStage.status = decision;
  myStage.reviewer = myStage.role || 'Reviewer';
  myStage.time = new Date().toISOString().slice(0, 16).replace('T', ' ');
  myStage.comment = comment || '';

  if (decision === 'approved') {
    const next = item.stages.find(s => s.level === level + 1);
    if (next) {
      item.currentStageLevel = next.level;
      next.status = 'pending';
    } else {
      item.currentStageLevel = level;
    }
    if (item.versionId && item.stages.every(s => s.status === 'approved')) {
      finalizeProgrammeVersionApproval(item.versionId);
    }
  } else if (decision === 'update_required' || decision === 'rejected') {
    if (item.versionId) {
      const v = findVersionById(item.versionId);
      if (v) v.status = 'rejected';
    }
    if (decision === 'update_required') {
      item.stages.forEach(stage => {
        if (stage.level > level) {
          stage.status = 'waiting';
          delete stage.reviewer;
          delete stage.time;
          delete stage.comment;
        }
      });
    }
  }
  return true;
}

function submitBatchApprovalDecision(decision) {
  if (!batchApprovalReviewIds.length) return;
  const comment = document.getElementById('batch-approval-review-comment')?.value.trim() || '';
  let count = 0;
  batchApprovalReviewIds.forEach(id => {
    const item = findApprovalItem(id);
    if (item && applyApprovalDecisionToItem(item, decision, comment)) count += 1;
  });
  batchApprovalReviewIds = [];
  selectedApprovalIds = new Set();
  closeModal('modal-batch-approval-review');
  renderApprovalList();
  alert(decision === 'approved'
    ? `已批量通过 ${count} 项（原型）`
    : `已批量驳回 ${count} 项（原型）`);
}

function setApprovalTab(tabId) {
  approvalActiveTab = tabId;
  renderApprovalList();
}

function renderApprovalActions(item, tab) {
  const parts = [
    `<a href="#" onclick="openApprovalView('${item.id}');return false">View</a>`
  ];
  if (canReviewApprovalItem(item, tab)) {
    parts.push(`<a href="#" onclick="openApprovalReview('${item.id}');return false">Review</a>`);
  }
  parts.push(`<a href="#" onclick="openApprovalLog('${item.id}');return false">Approval Log</a>`);
  return parts.join('');
}

function renderApprovalList() {
  renderApprovalTabs();
  const tbody = document.getElementById('approval-list-body');
  const empty = document.getElementById('approval-list-empty');
  const toolbar = document.getElementById('approval-list-toolbar');
  const table = document.querySelector('.approval-table');
  const showBatch = approvalActiveTab === 'pending';
  if (toolbar) toolbar.style.display = showBatch ? 'flex' : 'none';
  if (table) table.classList.toggle('batch-mode', showBatch);
  selectedApprovalIds = new Set();
  if (!tbody) return;

  const items = APPROVAL_QUEUE.filter(item => resolveApprovalBucket(item) === approvalActiveTab);
  if (!items.length) {
    tbody.innerHTML = '';
    if (empty) empty.style.display = 'block';
    updateApprovalSelection();
    return;
  }
  if (empty) empty.style.display = 'none';

  tbody.innerHTML = items.map(item => {
    const st = getApprovalOverallStatus(item);
    const canReview = canReviewApprovalItem(item, approvalActiveTab);
    const checkCell = showBatch && canReview
      ? `<td class="col-check"><input type="checkbox" class="approval-row-check" value="${item.id}" onchange="updateApprovalSelection()"></td>`
      : '<td class="col-check"></td>';
    return `<tr>
      ${checkCell}
      <td><a href="#" class="link-name" onclick="openApprovalView('${item.id}');return false">${escapeHtml(item.name)}</a></td>
      <td><span class="status ${st.cls}">${st.label}</span></td>
      <td>${escapeHtml(getApprovalStageDisplay(item))}</td>
      <td>${escapeHtml(item.major)}</td>
      <td><code>${formatBatchDisplay(item.startBatch)}</code></td>
      <td>${item.totalCredits}</td>
      <td>${escapeHtml(item.submitter)}</td>
      <td>${escapeHtml(item.submitTime)}</td>
      <td class="actions">${renderApprovalActions(item, approvalActiveTab)}</td>
    </tr>`;
  }).join('');
  updateApprovalSelection();
}

function buildApprovalStageInfoHtml(item) {
  const current = item.stages.find(s => s.level === item.currentStageLevel);
  const nodeLabel = current?.role || getApprovalStageDisplay(item);
  return `
    <div class="approval-stage-field">
      <label>当前审批节点</label>
      <span>${escapeHtml(nodeLabel)}</span>
    </div>`;
}

function openApprovalView(id) {
  const item = findApprovalItem(id);
  if (!item) return;
  const versionId = resolveApprovalVersionId(item);
  if (!versionId) {
    alert('未找到关联的培养方案版本');
    return;
  }
  goEditVersion(versionId, true, 'approval-list');
}

function openApprovalReview(id) {
  const item = findApprovalItem(id);
  if (!item) return;
  if (!canReviewApprovalItem(item, approvalActiveTab)) {
    alert('当前记录不可审批，请使用「查看」或切换至 Pending 页。');
    return;
  }
  pendingApprovalItemId = id;
  const title = document.getElementById('approval-review-title');
  const stageInfo = document.getElementById('approval-review-stage-info');
  const comment = document.getElementById('approval-review-comment');
  if (title) title.textContent = `Review — ${item.name}`;
  if (stageInfo) stageInfo.innerHTML = buildApprovalStageInfoHtml(item);
  if (comment) comment.value = '';
  openModal('modal-approval-review');
}

function getApprovalDecisionMessage(decision) {
  return {
    approved: 'Approved（原型）',
    rejected: 'Rejected（原型）',
    update_required: 'Update Required — 方案已退回修改（原型）'
  }[decision] || decision;
}

function submitApprovalDecision(decision) {
  const item = findApprovalItem(pendingApprovalItemId);
  if (!item) return;
  applyApprovalDecisionToItem(item, decision, document.getElementById('approval-review-comment')?.value.trim() || '');
  pendingApprovalItemId = null;
  closeModal('modal-approval-review');
  renderApprovalList();
  filterVersions();
  alert(getApprovalDecisionMessage(decision));
}

function renderApprovalLogStageStatus(stage) {
  const map = {
    approved: { label: 'Approved', cls: 'approved' },
    rejected: { label: 'Rejected', cls: 'rejected' },
    update_required: { label: 'Update Required', cls: 'pending' },
    pending: { label: 'Pending', cls: 'pending' },
    waiting: { label: 'Waiting', cls: 'draft' },
    cancelled: { label: 'Cancelled', cls: 'draft' }
  };
  return map[stage.status] || { label: stage.status, cls: 'draft' };
}

function openApprovalLog(id) {
  const item = findApprovalItem(id);
  if (!item) return;
  const title = document.getElementById('approval-log-title');
  const body = document.getElementById('approval-log-body');
  if (title) title.textContent = `Approval Log — ${item.name}`;
  if (!body) return;

  const submitRow = `
    <div class="approval-log-item done">
      <div class="approval-log-dot"></div>
      <div>
        <div class="approval-log-head"><strong>Submitted</strong><span class="status draft">Submitted</span></div>
        <div class="approval-log-meta">${escapeHtml(item.submitter)} · ${escapeHtml(item.submitTime)}</div>
      </div>
    </div>`;

  const stageRows = item.stages.map(stage => {
    const st = renderApprovalLogStageStatus(stage);
    const itemCls = stage.status === 'approved' ? 'done'
      : stage.status === 'rejected' ? 'rejected'
      : stage.status === 'update_required' ? 'update-required'
      : stage.status === 'cancelled' ? 'cancelled'
      : stage.status === 'pending' ? 'pending' : '';
    const meta = stage.time
      ? `${escapeHtml(stage.reviewer || stage.role)} · ${escapeHtml(stage.time)}`
      : escapeHtml(stage.role);
    const comment = stage.comment
      ? `<div class="approval-log-comment">${escapeHtml(stage.comment)}</div>`
      : '';
    return `
      <div class="approval-log-item ${itemCls}">
        <div class="approval-log-dot"></div>
        <div>
          <div class="approval-log-head"><strong>${escapeHtml(stage.role)}</strong><span class="status ${st.cls}">${st.label}</span></div>
          <div class="approval-log-meta">${meta}</div>
          ${comment}
        </div>
      </div>`;
  }).join('');

  body.innerHTML = submitRow + stageRows;
  openModal('modal-approval-log');
}

// ── Page navigation ──
function goPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + id)?.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === id);
  });
  if (id === 'version-list' || id === 'version-query') filterVersions();
  if (id === 'approval-list') renderApprovalList();
  if (id === 'exec-list') renderExecList();
  if (id === 'change-apply') renderChangeApplyList();
  if (id === 'change-review') renderChangeReviewList();
  if (id === 'stats-alignment') renderStatsAlignmentPage();
  if (id === 'stats-bloom') renderStatsBloomPage();
  if (id === 'workflow') renderWorkflowPage();
}

const WORKFLOW_ZOOM = { scale: 1, min: 0.5, max: 1.8, step: 0.1 };

function applyWorkflowZoom() {
  const stage = document.getElementById('workflow-zoom-stage');
  const mount = document.getElementById('workflow-doc-mount');
  const label = document.getElementById('workflow-zoom-label');
  if (!stage || !mount) return;
  const z = WORKFLOW_ZOOM.scale;
  stage.style.transform = `scale(${z})`;
  stage.style.width = z < 1 ? `${100 / z}%` : '100%';
  const baseH = mount.offsetHeight;
  stage.style.minHeight = baseH ? `${baseH * z}px` : '';
  if (label) label.textContent = `${Math.round(z * 100)}%`;
}

function workflowZoomStep(delta) {
  WORKFLOW_ZOOM.scale = Math.min(
    WORKFLOW_ZOOM.max,
    Math.max(WORKFLOW_ZOOM.min, +(WORKFLOW_ZOOM.scale + delta).toFixed(2))
  );
  applyWorkflowZoom();
}

function workflowZoomReset() {
  WORKFLOW_ZOOM.scale = 1;
  applyWorkflowZoom();
}

async function renderWorkflowPage() {
  const mount = document.getElementById('workflow-doc-mount');
  if (!mount) return;
  try {
    const res = await fetch('docs/pyfa-workflow.html', { cache: 'no-store' });
    if (!res.ok) throw new Error('fetch failed');
    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const sheet = doc.querySelector('.sheet');
    if (!sheet) throw new Error('no sheet');
    mount.replaceChildren(...sheet.children);
    requestAnimationFrame(() => {
      workflowZoomReset();
      applyWorkflowZoom();
    });
  } catch {
    mount.innerHTML = '<p class="workflow-loading">无法加载流程图，请使用 <code>npm start</code> 启动本地服务后刷新页面。</p>';
    workflowZoomReset();
  }
}

(function initWorkflowZoom() {
  const viewport = document.getElementById('workflow-viewport');
  if (!viewport) return;
  viewport.addEventListener('wheel', e => {
    if (!document.getElementById('page-workflow')?.classList.contains('active')) return;
    if (!e.ctrlKey && !e.metaKey) return;
    e.preventDefault();
    workflowZoomStep(e.deltaY > 0 ? -WORKFLOW_ZOOM.step : WORKFLOW_ZOOM.step);
  }, { passive: false });
})();

function goEditVersion(id, readonly, returnPage = 'version-list') {
  const v = VERSIONS.find(x => x.id === id);
  if (!v) return;
  versionEditReturnPage = returnPage;
  goEdit(readonly ? 'locked' : 'draft', v);
}

function goEdit(mode, versionData) {
  saveCurrentEditContent();
  currentExecPlan = null;
  currentChangeApplication = null;
  goPage('version-edit');
  const v = versionData || currentEditVersion || VERSIONS.find(x => x.version === '202509' && x.majorKey === 'finance');
  currentEditVersion = v;
  const readonly = mode === 'locked' || v.status === 'approved' || v.status === 'pending';
  applyVersionEditReadonly(readonly);
  applyEditPageChrome('version');

  const statusEl = document.getElementById('edit-status');
  if (statusEl) {
    statusEl.className = 'status ' + statusClass(v.status);
    statusEl.textContent = readonly ? getVersionReadonlyStatusLabel(v.status) : statusLabel(v.status);
  }
  document.getElementById('edit-title').textContent = `${MAJORS[v.majorKey].name} (${formatBatchDisplay(v.version)} Version)`;
  restoreVersionInfoStrip(v);
  updateVersionEditBreadcrumb();
  loadVersionContent(v.id);
  activateVersionEditTab('tab-classification');
  updateVersionEditTabStates();
}

function goExecEdit(execPlanId, editable = true) {
  const ep = findExecPlanById(execPlanId);
  if (!ep) return;
  if (editable && ep.isOffering) {
    alert('该执行计划已开课，不允许编辑');
    return;
  }
  if (editable && ep.isLocked) {
    alert('该执行计划已提交，不允许编辑');
    return;
  }
  saveCurrentEditContent();
  currentExecPlan = ep;
  currentChangeApplication = null;
  currentEditVersion = findVersionById(ep.versionId);
  versionEditReturnPage = 'exec-list';
  goPage('version-edit');

  const readonly = !editable;
  applyVersionEditReadonly(readonly);
  applyEditPageChrome('exec');

  const major = MAJORS[ep.majorKey];
  const version = currentEditVersion;
  document.getElementById('edit-title').textContent =
    `${major.name} · ${formatMajorBatchCode(ep.majorKey, ep.intakeBatch)}`;

  const statusEl = document.getElementById('edit-status');
  if (statusEl) {
    statusEl.className = 'status ' + (ep.status === 'published' ? 'approved' : 'draft');
    statusEl.textContent = readonly ? '查看模式' : (ep.status === 'published' ? '已发布' : '草稿');
  }

  renderExecInfoStrip(ep, version);
  updateVersionEditBreadcrumb();
  loadExecContent(ep.id);
  activateVersionEditTab('tab-classification');
  updateVersionEditTabStates();
}

// ── Sidebar nav ──
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', e => {
    e.preventDefault();
    goPage(item.dataset.page);
  });
});

// ── Version edit tabs ──
document.querySelectorAll('#page-version-edit .tab-bar .tab').forEach(tab => {
  tab.addEventListener('click', () => {
    if (tab.classList.contains('is-disabled')) {
      alert(getClassificationSetupStatus().message);
      return;
    }
    activateVersionEditTab(tab.dataset.tab);
  });
});

document.querySelectorAll('#page-exec-edit .tab-bar .tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const parent = tab.closest('#page-exec-edit');
    parent.querySelectorAll('.tab-bar .tab').forEach(t => t.classList.remove('active'));
    parent.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.tabExec)?.classList.add('active');
    if (tab.dataset.tabExec === 'exec-tab3') {
      renderProgrammeStructure('programme-structure-exec');
    }
  });
});

// ── Modals ──
function openModal(id) {
  document.getElementById(id)?.classList.add('open');
  if (id === 'modal-add-category') {
    if (categoryFormMode === 'add-l2') {
      onH1Change();
      onStudyTypeChange();
      onCategoryLevelChange();
      resetElectiveMatrix();
    } else if (categoryFormMode === 'edit-l2') {
      onStudyTypeChange();
      onCategoryLevelChange();
      if (editingCategoryId) loadElectiveMatrixForCategory(editingCategoryId);
    }
    applyCategoryFormMode();
  }
  if (id === 'modal-gen-exec') {
    initExecMajorSelect();
    const majorKey = document.getElementById('exec-major')?.value || 'finance';
    rebuildExecIntakeBatchSelect(majorKey);
    onExecBatchInput();
  }
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  if (id === 'modal-add-course') {
    courseModalReadonly = false;
    applyCourseModalReadonly(false);
    editingProgramCourseId = null;
  }
  if (id === 'modal-delete-category') pendingDeleteCategoryId = null;
  if (id === 'modal-submit-version') pendingSubmitVersionId = null;
  if (id === 'modal-delete-version') pendingDeleteVersionId = null;
  if (id === 'modal-delete-confirm') deleteConfirmCallback = null;
}

let deleteConfirmCallback = null;

function openDeleteConfirm({ title, message, hint, onConfirm }) {
  deleteConfirmCallback = onConfirm || null;
  const titleEl = document.getElementById('delete-confirm-title');
  const msgEl = document.getElementById('delete-confirm-msg');
  const hintEl = document.getElementById('delete-confirm-hint');
  if (titleEl) titleEl.textContent = title || '确认删除';
  if (msgEl) msgEl.innerHTML = message || '确定删除吗？此操作不可撤销。';
  if (hintEl) {
    if (hint) {
      hintEl.textContent = hint;
      hintEl.style.display = '';
    } else {
      hintEl.textContent = '';
      hintEl.style.display = 'none';
    }
  }
  openModal('modal-delete-confirm');
}

function cancelDeleteConfirm() {
  deleteConfirmCallback = null;
  closeModal('modal-delete-confirm');
}

function confirmDeleteConfirm() {
  const cb = deleteConfirmCallback;
  deleteConfirmCallback = null;
  closeModal('modal-delete-confirm');
  if (cb) cb();
}

document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeSltOutlineCloDropdown();
    closeSltInfoTip();
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  }
});

document.addEventListener('click', e => {
  const wrap = document.getElementById('slt-outline-clo-multiselect');
  if (wrap && !wrap.contains(e.target)) closeSltOutlineCloDropdown();
  if (!e.target.closest('.slt-info-tip')) closeSltInfoTip();
});

// ── H1/H2 cascade ──
const H2_MAP = {
  compulsory: ['Mata Pelajaran Umum (MPU)', 'University Course', 'General Elective'],
  core: ['Major Core', 'Common Core', 'Basic Medical Sciences', 'Discipline',
         'Scientific Methods', 'Engineering Core 1', 'Engineering Core 2',
         'Mathematics/Physics', 'Major Elective', 'Field Elective'],
  elective: ['General Elective', 'Major Elective', 'Open Elective',
             'Engineering Elective', 'Field Elective', 'Specialisation Elective'],
  minor: ['—'],
  training: ['Industrial Training', 'Practicum', 'Clinical Training'],
  others: ['Humanities']
};

// ── Semester codes: 4 years × 3 semesters (Y1S1 … Y4S3) ──
const PROGRAM_YEARS = 4;
const SEMESTERS_PER_YEAR = 3;
const SEMESTER_WEEKS = { 1: 18, 2: 18, 3: 6 };

function semesterCode(year, sem) {
  return `Y${year}S${sem}`;
}

function getAllSemesterCodes(years = PROGRAM_YEARS) {
  const codes = [];
  for (let y = 1; y <= years; y++) {
    for (let s = 1; s <= SEMESTERS_PER_YEAR; s++) {
      codes.push(semesterCode(y, s));
    }
  }
  return codes;
}

function buildSemesterSelectOptions(selected) {
  return getAllSemesterCodes()
    .map(code => `<option value="${code}"${code === selected ? ' selected' : ''}>${code}</option>`)
    .join('');
}

function initSemesterSelects() {
  document.querySelectorAll('.semester-select').forEach((sel, i) => {
    const defaults = ['Y1S2', 'Y2S1'];
    sel.innerHTML = buildSemesterSelectOptions(defaults[i] || 'Y1S1');
  });
}

function offeringSemesterIds(prefix = '') {
  const p = prefix ? `${prefix}-` : '';
  return {
    toggle: `${p}offering-semester-enabled`,
    wrap: `${p}offering-semester-wrap`,
    label: `${p}offering-semester-label`,
    select: `${p}offering-semester-select`,
    hint: `${p}offering-semester-hint`
  };
}

function isOfferingSemesterEnabled(prefix = '') {
  return document.getElementById(offeringSemesterIds(prefix).toggle)?.checked ?? false;
}

function getCourseFormH1Id(prefix = '') {
  const id = prefix ? `${prefix}-course-h1-select` : 'course-h1-select';
  return document.getElementById(id)?.value || '';
}

function isCourseFormCompulsory(prefix = '') {
  const h1Id = getCourseFormH1Id(prefix);
  if (!h1Id) return false;
  const l1 = findClassificationNode(h1Id);
  return l1?.studyType !== 'elective';
}

function getCourseFormStudyTypeLabel(prefix = '') {
  const h1Id = getCourseFormH1Id(prefix);
  if (!h1Id) return '—';
  return isCourseFormCompulsory(prefix) ? '必修 Compulsory' : '选修 Elective';
}

function syncCourseFormStudyTypeField(prefix = '') {
  const id = prefix ? `${prefix}-course-study-type-display` : 'course-study-type-display';
  const el = document.getElementById(id);
  if (el) el.value = getCourseFormStudyTypeLabel(prefix);
}

function setOfferingSemesterEnabled(enabled, semester, prefix = '', { locked = false } = {}) {
  const ids = offeringSemesterIds(prefix);
  const toggle = document.getElementById(ids.toggle);
  const wrap = document.getElementById(ids.wrap);
  const label = document.getElementById(ids.label);
  const select = document.getElementById(ids.select);
  const hint = document.getElementById(ids.hint);
  const toggleSwitch = toggle?.closest('.toggle-switch');
  const on = locked ? true : enabled;

  if (toggle) {
    toggle.checked = on;
    toggle.disabled = locked;
  }
  if (toggleSwitch) {
    toggleSwitch.classList.toggle('is-locked', locked);
    toggleSwitch.setAttribute('aria-disabled', locked ? 'true' : 'false');
  }
  if (wrap) {
    wrap.classList.toggle('field-disabled', !on);
    wrap.classList.toggle('offering-semester-locked', locked);
  }
  if (label) label.classList.toggle('req', on);
  if (select) {
    select.disabled = !on;
    if (on) {
      select.innerHTML = buildSemesterSelectOptions(semester || 'Y1S1');
    } else {
      select.innerHTML = '<option value="">—</option>';
    }
  }
  if (hint) {
    if (locked) {
      hint.textContent = '必修课程须指定开课学期，开关固定为开启';
    } else {
      hint.textContent = on
        ? '请选择该课程在本方案中的开课学期'
        : '选修课程可关闭开关，不指定开课学期时列表显示为 —';
    }
  }
  if (prefix === 'batch') {
    updateBatchAddButtonState();
  } else {
    updateCourseSaveButtonState();
  }
  syncCourseFormStudyTypeField(prefix);
}

function syncOfferingSemesterControl(prefix = '') {
  const ids = offeringSemesterIds(prefix);
  const select = document.getElementById(ids.select);
  const prev = select?.value && select.value !== '—' ? select.value : 'Y1S1';

  if (isCourseFormCompulsory(prefix)) {
    setOfferingSemesterEnabled(true, prev, prefix, { locked: true });
    return;
  }

  const toggle = document.getElementById(ids.toggle);
  if (toggle) {
    toggle.disabled = false;
    toggle.checked = isOfferingSemesterEnabled(prefix);
  }
  toggle?.closest('.toggle-switch')?.classList.remove('is-locked');
  toggle?.closest('.toggle-switch')?.setAttribute('aria-disabled', 'false');
  document.getElementById(ids.wrap)?.classList.remove('offering-semester-locked');
  setOfferingSemesterEnabled(isOfferingSemesterEnabled(prefix), prev, prefix, { locked: false });
}

function onOfferingSemesterToggleChange(prefix = '') {
  if (isCourseFormCompulsory(prefix)) {
    syncOfferingSemesterControl(prefix);
    return;
  }
  const select = document.getElementById(offeringSemesterIds(prefix).select);
  const prev = select?.value && select.value !== '—' ? select.value : 'Y1S1';
  setOfferingSemesterEnabled(isOfferingSemesterEnabled(prefix), prev, prefix, { locked: false });
}


function getUsedElectiveSemesters(excludeSelect) {
  return Array.from(document.querySelectorAll('#elective-matrix-tbody .semester-row-select'))
    .filter(sel => sel !== excludeSelect)
    .map(sel => sel.value)
    .filter(Boolean);
}

function buildElectiveSemesterOptions(selected, excludeSelect) {
  const used = getUsedElectiveSemesters(excludeSelect);
  const options = ['<option value="">请选择</option>'];
  getAllSemesterCodes().forEach(code => {
    if (code !== selected && used.includes(code)) return;
    options.push(`<option value="${code}"${code === selected ? ' selected' : ''}>${code}</option>`);
  });
  return options.join('');
}

function refreshElectiveSemesterOptions() {
  document.querySelectorAll('#elective-matrix-tbody .semester-row-select').forEach(sel => {
    const current = sel.value;
    sel.innerHTML = buildElectiveSemesterOptions(current, sel);
  });
}

function updateElectiveMatrixEmptyState() {
  const tbody = document.getElementById('elective-matrix-tbody');
  const empty = document.getElementById('elective-matrix-empty');
  if (!tbody) return;
  const hasRows = tbody.querySelectorAll('tr[data-row]').length > 0;
  if (empty) empty.style.display = hasRows ? 'none' : '';
}

function resetElectiveMatrix() {
  const tbody = document.getElementById('elective-matrix-tbody');
  if (!tbody) return;
  tbody.innerHTML = '<tr id="elective-matrix-empty"><td colspan="5" class="matrix-empty">暂无数据，请点击下方「+ 添加学期要求」</td></tr>';
}

function addElectiveMatrixRow(data = {}) {
  const tbody = document.getElementById('elective-matrix-tbody');
  if (!tbody) return;

  const row = document.createElement('tr');
  row.setAttribute('data-row', '1');
  row.innerHTML = `
    <td>
      <select class="input input-sm semester-row-select" onchange="refreshElectiveSemesterOptions()"></select>
    </td>
    <td><input class="input input-sm matrix-credit-min" type="number" min="0" placeholder="最低" value="${data.creditsMin ?? ''}"></td>
    <td><input class="input input-sm matrix-credit-max" type="number" min="0" placeholder="最高" value="${data.creditsMax ?? ''}"></td>
    <td><input class="input input-sm matrix-count" type="number" min="0" placeholder="门数" value="${data.count ?? ''}"></td>
    <td class="actions"><a href="#" class="danger" onclick="removeElectiveMatrixRow(this);return false">删除</a></td>`;

  tbody.appendChild(row);
  const sel = row.querySelector('.semester-row-select');
  sel.innerHTML = buildElectiveSemesterOptions(data.semester || '', sel);
  if (data.semester) sel.value = data.semester;
  refreshElectiveSemesterOptions();
  updateElectiveMatrixEmptyState();
}

function removeElectiveMatrixRow(link) {
  const row = link.closest('tr');
  if (!row) return;
  openDeleteConfirm({
    title: '删除学期要求',
    message: '确定删除该学期的选修要求配置吗？此操作不可撤销。',
    onConfirm: () => {
      row.remove();
      refreshElectiveSemesterOptions();
      updateElectiveMatrixEmptyState();
    }
  });
}

function onH1Change() {
  const h1 = document.getElementById('h1-select')?.value;
  const h2 = document.getElementById('h2-select');
  if (!h2) return;
  if (!h1) {
    h2.innerHTML = '<option value="">请选择</option>';
    h2.value = '';
    return;
  }
  h2.innerHTML = '<option value="">请选择</option>' +
    (H2_MAP[h1] || []).map(o => `<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join('');
  h2.value = '';
}

// ── Course Classification Tree（学分/课程数：L1/L2(有L3) 自动汇总，L2/L3 可填）──
const SEED_CLASSIFICATION_TREE = [
  {
    id: 'l1-comp', level: 1, name: 'Compulsory Courses', studyType: 'compulsory',
    children: [
      { id: 'l2-mpu', level: 2, name: 'Mata Pelajaran Umum (MPU)', studyType: 'compulsory', creditsMin: 19, creditsMax: 19, courseCount: 5 },
      { id: 'l2-uni', level: 2, name: 'University Course', studyType: 'compulsory', creditsMin: 15, creditsMax: 15, courseCount: 4 }
    ]
  },
  {
    id: 'l1-core', level: 1, name: 'Core/Major/Specialisation', studyType: 'compulsory',
    children: [
      { id: 'l2-major', level: 2, name: 'Major Core', studyType: 'compulsory', creditsMin: 54, creditsMax: 54, courseCount: 14 }
    ]
  },
  {
    id: 'l1-elec', level: 1, name: 'Optional/Elective Courses', studyType: 'elective', highlight: true,
    children: [
      {
        id: 'l2-ge', level: 2, name: 'General Elective', studyType: 'elective',
        creditsMin: 12, creditsMax: 20,
        children: [
          { id: 'l3-arts', level: 3, name: 'Arts', studyType: 'elective', creditsMin: 4, courseCount: 2 },
          { id: 'l3-biz', level: 3, name: 'Business', studyType: 'elective', creditsMin: 4, courseCount: 2 },
          { id: 'l3-sci', level: 3, name: 'Science', studyType: 'elective', creditsMin: 4, courseCount: 2 }
        ]
      },
      { id: 'l2-me', level: 2, name: 'Major Elective', studyType: 'elective', creditsMin: 15, creditsMax: 17, courseCount: 5 }
    ]
  }
];

/** 选修课学期修读要求（TAB1 矩阵 · 按二级分类 × 学期） */
const SEED_ELECTIVE_SEMESTER_REQUIREMENTS = {
  'l2-ge': {
    Y1S2: { creditsMin: 4, creditsMax: 6, count: 1 },
    Y2S1: { creditsMin: 4, creditsMax: 6, count: 1 },
    Y1S3: { creditsMin: 2, creditsMax: 4, count: 1 },
    Y3S1: { creditsMin: 4, creditsMax: 6, count: 1 },
    Y4S1: { creditsMin: 3, creditsMax: 5, count: 1 }
  },
  'l2-me': {
    Y2S2: { creditsMin: 4, creditsMax: 6, count: 1 },
    Y3S2: { creditsMin: 4, creditsMax: 6, count: 1 },
    Y4S2: { creditsMin: 4, creditsMax: 6, count: 1 }
  }
};

let CLASSIFICATION_TREE = JSON.parse(JSON.stringify(SEED_CLASSIFICATION_TREE));
let ELECTIVE_SEMESTER_REQUIREMENTS = JSON.parse(JSON.stringify(SEED_ELECTIVE_SEMESTER_REQUIREMENTS));

function normalizeElectiveSemesterReq(req) {
  if (!req) return req;
  if (req.credits != null && req.creditsMin == null) {
    req.creditsMin = req.credits;
    req.creditsMax = req.credits;
    delete req.credits;
  }
  if (req.creditsMin != null && req.creditsMax == null) {
    req.creditsMax = req.creditsMin;
  }
  return req;
}

function normalizeNodeCredits(node) {
  if (!node) return;
  if (node.credits != null && node.creditsMin == null) {
    node.creditsMin = node.credits;
    if (node.level !== 3) node.creditsMax = node.credits;
    delete node.credits;
  }
  if (node.level === 3) {
    delete node.creditsMax;
  } else if (node.creditsMin != null && node.creditsMax == null) {
    node.creditsMax = node.creditsMin;
  }
  (node.children || []).forEach(normalizeNodeCredits);
}

function calcNodeCreditsMin(node) {
  normalizeNodeCredits(node);
  if (node.level === 3) return Number(node.creditsMin) || 0;
  if (node.level === 2) return Number(node.creditsMin) || 0;
  if (node.level === 1) {
    return (node.children || []).reduce((sum, child) => sum + calcNodeCreditsMin(child), 0);
  }
  return Number(node.creditsMin) || 0;
}

function calcNodeCreditsMax(node) {
  normalizeNodeCredits(node);
  if (node.level === 3) return null;
  if (node.level === 2) return Number(node.creditsMax) || 0;
  if (node.level === 1) {
    return (node.children || []).reduce((sum, child) => sum + calcNodeCreditsMax(child), 0);
  }
  return Number(node.creditsMax) || 0;
}

function calcNodeCredits(node) {
  return calcNodeCreditsMin(node);
}

function calcNodeCourseCount(node) {
  if (node.level === 3) return Number(node.courseCount) || 0;
  if (node.level === 2) {
    if (node.children?.length) {
      return node.children.reduce((sum, child) => sum + calcNodeCourseCount(child), 0);
    }
    return Number(node.courseCount) || 0;
  }
  if (node.level === 1) {
    return (node.children || []).reduce((sum, child) => sum + calcNodeCourseCount(child), 0);
  }
  return Number(node.courseCount) || 0;
}

function isAggregatedCreditNode(node) {
  return node.level === 1;
}

function syncClassificationStoredCredits() {
  CLASSIFICATION_TREE.forEach(l1 => {
    normalizeNodeCredits(l1);
    (l1.children || []).forEach(l2 => {
      normalizeNodeCredits(l2);
      if (l2.children?.length) {
        delete l2.credits;
        delete l2.courseCount;
        (l2.children || []).forEach(normalizeNodeCredits);
      }
    });
  });
}

function findClassificationNode(id, nodes = CLASSIFICATION_TREE) {
  for (const n of nodes) {
    if (n.id === id) return n;
    if (n.children) {
      const found = findClassificationNode(id, n.children);
      if (found) return found;
    }
  }
  return null;
}

function hasCourseClassificationOptions() {
  return CLASSIFICATION_TREE.some(l1 => l1.children?.length);
}

function getClassificationSetupStatus() {
  if (!CLASSIFICATION_TREE.length) {
    return {
      ok: false,
      message: '请先在 TAB1 完成课程分类建设（各级分类及学分要求），再进入 TAB2 课程设置。'
    };
  }
  for (const l1 of CLASSIFICATION_TREE) {
    if (!l1.children?.length) {
      return {
        ok: false,
        message: `请先在 TAB1 为「${l1.name}」建设二级分类，再进入 TAB2 课程设置。`
      };
    }
    for (const l2 of l1.children) {
      if (l2.children?.length) {
        for (const l3 of l2.children) {
          normalizeNodeCredits(l3);
          if (l3.creditsMin == null || l3.creditsMin === '') {
            return {
              ok: false,
              message: `请完善 TAB1 三级分类「${l3.name}」的最低学分，再进入 TAB2 课程设置。`
            };
          }
        }
      } else {
        normalizeNodeCredits(l2);
        if (l2.creditsMin == null || l2.creditsMin === '') {
          return {
            ok: false,
            message: `请完善 TAB1 二级分类「${l2.name}」的学分要求，再进入 TAB2 课程设置。`
          };
        }
      }
    }
  }
  return { ok: true, message: '' };
}

function isClassificationSetupComplete() {
  return getClassificationSetupStatus().ok;
}

function canAccessVersionEditTab(tabId) {
  if (tabId !== 'tab-courses') return true;
  if (versionEditReadonly) return true;
  return isClassificationSetupComplete();
}

function updateVersionEditTabStates() {
  const coursesTab = document.querySelector('#page-version-edit .tab[data-tab="tab-courses"]');
  if (!coursesTab) return;
  const unlocked = canAccessVersionEditTab('tab-courses');
  coursesTab.classList.toggle('is-disabled', !unlocked);
  coursesTab.title = unlocked ? '' : getClassificationSetupStatus().message;
}

function activateVersionEditTab(tabId) {
  if (!canAccessVersionEditTab(tabId)) {
    alert(getClassificationSetupStatus().message);
    return;
  }
  const parent = document.getElementById('page-version-edit');
  if (!parent) return;
  parent.querySelectorAll('.tab-bar .tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === tabId);
  });
  parent.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  document.getElementById(tabId)?.classList.add('active');
  if (tabId === 'tab-structure') {
    renderProgrammeStructure('programme-structure-root');
  }
  if (tabId === 'tab-classification') {
    renderClassificationTree();
  }
  if (tabId === 'tab-courses') {
    renderProgramCoursesTable();
  }
}

/** 教务课程库（课程选择器数据源） */
const COURSE_CATALOG = [
  { id: 'mpu3123', code: 'MPU3123', name: 'Malaysian Studies 3', department: 'School of Humanities and Social Sciences', coordinator: 'Dr. Ahmad Rahman', credits: 3, language: 'English', classification: 'Compulsory', synopsis: 'An overview of Malaysian history, politics and society.', references: 'Malaysia: History and Heritage.' },
  { id: 'fin101', code: 'FIN101', name: 'Introduction to Finance', department: 'School of Economics & Management', coordinator: 'Prof. Lim Wei Jie', credits: 4, language: 'English', classification: 'Major Core', synopsis: 'Fundamentals of finance and financial markets.', references: 'Berk & DeMarzo, Corporate Finance.' },
  { id: 'fin201', code: 'FIN201', name: 'Corporate Finance', department: 'School of Economics & Management', coordinator: 'Dr. Tan Mei Ling', credits: 4, language: 'English', classification: 'Major Core', synopsis: 'This course introduces students to the principles of corporate finance, including valuation, capital budgeting, and risk management.', references: 'Berk & DeMarzo, Corporate Finance, 5th Ed.' },
  { id: 'eng101', code: 'ENG101', name: 'English for Academic Writing', department: 'School of Humanities and Social Sciences', coordinator: 'Dr. Sarah Chen', credits: 3, language: 'English', classification: 'Compulsory', synopsis: 'Academic writing skills for undergraduate students.', references: '—' },
  { id: 'phy101', code: 'PHY101', name: 'Mechanics', department: 'School of Science', coordinator: 'Dr. Wong Kai', credits: 4, language: 'English', classification: 'Major Core', synopsis: 'Classical mechanics for science majors.', references: 'Halliday & Resnick, Fundamentals of Physics.' },
  { id: 'phy102', code: 'PHY102', name: 'Data Science Fundamentals', department: 'School of Science', coordinator: 'Dr. Lee Ming', credits: 2, language: 'English', classification: 'Common Core', synopsis: 'Introduction to data science concepts and tools.', references: '—' },
  { id: 'csc201', code: 'CSC201', name: 'Introduction to Programming', department: 'School of Computing', coordinator: 'Dr. Kumar Raj', credits: 3, language: 'English', classification: 'Common Core', synopsis: 'Programming fundamentals using Python.', references: '—' },
  { id: 'fin301', code: 'FIN301', name: 'Investment Analysis', department: 'School of Economics & Management', coordinator: 'Dr. Tan Mei Ling', credits: 4, language: 'English', classification: 'Major Elective', synopsis: 'Portfolio theory and security analysis.', references: 'Bodie, Kane & Marcus, Investments.' },
  { id: 'int401', code: 'INT401', name: 'Industrial Training', department: 'School of Economics & Management', coordinator: 'Ms. Ooi Lay Kuan', credits: 6, language: 'English', classification: 'Industrial Training', synopsis: 'Supervised industrial placement.', references: '—' }
];

/** 培养方案内已配置课程（TAB2 列表数据源） */
const SEED_PROGRAM_COURSES = [
  {
    id: 'pc-mpu3123', catalogId: 'mpu3123',
    h1Id: 'l1-comp', h2Id: 'l2-mpu', h3Id: null,
    semester: 'Y1S1', studyType: 'compulsory', language: 'English', credits: 3,
    prereqIds: [],
    synopsis: 'An overview of Malaysian history, politics and society.',
    references: 'Malaysia: History and Heritage.'
  },
  {
    id: 'pc-fin101', catalogId: 'fin101',
    h1Id: 'l1-core', h2Id: 'l2-major', h3Id: null,
    semester: 'Y1S1', studyType: 'compulsory', language: 'English', credits: 4,
    prereqIds: [],
    synopsis: 'Fundamentals of finance and financial markets.',
    references: 'Berk & DeMarzo, Corporate Finance.'
  },
  {
    id: 'pc-fin201', catalogId: 'fin201',
    h1Id: 'l1-core', h2Id: 'l2-major', h3Id: null,
    semester: 'Y2S1', studyType: 'compulsory', language: 'English', credits: 4,
    prereqIds: ['fin101'],
    synopsis: 'This course introduces students to the principles of corporate finance, including valuation, capital budgeting, and risk management.',
    references: 'Berk & DeMarzo, Corporate Finance, 5th Ed.'
  },
  {
    id: 'pc-fin301', catalogId: 'fin301',
    h1Id: 'l1-elec', h2Id: 'l2-me', h3Id: null,
    semester: 'Y3S1', studyType: 'elective', language: 'English', credits: 4,
    prereqIds: ['fin201'],
    synopsis: 'Portfolio theory and security analysis.',
    references: 'Bodie, Kane & Marcus, Investments.'
  },
  {
    id: 'pc-csc201', catalogId: 'csc201',
    h1Id: 'l1-elec', h2Id: 'l2-ge', h3Id: 'l3-sci',
    semester: 'Y2S2', studyType: 'elective', language: 'English', credits: 3,
    prereqIds: [],
    synopsis: 'Programming fundamentals using Python.',
    references: '—'
  },
  {
    id: 'pc-eng101', catalogId: 'eng101',
    h1Id: 'l1-elec', h2Id: 'l2-ge', h3Id: 'l3-arts',
    semester: 'Y1S2', studyType: 'elective', language: 'English', credits: 3,
    prereqIds: [],
    synopsis: 'Academic writing skills for undergraduate students.',
    references: '—'
  },
  {
    id: 'pc-phy102', catalogId: 'phy102',
    h1Id: 'l1-elec', h2Id: 'l2-ge', h3Id: 'l3-sci',
    semester: 'Y3S2', studyType: 'elective', language: 'English', credits: 2,
    prereqIds: [],
    synopsis: 'Introduction to data science concepts and tools.',
    references: '—'
  }
];

const PROGRAM_COURSES = JSON.parse(JSON.stringify(SEED_PROGRAM_COURSES));

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function getEmptyVersionContent() {
  return {
    classificationTree: [],
    programCourses: [],
    electiveSemesterRequirements: {}
  };
}

function getSeedVersionContent() {
  return {
    classificationTree: cloneJson(SEED_CLASSIFICATION_TREE),
    programCourses: cloneJson(SEED_PROGRAM_COURSES),
    electiveSemesterRequirements: cloneJson(SEED_ELECTIVE_SEMESTER_REQUIREMENTS)
  };
}

function applyVersionContent(content) {
  CLASSIFICATION_TREE.length = 0;
  CLASSIFICATION_TREE.push(...cloneJson(content.classificationTree));
  PROGRAM_COURSES.length = 0;
  PROGRAM_COURSES.push(...cloneJson(content.programCourses));
  Object.keys(ELECTIVE_SEMESTER_REQUIREMENTS).forEach(k => delete ELECTIVE_SEMESTER_REQUIREMENTS[k]);
  Object.assign(ELECTIVE_SEMESTER_REQUIREMENTS, cloneJson(content.electiveSemesterRequirements));
}

function getVersionContentSnapshot(versionId) {
  if (VERSION_CONTENT_STORE[versionId]) {
    return cloneJson(VERSION_CONTENT_STORE[versionId]);
  }
  const v = findVersionById(versionId);
  return (v?.status === 'draft' || v?.status === 'rejected')
    ? getEmptyVersionContent()
    : getSeedVersionContent();
}

function saveCurrentEditContent() {
  const payload = {
    classificationTree: cloneJson(CLASSIFICATION_TREE),
    programCourses: cloneJson(PROGRAM_COURSES),
    electiveSemesterRequirements: cloneJson(ELECTIVE_SEMESTER_REQUIREMENTS)
  };
  if (currentChangeApplication?.id) {
    CHANGE_CONTENT_STORE[currentChangeApplication.id] = payload;
    return;
  }
  if (currentExecPlan?.id) {
    EXEC_CONTENT_STORE[currentExecPlan.id] = payload;
    return;
  }
  if (currentEditVersion?.id) {
    VERSION_CONTENT_STORE[currentEditVersion.id] = payload;
  }
}

function loadVersionContent(versionId) {
  applyVersionContent(getVersionContentSnapshot(versionId));
}

function loadExecContent(execPlanId) {
  const ep = findExecPlanById(execPlanId);
  if (!ep) return;
  let content = EXEC_CONTENT_STORE[execPlanId];
  if (!content) {
    content = cloneJson(getVersionContentSnapshot(ep.versionId));
    EXEC_CONTENT_STORE[execPlanId] = cloneJson(content);
  }
  applyVersionContent(content);
}

let selectedCatalogCourseId = null;
let editingProgramCourseId = null;
let selectedPrereqCourseIds = [];
let pendingPickerCourseId = null;
let pendingPrereqCourseIds = [];
let coursePickerMode = 'main';
let coursePickerFilteredList = [];
let batchSelectedCatalogIds = [];
let pendingBatchCourseIds = [];

function getExistingProgramCatalogIds() {
  return new Set(PROGRAM_COURSES.map(pc => pc.catalogId));
}

function createProgramCourseFromCatalog(catalogId, { h1Id, h2Id, h3Id, semester }) {
  const catalog = COURSE_CATALOG.find(c => c.id === catalogId);
  if (!catalog) return null;
  const l1 = findClassificationNode(h1Id);
  return {
    id: `pc-${catalogId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    catalogId,
    h1Id,
    h2Id,
    h3Id: h3Id || null,
    semester,
    studyType: l1?.studyType === 'elective' ? 'elective' : 'compulsory',
    language: catalog.language || 'English',
    credits: catalog.credits,
    prereqIds: [],
    synopsis: catalog.synopsis || '',
    references: catalog.references || ''
  };
}

function findProgramCourse(id) {
  return PROGRAM_COURSES.find(c => c.id === id);
}

function studyTypeTag(type) {
  if (type === 'elective') return '<span class="tag elective">选修</span>';
  return '<span class="tag compulsory">必修</span>';
}

function getCourseClassificationDisplay(pc) {
  const l1 = findClassificationNode(pc.h1Id);
  if (!l1) return '—';
  const l2 = pc.h2Id ? findClassificationNode(pc.h2Id) : null;
  const l3 = pc.h3Id ? findClassificationNode(pc.h3Id) : null;
  if (l3 && l2) return `${l1.name} / ${l2.name} / ${l3.name}`;
  if (l2) return `${l1.name} / ${l2.name}`;
  return l1.name;
}

function getProgramCourseCredits(pc) {
  const cat = COURSE_CATALOG.find(c => c.id === pc.catalogId);
  return Number(pc.credits ?? cat?.credits) || 0;
}

function courseBelongsToClassificationNode(pc, node) {
  if (!pc || !node || pc.studyType !== 'compulsory') return false;
  if (node.level === 1) return pc.h1Id === node.id;
  if (node.level === 2) return pc.h2Id === node.id;
  if (node.level === 3) return pc.h3Id === node.id;
  return false;
}

function sumCompulsoryCreditsForNode(nodeId, excludeCourseId = null) {
  const node = findClassificationNode(nodeId);
  if (!node) return 0;
  return PROGRAM_COURSES
    .filter(pc => pc.id !== excludeCourseId && courseBelongsToClassificationNode(pc, node))
    .reduce((sum, pc) => sum + getProgramCourseCredits(pc), 0);
}

function getClassificationLevelLabel(level) {
  return { 1: '一级', 2: '二级', 3: '三级' }[level] || '';
}

function getClassificationMaxCredits(node) {
  if (!node) return null;
  normalizeNodeCredits(node);
  if (node.level === 3) {
    if (node.creditsMax != null && node.creditsMax !== '') return Number(node.creditsMax);
    if (node.creditsMin != null && node.creditsMin !== '') return Number(node.creditsMin);
    return null;
  }
  return calcNodeCreditsMax(node);
}

function getEffectiveCourseCreditCap(node) {
  if (!node) return null;
  normalizeNodeCredits(node);
  if (node.level === 3) {
    if (node.creditsMax != null && node.creditsMax !== '') return Number(node.creditsMax);
    if (node.creditsMin != null && node.creditsMin !== '') return Number(node.creditsMin);
    return null;
  }
  if (node.level === 2 && node.children?.length) {
    return null;
  }
  return getClassificationMaxCredits(node);
}

function isCompulsoryCourseClassification(h1Id) {
  const l1 = findClassificationNode(h1Id);
  return l1?.studyType !== 'elective';
}

function validateCompulsoryCourseMaxCredits({ h1Id, h2Id, h3Id, credits, excludeCourseId = null }) {
  const addCredits = Number(credits) || 0;
  if (addCredits <= 0) return { ok: true };

  const violations = [];
  const isCompulsory = isCompulsoryCourseClassification(h1Id);
  const targetId = h3Id || h2Id;

  if (targetId) {
    const target = findClassificationNode(targetId);
    const cap = getEffectiveCourseCreditCap(target);
    if (cap != null && addCredits > cap) {
      violations.push(
        `当前课程学分 ${addCredits} 已超过「${target.name}」（${getClassificationLevelLabel(target.level)}）最高学分限制 ${cap}`
      );
    }
  }

  if (isCompulsory) {
    [h1Id, h2Id, h3Id].filter(Boolean).forEach(nodeId => {
      const node = findClassificationNode(nodeId);
      if (!node || node.studyType !== 'compulsory') return;
      const maxLimit = getClassificationMaxCredits(node);
      if (maxLimit == null) return;
      const current = sumCompulsoryCreditsForNode(nodeId, excludeCourseId);
      const after = current + addCredits;
      if (after > maxLimit && !(nodeId === targetId && addCredits > maxLimit)) {
        violations.push(
          `「${node.name}」（${getClassificationLevelLabel(node.level)}）最高学分 ${maxLimit}，` +
          `当前已配置 ${current}，保存后将为 ${after}`
        );
      }
    });
  }

  if (violations.length) {
    return {
      ok: false,
      message: `超出课程分类最高学分限制，无法提交：\n${violations.join('\n')}`
    };
  }
  return { ok: true };
}

function validateCompulsoryMinCreditsForSubmit() {
  const shortcomings = [];

  function walk(nodes) {
    (nodes || []).forEach(node => {
      if (node.studyType === 'compulsory') {
        const minRequired = calcNodeCreditsMin(node);
        if (minRequired > 0) {
          const current = sumCompulsoryCreditsForNode(node.id);
          if (current < minRequired) {
            shortcomings.push(
              `「${node.name}」（${getClassificationLevelLabel(node.level)}）` +
              `最低学分 ${minRequired}，当前已配置 ${current}`
            );
          }
        }
      }
      walk(node.children);
    });
  }

  walk(CLASSIFICATION_TREE);

  if (shortcomings.length) {
    return {
      ok: false,
      message: `以下必修课程分类未达到最低学分要求，无法提交审批：\n${shortcomings.join('\n')}`
    };
  }
  return { ok: true };
}

function submitCurrentVersionForApproval() {
  if (currentExecPlan || versionEditReadonly) return;
  if (currentChangeApplication) {
    requestSubmitChangeApplication();
    return;
  }
  if (!currentEditVersion) return;
  const result = validateCompulsoryMinCreditsForSubmit();
  if (!result.ok) {
    alert(result.message);
    return;
  }
  requestSubmitVersion(currentEditVersion.id);
}

function getCourseClassificationShort(pc) {
  const l2 = pc.h2Id ? findClassificationNode(pc.h2Id) : null;
  const l3 = pc.h3Id ? findClassificationNode(pc.h3Id) : null;
  if (l3) return l3.name;
  if (l2) return l2.name;
  return findClassificationNode(pc.h1Id)?.name || '—';
}

function getCourseClassificationL1(h1Id) {
  return findClassificationNode(h1Id)?.name || '—';
}

function getCourseClassificationL2(h2Id) {
  return h2Id ? (findClassificationNode(h2Id)?.name || '—') : '—';
}

function getCourseClassificationL3(h3Id) {
  return h3Id ? (findClassificationNode(h3Id)?.name || '—') : '—';
}

function getElectiveL2Categories() {
  const list = [];
  CLASSIFICATION_TREE.forEach(l1 => {
    if (l1.studyType !== 'elective') return;
    (l1.children || []).forEach(l2 => {
      if (l2.level === 2) list.push({ l1, l2 });
    });
  });
  return list;
}

function renderSemesterMatrixTable() {
  const tbody = document.getElementById('semester-matrix-tbody');
  if (!tbody) return;
  const codes = getAllSemesterCodes();
  const categories = getElectiveL2Categories();

  if (!categories.length) {
    tbody.innerHTML = `<tr><td colspan="${2 + codes.length}" class="matrix-empty">暂无选修类二级分类</td></tr>`;
    return;
  }

  tbody.innerHTML = categories.map(({ l1, l2 }) => {
    const reqs = ELECTIVE_SEMESTER_REQUIREMENTS[l2.id] || {};
    const minCells = codes.map(code => {
      const v = normalizeElectiveSemesterReq(reqs[code])?.creditsMin;
      return `<td>${v != null && v !== '' ? v : '—'}</td>`;
    }).join('');
    const maxCells = codes.map(code => {
      const v = normalizeElectiveSemesterReq(reqs[code])?.creditsMax;
      return `<td>${v != null && v !== '' ? v : '—'}</td>`;
    }).join('');
    const countCells = codes.map(code => {
      const v = reqs[code]?.count;
      return `<td>${v != null && v !== '' ? v : '—'}</td>`;
    }).join('');
    return `
      <tr>
        <td class="sticky-col-cat cat-cell" rowspan="3">${escapeHtml(l2.name)}</td>
        <td class="sticky-col-req req-cell">最低学分</td>
        ${minCells}
      </tr>
      <tr>
        <td class="sticky-col-req req-cell">最高学分</td>
        ${maxCells}
      </tr>
      <tr>
        <td class="sticky-col-req req-cell">课程数</td>
        ${countCells}
      </tr>`;
  }).join('');
}

function buildElectivePoolCourseEntries() {
  const entries = [];
  getElectiveL2Categories().forEach(({ l1, l2 }) => {
    const reqs = ELECTIVE_SEMESTER_REQUIREMENTS[l2.id] || {};
    Object.entries(reqs).forEach(([semester, req]) => {
      normalizeElectiveSemesterReq(req);
      const count = Number(req.count) || 0;
      const credits = Number(req.creditsMin) || 0;
      if (count <= 0) return;
      const creditPerCourse = count > 0 ? credits / count : credits;
      const creditDisplay = Number.isInteger(creditPerCourse)
        ? creditPerCourse
        : Math.round(creditPerCourse * 10) / 10;
      for (let i = 0; i < count; i++) {
        entries.push({
          semester,
          name: l2.name,
          code: 'GXXXX',
          cls: l1.name,
          credit: creditDisplay,
          elective: true,
          isPool: true
        });
      }
    });
  });
  return entries;
}

function parseSemesterCode(code) {
  const m = /^Y(\d+)S(\d+)$/.exec(code || '');
  if (!m) return null;
  return { year: Number(m[1]), sem: Number(m[2]) };
}

function buildProgrammeStructureFromCourses() {
  const v = currentEditVersion;
  const majorKey = v?.majorKey || 'finance';
  const major = MAJORS[majorKey];
  const programmeName = major ? `${major.name} (${major.nameZh})` : 'Programme';

  const bySemester = {};
  PROGRAM_COURSES.forEach(pc => {
    if (!pc.semester) return;
    const cat = COURSE_CATALOG.find(c => c.id === pc.catalogId);
    if (!cat) return;
    if (!bySemester[pc.semester]) bySemester[pc.semester] = [];
    bySemester[pc.semester].push({
      name: cat.name,
      code: cat.code,
      cls: getCourseClassificationL1(pc.h1Id),
      credit: pc.credits ?? cat.credits,
      elective: pc.studyType === 'elective'
    });
  });

  const poolEntries = buildElectivePoolCourseEntries();
  poolEntries.forEach(entry => {
    if (!bySemester[entry.semester]) bySemester[entry.semester] = [];
    bySemester[entry.semester].push(entry);
  });

  const poolCredits = poolEntries.reduce((s, e) => s + (e.credit || 0), 0);
  const totalCredits = PROGRAM_COURSES.reduce((sum, pc) => {
    if (!pc.semester) return sum;
    const cat = COURSE_CATALOG.find(c => c.id === pc.catalogId);
    return sum + (pc.credits ?? cat?.credits ?? 0);
  }, 0) + poolCredits;

  const yearsMap = new Map();
  Object.entries(bySemester).forEach(([code, courses]) => {
    const parsed = parseSemesterCode(code);
    if (!parsed || !courses.length) return;
    if (!yearsMap.has(parsed.year)) yearsMap.set(parsed.year, new Map());
    yearsMap.get(parsed.year).set(parsed.sem, {
      label: `Semester ${parsed.sem}`,
      weeks: SEMESTER_WEEKS[parsed.sem] || 18,
      courses
    });
  });

  const years = [...yearsMap.keys()].sort((a, b) => a - b).map(year => {
    const semMap = yearsMap.get(year);
    const semesters = [];
    for (let sem = 1; sem <= SEMESTERS_PER_YEAR; sem++) {
      semesters.push(semMap.get(sem) || {
        label: `Semester ${sem}`,
        weeks: SEMESTER_WEEKS[sem] || 18,
        courses: []
      });
    }
    return { year, semesters };
  });

  return {
    institution: 'Xiamen University Malaysia',
    programme: programmeName,
    totalCredits: totalCredits || '—',
    years
  };
}

function refreshProgrammeStructureIfVisible() {
  if (document.getElementById('tab-structure')?.classList.contains('active')) {
    renderProgrammeStructure('programme-structure-root');
  }
}

function renderProgramCoursesTable() {
  const tbody = document.getElementById('program-courses-tbody');
  if (!tbody) return;
  tbody.innerHTML = PROGRAM_COURSES.map(pc => {
    const cat = COURSE_CATALOG.find(c => c.id === pc.catalogId);
    if (!cat) return '';
    const actions = versionEditReadonly
      ? `<a href="#" class="view-link" onclick="openViewProgramCourse('${pc.id}');return false">查看</a>`
      : `<a href="#" onclick="openEditProgramCourse('${pc.id}');return false">编辑</a><a href="#" class="danger">移除</a>`;
    return `<tr>
      <td><code>${escapeHtml(cat.code)}</code></td>
      <td>${escapeHtml(cat.name)}</td>
      <td>${escapeHtml(getCourseClassificationL1(pc.h1Id))}</td>
      <td>${escapeHtml(getCourseClassificationL2(pc.h2Id))}</td>
      <td>${escapeHtml(getCourseClassificationL3(pc.h3Id))}</td>
      <td>${pc.credits ?? cat.credits}</td>
      <td>${escapeHtml(pc.semester || '—')}</td>
      <td>${studyTypeTag(pc.studyType)}</td>
      <td class="actions">${actions}</td>
    </tr>`;
  }).join('');
  refreshProgrammeStructureIfVisible();
}

function setCoursePickerSectionVisible(visible) {
  const section = document.getElementById('course-picker-section');
  if (section) section.classList.toggle('is-hidden', !visible);
}

function setCourseClassificationValues(h1Id, h2Id, h3Id) {
  const h1 = document.getElementById('course-h1-select');
  if (h1 && h1Id) {
    h1.value = h1Id;
    onCourseH1Change();
  }
  const h2 = document.getElementById('course-h2-select');
  if (h2 && h2Id) {
    h2.value = h2Id;
    onCourseH2Change();
  }
  const h3 = document.getElementById('course-h3-select');
  if (h3 && h3Id) {
    h3.value = h3Id;
  }
  updateCourseSaveButtonState();
}

function fillCourseFormFromProgramCourse(pc) {
  const catalog = COURSE_CATALOG.find(c => c.id === pc.catalogId);
  if (!catalog) return;
  selectedCatalogCourseId = pc.catalogId;
  selectedPrereqCourseIds = [...(pc.prereqIds || [])];
  setCourseFormDetailsEnabled(true);
  document.getElementById('course-code-input').value = catalog.code;
  document.getElementById('course-name-input').value = catalog.name;
  document.getElementById('course-dept-input').value = catalog.department;
  document.getElementById('course-coordinator-input').value = catalog.coordinator;
  document.getElementById('course-credits-input').value = pc.credits ?? catalog.credits;
  const lang = document.getElementById('course-language-select');
  if (lang) lang.value = pc.language || catalog.language || 'English';
  document.getElementById('course-prereq-input').value = formatPrereqDisplay(selectedPrereqCourseIds);
  document.getElementById('course-synopsis-input').value = pc.synopsis ?? catalog.synopsis ?? '';
  document.getElementById('course-refs-input').value = pc.references ?? catalog.references ?? '';
  setOfferingSemesterEnabled(Boolean(pc.semester), pc.semester || 'Y1S1');
  setCourseClassificationValues(pc.h1Id, pc.h2Id, pc.h3Id);
  syncOfferingSemesterControl();
  updateCourseCharCounts();
}

function readCourseFormIntoProgramCourse(pc) {
  const h1 = document.getElementById('course-h1-select');
  const h2 = document.getElementById('course-h2-select');
  const h3 = document.getElementById('course-h3-select');
  const offering = document.getElementById('offering-semester-select');
  const credits = document.getElementById('course-credits-input');
  const lang = document.getElementById('course-language-select');
  const synopsis = document.getElementById('course-synopsis-input');
  const refs = document.getElementById('course-refs-input');
  if (h1?.value) pc.h1Id = h1.value;
  if (h2?.value) pc.h2Id = h2.value;
  pc.h3Id = h3 && !h3.disabled && h3.value ? h3.value : null;
  if (isCourseFormCompulsory() || isOfferingSemesterEnabled()) {
    pc.semester = offering?.value || null;
  } else {
    pc.semester = null;
  }
  if (credits?.value !== '') pc.credits = Number(credits.value);
  if (lang?.value) pc.language = lang.value;
  pc.prereqIds = [...selectedPrereqCourseIds];
  if (synopsis) pc.synopsis = synopsis.value;
  if (refs) pc.references = refs.value;
  const l1 = findClassificationNode(pc.h1Id);
  pc.studyType = l1?.studyType === 'elective' ? 'elective' : 'compulsory';
}

function formatPrereqDisplay(ids) {
  return ids.map(id => {
    const c = COURSE_CATALOG.find(x => x.id === id);
    return c ? `${c.code} — ${c.name}` : '';
  }).filter(Boolean).join('；');
}

function isPrereqPickerSelected(id) {
  return pendingPrereqCourseIds.includes(id);
}

function getCourseCatalogOfferings() {
  return [...new Set(COURSE_CATALOG.map(c => c.department))].sort();
}

function rebuildOfferingFilterOptions() {
  const sel = document.getElementById('picker-filter-offering');
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">please select</option>' +
    getCourseCatalogOfferings().map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
  if (cur) sel.value = cur;
}

function filterCourseCatalogList() {
  const name = document.getElementById('picker-filter-name')?.value.trim().toLowerCase() || '';
  const code = document.getElementById('picker-filter-code')?.value.trim().toLowerCase() || '';
  const offering = document.getElementById('picker-filter-offering')?.value || '';
  return COURSE_CATALOG.filter(c => {
    if (name && !c.name.toLowerCase().includes(name)) return false;
    if (code && !c.code.toLowerCase().includes(code)) return false;
    if (offering && c.department !== offering) return false;
    return true;
  });
}

function renderCoursePickerTable(list) {
  coursePickerFilteredList = list;
  const tbody = document.getElementById('course-picker-tbody');
  const countEl = document.getElementById('course-picker-count');
  if (!tbody) return;

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="matrix-empty">No records found</td></tr>';
    if (countEl) countEl.textContent = 'Total 0 records';
    return;
  }

  if (coursePickerMode === 'prereq' || coursePickerMode === 'batch') {
    tbody.innerHTML = list.map((c, i) => {
      const disabled = coursePickerMode === 'prereq'
        ? c.id === selectedCatalogCourseId
        : isBatchCourseDisabled(c.id);
      const selected = coursePickerMode === 'prereq'
        ? isPrereqPickerSelected(c.id)
        : isBatchPickerSelected(c.id);
      const toggleFn = coursePickerMode === 'prereq'
        ? `togglePrereqPickerRow('${c.id}')`
        : `toggleBatchPickerRow('${c.id}')`;
      return `
        <tr class="picker-row${selected ? ' selected' : ''}${disabled ? ' disabled' : ''}" onclick="${toggleFn}">
          <td class="col-radio"><input type="checkbox" ${selected ? 'checked' : ''} ${disabled ? 'disabled' : ''} onclick="event.stopPropagation();${toggleFn}"></td>
          <td>${i + 1}</td>
          <td><code>${escapeHtml(c.code)}</code></td>
          <td>${escapeHtml(c.name)}${disabled && coursePickerMode === 'batch' ? ' <span class="text-muted">（已添加）</span>' : ''}</td>
          <td>${escapeHtml(c.department)}</td>
          <td>${c.credits}</td>
          <td>${escapeHtml(c.classification || '—')}</td>
        </tr>`;
    }).join('');
    const selectedCount = coursePickerMode === 'prereq'
      ? pendingPrereqCourseIds.length
      : pendingBatchCourseIds.length;
    if (countEl) countEl.textContent = `Total ${list.length} records · 已选 ${selectedCount} 门`;
    return;
  }

  tbody.innerHTML = list.map((c, i) => `
    <tr class="picker-row${pendingPickerCourseId === c.id ? ' selected' : ''}" onclick="selectCoursePickerRow('${c.id}')">
      <td class="col-radio"><input type="radio" name="course-pick" value="${c.id}" ${pendingPickerCourseId === c.id ? 'checked' : ''} onclick="event.stopPropagation();selectCoursePickerRow('${c.id}')"></td>
      <td>${i + 1}</td>
      <td><code>${escapeHtml(c.code)}</code></td>
      <td>${escapeHtml(c.name)}</td>
      <td>${escapeHtml(c.department)}</td>
      <td>${c.credits}</td>
      <td>${escapeHtml(c.classification || '—')}</td>
    </tr>`).join('');
  if (countEl) countEl.textContent = `Total ${list.length} records`;
}

function togglePrereqPickerRow(id) {
  if (id === selectedCatalogCourseId) return;
  const idx = pendingPrereqCourseIds.indexOf(id);
  if (idx >= 0) pendingPrereqCourseIds.splice(idx, 1);
  else pendingPrereqCourseIds.push(id);
  renderCoursePickerTable(coursePickerFilteredList);
}

function isBatchPickerSelected(id) {
  return pendingBatchCourseIds.includes(id);
}

function toggleBatchPickerRow(id) {
  if (isBatchCourseDisabled(id)) return;
  const idx = pendingBatchCourseIds.indexOf(id);
  if (idx >= 0) pendingBatchCourseIds.splice(idx, 1);
  else pendingBatchCourseIds.push(id);
  renderCoursePickerTable(coursePickerFilteredList);
}

function selectCoursePickerRow(id) {
  pendingPickerCourseId = id;
  renderCoursePickerTable(coursePickerFilteredList);
}

function searchCourseCatalog() {
  renderCoursePickerTable(filterCourseCatalogList());
}

function resetCoursePickerSearch() {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
  set('picker-filter-name', '');
  set('picker-filter-code', '');
  set('picker-filter-offering', '');
  if (coursePickerMode === 'prereq') {
    pendingPrereqCourseIds = [...selectedPrereqCourseIds];
  } else if (coursePickerMode === 'batch') {
    pendingBatchCourseIds = [...batchSelectedCatalogIds];
    pendingPickerCourseId = null;
  } else {
    pendingPickerCourseId = selectedCatalogCourseId;
  }
  renderCoursePickerTable(COURSE_CATALOG);
}

function openCoursePickerModal(mode = 'main') {
  coursePickerMode = mode;
  const title = document.getElementById('course-picker-title');
  if (title) {
    const titles = {
      prereq: '选择先修课程（可多选）',
      batch: '选择课程（可多选）',
      main: '选择课程'
    };
    title.textContent = titles[mode] || titles.main;
  }
  if (mode === 'prereq') {
    pendingPrereqCourseIds = [...selectedPrereqCourseIds];
    pendingPickerCourseId = null;
    pendingBatchCourseIds = [];
  } else if (mode === 'batch') {
    pendingBatchCourseIds = [...batchSelectedCatalogIds];
    pendingPickerCourseId = null;
    pendingPrereqCourseIds = [];
  } else {
    pendingPickerCourseId = selectedCatalogCourseId;
    pendingPrereqCourseIds = [];
    pendingBatchCourseIds = [];
  }
  rebuildOfferingFilterOptions();
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v; };
  set('picker-filter-name', '');
  set('picker-filter-code', '');
  set('picker-filter-offering', '');
  renderCoursePickerTable(COURSE_CATALOG);
  document.getElementById('modal-course-picker')?.classList.add('open');
}

function openBatchCoursePickerModal() {
  openCoursePickerModal('batch');
}

function openPrereqCoursePickerModal() {
  if (!selectedCatalogCourseId) {
    alert('请先选择要新增的课程');
    return;
  }
  openCoursePickerModal('prereq');
}

function cancelCoursePicker() {
  pendingPickerCourseId = null;
  pendingPrereqCourseIds = [];
  pendingBatchCourseIds = [];
  document.getElementById('modal-course-picker')?.classList.remove('open');
}

function applySelectedCourse(course) {
  if (!course) return;
  selectedCatalogCourseId = course.id;
  selectedPrereqCourseIds = selectedPrereqCourseIds.filter(id => id !== course.id);
  document.getElementById('course-prereq-input').value = formatPrereqDisplay(selectedPrereqCourseIds);
  setCourseFormDetailsEnabled(true);
  document.getElementById('course-code-input').value = course.code;
  document.getElementById('course-name-input').value = course.name;
  document.getElementById('course-dept-input').value = course.department;
  document.getElementById('course-coordinator-input').value = course.coordinator;
  document.getElementById('course-credits-input').value = course.credits;
  const lang = document.getElementById('course-language-select');
  if (lang) lang.value = course.language || 'English';
  document.getElementById('course-synopsis-input').value = course.synopsis || '';
  document.getElementById('course-refs-input').value = course.references || '';
  const display = document.getElementById('course-picker-display');
  if (display) display.value = `${course.code} — ${course.name}`;
  updateCourseCharCounts();
  const hint = document.getElementById('course-picker-hint');
  if (hint) hint.textContent = `已选择：${course.code} ${course.name}。请继续填写方案内分类与开课学期。`;
  syncOfferingSemesterControl();
  updateCourseSaveButtonState();
}

function confirmCoursePicker() {
  if (coursePickerMode === 'prereq') {
    selectedPrereqCourseIds = pendingPrereqCourseIds.filter(id => id !== selectedCatalogCourseId);
    document.getElementById('course-prereq-input').value = formatPrereqDisplay(selectedPrereqCourseIds);
    cancelCoursePicker();
    return;
  }

  if (coursePickerMode === 'batch') {
    batchSelectedCatalogIds = pendingBatchCourseIds.filter(id => !isBatchCourseDisabled(id));
    updateBatchCoursePickerDisplay();
    updateBatchAddButtonState();
    cancelCoursePicker();
    return;
  }

  if (!pendingPickerCourseId) {
    alert('请选择一门课程');
    return;
  }
  const course = COURSE_CATALOG.find(c => c.id === pendingPickerCourseId);
  if (!course) return;
  applySelectedCourse(course);
  cancelCoursePicker();
}

function clearCourseFormFields() {
  selectedCatalogCourseId = null;
  selectedPrereqCourseIds = [];
  pendingPickerCourseId = null;
  pendingPrereqCourseIds = [];
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
  set('course-picker-display', '');
  set('course-code-input', '');
  set('course-name-input', '');
  set('course-dept-input', '');
  set('course-coordinator-input', '');
  set('course-credits-input', '');
  set('course-prereq-input', '');
  set('course-synopsis-input', '');
  set('course-refs-input', '');
  syncOfferingSemesterControl();
  const lang = document.getElementById('course-language-select');
  if (lang) lang.value = 'English';
  updateCourseCharCounts();
}

function updateCourseCharCounts() {
  const syn = document.getElementById('course-synopsis-input');
  const refs = document.getElementById('course-refs-input');
  const synCount = document.getElementById('course-synopsis-count');
  const refsCount = document.getElementById('course-refs-count');
  if (syn && synCount) synCount.textContent = `${(syn.value || '').length}/500`;
  if (refs && refsCount) refsCount.textContent = `${(refs.value || '').length}/500`;
}

function setCourseFormDetailsEnabled(enabled) {
  const details = document.getElementById('course-form-details');
  if (details) details.classList.toggle('course-form-disabled', !enabled);
}

function resetCoursePicker() {
  cancelCoursePicker();
  clearCourseFormFields();
  setCourseFormDetailsEnabled(false);
  const hint = document.getElementById('course-picker-hint');
  if (hint) hint.textContent = '须先从教务课程库选择一门课程；选定后自动带出课号、课名、开课单位与负责人。';
}

function refreshCourseClassificationSelects() {
  const h1 = document.getElementById('course-h1-select');
  const h2 = document.getElementById('course-h2-select');
  const h3 = document.getElementById('course-h3-select');
  const hint = document.getElementById('course-classification-hint');
  if (!h1 || !h2 || !h3) return false;

  const l1List = CLASSIFICATION_TREE.filter(l1 => l1.children?.length);
  if (!l1List.length) {
    h1.innerHTML = '<option value="">暂无分类</option>';
    h2.innerHTML = '<option value="">暂无分类</option>';
    h3.innerHTML = '<option value="">—</option>';
    h1.disabled = h2.disabled = h3.disabled = true;
    updateCourseH3FieldState(false);
    if (hint) {
      hint.innerHTML = '<strong>无法新增课程：</strong>请先在 TAB1 课程分类中建设至少一个一级分类及其二级分类。';
    }
    updateCourseSaveButtonState();
    return false;
  }

  h1.disabled = false;
  h1.innerHTML = l1List.map(l1 => `<option value="${l1.id}">${escapeHtml(l1.name)}</option>`).join('');
  if (hint) {
    hint.textContent = '课程分类选项来自 TAB1 已建设的分类树；有三级分类时须选择 H3。';
  }
  onCourseH1Change();
  return true;
}

function onCourseH1Change() {
  const h1Id = document.getElementById('course-h1-select')?.value;
  const h2 = document.getElementById('course-h2-select');
  const l1 = findClassificationNode(h1Id);
  const l2List = l1?.children || [];
  if (!h2) return;

  if (!l2List.length) {
    h2.innerHTML = '<option value="">无二级分类</option>';
    h2.disabled = true;
  } else {
    h2.disabled = false;
    h2.innerHTML = l2List.map(l2 => `<option value="${l2.id}">${escapeHtml(l2.name)}</option>`).join('');
  }
  onCourseH2Change();
  syncOfferingSemesterControl();
}

function updateCourseH3FieldState(hasL3) {
  const label = document.getElementById('course-h3-label');
  const wrap = document.getElementById('course-h3-wrap');
  const hint = document.getElementById('course-h3-hint');
  if (label) label.classList.toggle('req', hasL3);
  if (wrap) wrap.classList.toggle('field-disabled', !hasL3);
  if (hint) {
    hint.textContent = hasL3 ? '该二级分类下有三级分类，请选择（必填）' : '该二级分类无三级分类，无需填写';
  }
}

function onCourseH2Change() {
  const h2Id = document.getElementById('course-h2-select')?.value;
  const h3 = document.getElementById('course-h3-select');
  const l2 = findClassificationNode(h2Id);
  const l3List = l2?.children || [];
  if (!h3) return;

  const hasL3 = l3List.length > 0;
  updateCourseH3FieldState(hasL3);

  if (!hasL3) {
    h3.innerHTML = '<option value="">—</option>';
    h3.disabled = true;
  } else {
    h3.disabled = false;
    h3.innerHTML = '<option value="">请选择</option>' +
      l3List.map(l3 => `<option value="${l3.id}">${escapeHtml(l3.name)}</option>`).join('');
  }
  updateCourseSaveButtonState();
}

function validateCourseSubmit() {
  const editing = editingProgramCourseId ? findProgramCourse(editingProgramCourseId) : null;

  if (!editing && !selectedCatalogCourseId) {
    return { ok: false, message: '请先从课程库选择一门课程' };
  }
  if (!hasCourseClassificationOptions()) {
    return { ok: false, message: '请先在 TAB1 课程分类中建设分类（至少包含一级与二级），否则无法提交课程' };
  }

  const h1 = document.getElementById('course-h1-select');
  const h2 = document.getElementById('course-h2-select');
  const h3 = document.getElementById('course-h3-select');

  if (!h1?.value || h1.disabled) {
    return { ok: false, message: '请选择一级分类（H1）' };
  }
  if (!h2?.value || h2.disabled) {
    return { ok: false, message: '请选择二级分类（H2）' };
  }
  if (h3 && !h3.disabled && !h3.value) {
    return { ok: false, message: '请选择三级分类（H3）' };
  }

  if (isCourseFormCompulsory() || isOfferingSemesterEnabled()) {
    const offering = document.getElementById('offering-semester-select');
    if (!offering?.value || offering.value === '—') {
      return {
        ok: false,
        message: isCourseFormCompulsory()
          ? '必修课程须开启指定学期并选择开课学期'
          : '已开启「指定学期」，请选择开课学期'
      };
    }
  }

  const creditsRaw = document.getElementById('course-credits-input')?.value;
  if (creditsRaw === '' || Number(creditsRaw) < 0) {
    return { ok: false, message: '请填写有效的课程学分' };
  }

  const h1Id = h1.value;
  const h2Id = h2.value;
  const h3Id = h3 && !h3.disabled && h3.value ? h3.value : null;
  const credits = Number(creditsRaw);

  const maxCheck = validateCompulsoryCourseMaxCredits({
    h1Id,
    h2Id,
    h3Id,
    credits,
    excludeCourseId: editing?.id || null
  });
  if (!maxCheck.ok) return maxCheck;

  return { ok: true, editing, h1Id, h2Id, h3Id, credits };
}

function canSaveCourse() {
  return validateCourseSubmit().ok;
}

function updateCourseSaveButtonState() {
  const btn = document.getElementById('btn-save-course');
  if (btn) btn.disabled = false;
}

/* ── Course modal Step 2 CLO / Step 3 SLT ── */
const BLOOM_LEVELS = ['C1', 'C2', 'C3', 'C4', 'A1', 'A2', 'A3', 'P1', 'P2'];
const TEACHING_METHODS = ['Lecture', 'Tutorial', 'Practical', 'Seminar', 'Workshop', 'Others'];
const ASSESSMENT_METHODS = [
  'Assignments', 'Quiz', 'Mid-term Examination', 'Practical Test',
  'Lab Report', 'Presentation', 'Project', 'Coursework', 'Examination'
];

function getCloMethodValue(value) {
  if (Array.isArray(value)) return value[0] || '';
  return value || '';
}

function formatCloMethodDisplay(value) {
  if (Array.isArray(value)) return value.join(', ');
  return value || '';
}
const CONTINUOUS_ASSESSMENT_TYPES = ['Coursework', 'Midterm Examination', 'Quiz', 'Assignment'];
const FINAL_ASSESSMENT_TYPES = ['Final Examination', 'Project', 'Portfolio'];

let courseModalStep = 1;
let courseModalReadonly = false;
let courseModalDraft = null;
let editingCloId = null;
let editingSltOutlineId = null;
let sltAssessmentFormKind = 'continuous';
let editingSltAssessmentId = null;

function getDefaultCourseClos() {
  return [
    { id: 'clo-1', code: 'CLO1', outcome: 'Explain the basic theories and laws of mechanics', bloom: 'C1', teaching: 'Lecture', assessment: 'Coursework' },
    { id: 'clo-2', code: 'CLO2', outcome: "Apply Newton's laws of motion to solve problems quantitatively using mathematical techniques", bloom: 'C2', teaching: 'Lecture', assessment: 'Examination' },
    { id: 'clo-3', code: 'CLO3', outcome: 'Analyze conservation of energy and momentum in physical systems', bloom: 'A3', teaching: 'Tutorial', assessment: 'Coursework' },
    { id: 'clo-4', code: 'CLO4', outcome: 'Evaluate rotational dynamics and gravitation concepts', bloom: 'C2', teaching: 'Lecture', assessment: 'Examination' },
    { id: 'clo-5', code: 'CLO5', outcome: 'Design experiments to investigate wave phenomena and oscillations', bloom: 'P2', teaching: 'Practical', assessment: 'Lab Report' },
    { id: 'clo-6', code: 'CLO6', outcome: 'Compare classical mechanics with an introduction to special relativity', bloom: 'C2', teaching: 'Lecture', assessment: 'Examination' }
  ];
}

function getDefaultCourseSlt() {
  return {
    outlines: [
      { id: 'slt-o1', content: '1. Kinematics', subtopics: ['Displacement and vectors', 'Circular motion', 'Relative motion'], cloCodes: ['CLO1', 'CLO2', 'CLO3', 'CLO4'], f2fPhysical: { L: 5, T: 1, P: 1, O: 0 }, f2fOnline: { L: 0, T: 0, P: 0, O: 0 }, nf2f: 8 },
      { id: 'slt-o2', content: '2. Dynamics', subtopics: ['Newton laws', 'Friction', 'Circular dynamics'], cloCodes: ['CLO1', 'CLO2'], f2fPhysical: { L: 4, T: 1, P: 0, O: 0 }, f2fOnline: { L: 0, T: 0, P: 0, O: 0 }, nf2f: 6 },
      { id: 'slt-o3', content: '3. Energy and Momentum', subtopics: ['Work and energy', 'Conservation laws'], cloCodes: ['CLO3'], f2fPhysical: { L: 3, T: 1, P: 1, O: 0 }, f2fOnline: { L: 0, T: 0, P: 0, O: 0 }, nf2f: 5 },
      { id: 'slt-o4', content: '4. Rotational Motion', subtopics: ['Torque', 'Angular momentum'], cloCodes: ['CLO4', 'CLO5'], f2fPhysical: { L: 3, T: 0, P: 1, O: 0 }, f2fOnline: { L: 0, T: 0, P: 0, O: 0 }, nf2f: 4 }
    ],
    continuous: [
      { id: 'slt-c1', type: 'Coursework', percent: 30, f2fPhysical: 0, f2fOnline: 0, nf2f: 20 },
      { id: 'slt-c2', type: 'Midterm Examination', percent: 30, f2fPhysical: 2, f2fOnline: 0, nf2f: 8 }
    ],
    final: [
      { id: 'slt-f1', type: 'Final Examination', percent: 40, f2fPhysical: 2, f2fOnline: 0, nf2f: 10 }
    ]
  };
}

function initCourseModalDraft(pc) {
  courseModalDraft = pc
    ? {
        clos: JSON.parse(JSON.stringify(pc.clos || getDefaultCourseClos())),
        slt: JSON.parse(JSON.stringify(pc.slt || getDefaultCourseSlt()))
      }
    : { clos: [], slt: { outlines: [], continuous: [], final: [] } };
}

function persistCourseDraftTo(pc) {
  if (!courseModalDraft) return;
  pc.clos = JSON.parse(JSON.stringify(courseModalDraft.clos));
  pc.slt = JSON.parse(JSON.stringify(courseModalDraft.slt));
}

function setCourseModalStep(step) {
  courseModalStep = step;
  [1, 2, 3].forEach(n => {
    const panel = document.getElementById(`course-step-panel-${n}`);
    if (panel) panel.hidden = n !== step;
    const stepEl = document.querySelector(`#course-modal-step-bar .step[data-step="${n}"]`);
    if (stepEl) stepEl.classList.toggle('active', n === step);
  });
  const prev = document.getElementById('btn-course-prev');
  const next = document.getElementById('btn-course-next');
  if (prev) prev.style.display = step > 1 ? '' : 'none';
  if (next) {
    if (step === 1) next.textContent = '下一步：CLO →';
    else if (step === 2) next.textContent = '下一步：SLT →';
    else next.style.display = 'none';
  }
  if (next && step < 3) next.style.display = '';
  if (step === 2) renderCloTable();
  if (step === 3) renderSltAll();
}

function courseModalNextStep() {
  if (courseModalStep === 1 && !courseModalReadonly) {
    const check = validateCourseSubmit();
    if (!check.ok) {
      alert(check.message);
      return;
    }
  }
  if (courseModalStep < 3) setCourseModalStep(courseModalStep + 1);
}

function courseModalGoToStep(step) {
  if (step < 1 || step > 3) return;
  if (courseModalReadonly || step <= courseModalStep) {
    setCourseModalStep(step);
    return;
  }
  if (courseModalStep === 1 && step > 1) {
    const check = validateCourseSubmit();
    if (!check.ok) {
      alert(check.message);
      return;
    }
  }
  setCourseModalStep(step);
}

function courseModalPrevStep() {
  if (courseModalStep > 1) setCourseModalStep(courseModalStep - 1);
}

function nextCloCode() {
  const n = (courseModalDraft?.clos?.length || 0) + 1;
  return `CLO${n}`;
}

function sumLtObj(obj) {
  return Object.values(obj || {}).reduce((s, v) => s + (Number(v) || 0), 0);
}

function calcOutlineRowTotal(row) {
  return sumLtObj(row.f2fPhysical) + sumLtObj(row.f2fOnline) + (Number(row.nf2f) || 0);
}

function calcAssessmentRowTotal(row) {
  return (Number(row.f2fPhysical) || 0) + (Number(row.f2fOnline) || 0) + (Number(row.nf2f) || 0);
}

function renderCloTable() {
  const tbody = document.getElementById('clo-table-body');
  if (!tbody || !courseModalDraft) return;
  const clos = courseModalDraft.clos;
  const readonly = courseModalReadonly;
  tbody.innerHTML = clos.length ? clos.map((c, i) => `
    <tr>
      ${readonly ? '' : `<td class="col-check"><input type="checkbox" class="clo-row-check" value="${c.id}" onchange="updateCloDeleteBtn()"></td>`}
      <td>${i + 1}</td>
      <td>${escapeHtml(c.code)}</td>
      <td>${escapeHtml(c.outcome)}</td>
      <td>${escapeHtml(c.bloom)}</td>
      <td>${escapeHtml(formatCloMethodDisplay(c.teaching))}</td>
      <td>${escapeHtml(formatCloMethodDisplay(c.assessment))}</td>
      <td class="actions">${readonly ? '<span class="text-muted">—</span>' : `<a href="#" onclick="event.preventDefault();openCloModal('${c.id}')">Edit</a><a href="#" class="danger" onclick="event.preventDefault();deleteClo('${c.id}')">Delete</a>`}</td>
    </tr>`).join('') : `<tr><td colspan="8" class="empty-cell">暂无 CLO${readonly ? '' : '，点击 Create 新增'}</td></tr>`;
  const all = document.getElementById('clo-check-all');
  if (all) {
    all.checked = false;
    all.closest('th')?.classList.toggle('col-check-hidden', readonly);
  }
  updateCloDeleteBtn();
}

function updateCloDeleteBtn() {
  const btn = document.getElementById('btn-clo-delete');
  const checked = document.querySelectorAll('.clo-row-check:checked').length;
  if (btn) btn.disabled = checked === 0;
}

function toggleAllCloCheck(checked) {
  document.querySelectorAll('.clo-row-check').forEach(cb => { cb.checked = checked; });
  updateCloDeleteBtn();
}

function populateCloFormSelects() {
  const bloom = document.getElementById('clo-bloom-select');
  const teach = document.getElementById('clo-teaching-select');
  const assess = document.getElementById('clo-assessment-select');
  if (bloom) bloom.innerHTML = '<option value="">please select</option>' + BLOOM_LEVELS.map(v => `<option value="${v}">${v}</option>`).join('');
  if (teach) teach.innerHTML = '<option value="">please select</option>' + TEACHING_METHODS.map(v => `<option value="${v}">${v}</option>`).join('');
  if (assess) assess.innerHTML = '<option value="">please select</option>' + ASSESSMENT_METHODS.map(v => `<option value="${v}">${v}</option>`).join('');
}

function openCloModal(id) {
  if (versionEditReadonly) return;
  editingCloId = id || null;
  populateCloFormSelects();
  const title = document.getElementById('clo-form-title');
  const code = document.getElementById('clo-code-input');
  const outcome = document.getElementById('clo-outcome-input');
  const bloom = document.getElementById('clo-bloom-select');
  const teach = document.getElementById('clo-teaching-select');
  const assess = document.getElementById('clo-assessment-select');
  if (id) {
    const c = courseModalDraft.clos.find(x => x.id === id);
    if (!c) return;
    if (title) title.textContent = 'Edit';
    if (code) code.value = c.code;
    if (outcome) outcome.value = c.outcome;
    if (bloom) bloom.value = c.bloom;
    if (teach) teach.value = getCloMethodValue(c.teaching);
    if (assess) assess.value = getCloMethodValue(c.assessment);
  } else {
    if (title) title.textContent = 'Create';
    if (code) code.value = nextCloCode();
    if (outcome) outcome.value = '';
    if (bloom) bloom.value = '';
    if (teach) teach.value = '';
    if (assess) assess.value = '';
  }
  updateCloOutcomeCount();
  openModal('modal-clo-form');
}

function updateCloOutcomeCount() {
  const ta = document.getElementById('clo-outcome-input');
  const el = document.getElementById('clo-outcome-count');
  if (ta && el) el.textContent = `${ta.value.length}/100`;
}

function confirmCloForm() {
  const code = document.getElementById('clo-code-input')?.value.trim();
  const outcome = document.getElementById('clo-outcome-input')?.value.trim();
  const bloom = document.getElementById('clo-bloom-select')?.value;
  const teach = document.getElementById('clo-teaching-select')?.value;
  const assess = document.getElementById('clo-assessment-select')?.value;
  if (!code || !outcome || !bloom || !teach || !assess) {
    alert('请填写所有必填项');
    return;
  }
  if (editingCloId) {
    const c = courseModalDraft.clos.find(x => x.id === editingCloId);
    if (c) Object.assign(c, { code, outcome, bloom, teaching: teach, assessment: assess });
  } else {
    courseModalDraft.clos.push({
      id: `clo-${Date.now()}`, code, outcome, bloom, teaching: teach, assessment: assess
    });
  }
  closeModal('modal-clo-form');
  renderCloTable();
  if (courseModalStep === 3) renderSltAll();
}

function deleteClo(id) {
  if (versionEditReadonly) return;
  const c = courseModalDraft?.clos?.find(x => x.id === id);
  openDeleteConfirm({
    title: '删除 CLO',
    message: `确定删除 <strong>${escapeHtml(c?.code || '该 CLO')}</strong> 吗？此操作不可撤销。`,
    hint: c?.outcome ? `Outcome：${c.outcome.slice(0, 60)}${c.outcome.length > 60 ? '…' : ''}` : '',
    onConfirm: () => {
      courseModalDraft.clos = courseModalDraft.clos.filter(x => x.id !== id);
      renderCloTable();
      if (courseModalStep === 3) renderSltAll();
    }
  });
}

function deleteSelectedClos() {
  if (versionEditReadonly) return;
  const ids = [...document.querySelectorAll('.clo-row-check:checked')].map(cb => cb.value);
  if (!ids.length) return;
  openDeleteConfirm({
    title: '批量删除 CLO',
    message: `确定删除选中的 <strong>${ids.length}</strong> 条 CLO 吗？此操作不可撤销。`,
    onConfirm: () => {
      courseModalDraft.clos = courseModalDraft.clos.filter(c => !ids.includes(c.id));
      renderCloTable();
      if (courseModalStep === 3) renderSltAll();
    }
  });
}

function toggleSltSection(key) {
  const map = { outline: 'slt-section-outline', continuous: 'slt-section-continuous', final: 'slt-section-final' };
  const sec = document.getElementById(map[key]);
  if (!sec) return;
  sec.classList.toggle('open');
  const toggle = sec.querySelector('.slt-toggle');
  const body = sec.querySelector('.slt-section-body');
  const open = sec.classList.contains('open');
  if (toggle) toggle.textContent = open ? '▼' : '▶';
  if (body) body.hidden = !open;
}

function toggleSltInfoTip(event) {
  event.stopPropagation();
  const tip = event.currentTarget?.closest('.slt-info-tip');
  if (!tip) return;
  document.querySelectorAll('.slt-info-tip.open').forEach(el => {
    if (el !== tip) el.classList.remove('open');
  });
  tip.classList.toggle('open');
}

function closeSltInfoTip() {
  document.querySelectorAll('.slt-info-tip.open').forEach(el => el.classList.remove('open'));
}

function renderSltAll() {
  renderSltOutlineTable();
  renderSltAssessmentTable('continuous');
  renderSltAssessmentTable('final');
  renderSltSummary();
}

function renderSltOutlineTable() {
  const tbody = document.getElementById('slt-outline-body');
  const tfoot = document.getElementById('slt-outline-foot');
  if (!tbody || !courseModalDraft) return;
  const rows = courseModalDraft.slt.outlines;
  const readonly = courseModalReadonly;
  tbody.innerHTML = rows.length ? rows.map((r, i) => {
    const p = r.f2fPhysical || {};
    const o = r.f2fOnline || {};
    const subHtml = (r.subtopics || []).length
      ? `<ul class="outline-subtopics">${r.subtopics.map(s => `<li>${escapeHtml(s)}</li>`).join('')}</ul>` : '';
    const actions = readonly
      ? '<span class="text-muted">—</span>'
      : `<a href="#" onclick="event.preventDefault();openSltOutlineModal('${r.id}')">Edit</a><a href="#" class="danger" onclick="event.preventDefault();deleteSltOutline('${r.id}')">Delete</a>`;
    return `<tr>
      <td class="num-cell">${i + 1}</td>
      <td><div class="outline-content">${escapeHtml(r.content)}</div>${subHtml}</td>
      <td>${escapeHtml((r.cloCodes || []).join(', '))}</td>
      <td class="num-cell">${p.L || 0}</td><td class="num-cell">${p.T || 0}</td><td class="num-cell">${p.P || 0}</td><td class="num-cell">${p.O || 0}</td>
      <td class="num-cell">${o.L || 0}</td><td class="num-cell">${o.T || 0}</td><td class="num-cell">${o.P || 0}</td><td class="num-cell">${o.O || 0}</td>
      <td class="num-cell">${r.nf2f || 0}</td>
      <td class="num-cell"><strong>${calcOutlineRowTotal(r)}</strong></td>
      <td class="actions">${actions}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="14" class="empty-cell">暂无大纲条目</td></tr>`;

  if (tfoot) {
    if (!rows.length) {
      tfoot.innerHTML = '';
    } else {
      const tot = rows.reduce((acc, r) => {
        const p = r.f2fPhysical || {};
        const o = r.f2fOnline || {};
        acc.pL += Number(p.L) || 0;
        acc.pT += Number(p.T) || 0;
        acc.pP += Number(p.P) || 0;
        acc.pO += Number(p.O) || 0;
        acc.oL += Number(o.L) || 0;
        acc.oT += Number(o.T) || 0;
        acc.oP += Number(o.P) || 0;
        acc.oO += Number(o.O) || 0;
        acc.nf2f += Number(r.nf2f) || 0;
        acc.slt += calcOutlineRowTotal(r);
        return acc;
      }, { pL: 0, pT: 0, pP: 0, pO: 0, oL: 0, oT: 0, oP: 0, oO: 0, nf2f: 0, slt: 0 });
      tfoot.innerHTML = `<tr class="slt-total-row">
        <td colspan="3" class="slt-total-label">Total</td>
        <td class="num-cell">${tot.pL}</td><td class="num-cell">${tot.pT}</td><td class="num-cell">${tot.pP}</td><td class="num-cell">${tot.pO}</td>
        <td class="num-cell">${tot.oL}</td><td class="num-cell">${tot.oT}</td><td class="num-cell">${tot.oP}</td><td class="num-cell">${tot.oO}</td>
        <td class="num-cell">${tot.nf2f}</td>
        <td class="num-cell">${tot.slt}</td>
        <td></td>
      </tr>`;
    }
  }
}

function renderSltAssessmentTable(kind) {
  const tbody = document.getElementById(`slt-${kind}-body`);
  const tfoot = document.getElementById(`slt-${kind}-foot`);
  if (!tbody || !courseModalDraft) return;
  const rows = courseModalDraft.slt[kind] || [];
  const readonly = courseModalReadonly;
  tbody.innerHTML = rows.length ? rows.map((r, i) => {
    const actions = readonly
      ? '<span class="text-muted">—</span>'
      : `<a href="#" onclick="event.preventDefault();openSltAssessmentModal('${kind}','${r.id}')">Edit</a><a href="#" class="danger" onclick="event.preventDefault();deleteSltAssessment('${kind}','${r.id}')">Delete</a>`;
    return `
    <tr>
      <td class="num-cell">${i + 1}</td>
      <td>${escapeHtml(r.type)}</td>
      <td class="num-cell">${r.percent}%</td>
      <td class="num-cell">${r.f2fPhysical || 0}</td>
      <td class="num-cell">${r.f2fOnline || 0}</td>
      <td class="num-cell">${r.nf2f || 0}</td>
      <td class="num-cell"><strong>${calcAssessmentRowTotal(r)}</strong></td>
      <td class="actions">${actions}</td>
    </tr>`;
  }).join('') : `<tr><td colspan="8" class="empty-cell">暂无数据</td></tr>`;
  if (tfoot) {
    const totPct = rows.reduce((s, r) => s + (Number(r.percent) || 0), 0);
    const totPhys = rows.reduce((s, r) => s + (Number(r.f2fPhysical) || 0), 0);
    const totOnline = rows.reduce((s, r) => s + (Number(r.f2fOnline) || 0), 0);
    const totNf2f = rows.reduce((s, r) => s + (Number(r.nf2f) || 0), 0);
    const totSlt = rows.reduce((s, r) => s + calcAssessmentRowTotal(r), 0);
    tfoot.innerHTML = rows.length ? `<tr class="slt-total-row">
      <td></td>
      <td class="slt-total-label">Total</td>
      <td class="num-cell">${totPct}</td>
      <td class="num-cell">${totPhys}</td>
      <td class="num-cell">${totOnline}</td>
      <td class="num-cell">${totNf2f}</td>
      <td class="num-cell">${totSlt}</td>
      <td></td>
    </tr>` : '';
  }
}

function renderSltSummary() {
  if (!courseModalDraft) return;
  const outlineTotal = courseModalDraft.slt.outlines.reduce((s, r) => s + calcOutlineRowTotal(r), 0);
  const contTotal = (courseModalDraft.slt.continuous || []).reduce((s, r) => s + calcAssessmentRowTotal(r), 0);
  const finalTotal = (courseModalDraft.slt.final || []).reduce((s, r) => s + calcAssessmentRowTotal(r), 0);
  const assessTotal = contTotal + finalTotal;
  const grandTotal = outlineTotal + assessTotal;
  let phys = 0, online = 0, nf2f = 0;
  courseModalDraft.slt.outlines.forEach(r => {
    phys += sumLtObj(r.f2fPhysical);
    online += sumLtObj(r.f2fOnline);
    nf2f += Number(r.nf2f) || 0;
  });
  [...courseModalDraft.slt.continuous, ...courseModalDraft.slt.final].forEach(r => {
    phys += Number(r.f2fPhysical) || 0;
    online += Number(r.f2fOnline) || 0;
    nf2f += Number(r.nf2f) || 0;
  });
  const physPct = grandTotal ? Math.round((phys / grandTotal) * 100) : 0;
  const onlinePct = grandTotal ? Math.round(((online + nf2f) / grandTotal) * 100) : 0;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('slt-total', grandTotal);
  set('slt-assessment-total', assessTotal);
  set('slt-physical-pct', `${physPct}%`);
  set('slt-online-pct', `${onlinePct}%`);
}

let sltOutlineSelectedClos = [];

function populateSltOutlineCloSelect(selected) {
  const clos = courseModalDraft?.clos || [];
  const validCodes = new Set(clos.map(c => c.code));
  sltOutlineSelectedClos = [...(selected || [])].filter(c => validCodes.has(c));
  const options = document.getElementById('slt-outline-clo-options');
  const empty = document.getElementById('slt-outline-clo-empty');
  closeSltOutlineCloDropdown();

  if (!clos.length) {
    if (empty) empty.hidden = false;
    if (options) options.innerHTML = '';
  } else {
    if (empty) empty.hidden = true;
    if (options) {
      options.innerHTML = clos.map(c => `
        <label class="clo-multiselect-option">
          <input type="checkbox" value="${escapeHtml(c.code)}"
            ${sltOutlineSelectedClos.includes(c.code) ? 'checked' : ''}
            onchange="onSltOutlineCloToggle(this)">
          <span>${escapeHtml(c.code)}</span>
        </label>`).join('');
    }
  }
  updateSltOutlineCloDisplay();
}

function updateSltOutlineCloDisplay() {
  const display = document.getElementById('slt-outline-clo-display');
  if (!display) return;
  if (sltOutlineSelectedClos.length) {
    display.textContent = sltOutlineSelectedClos.join(',');
    display.classList.remove('placeholder');
  } else {
    display.textContent = 'please select';
    display.classList.add('placeholder');
  }
}

function onSltOutlineCloToggle(checkbox) {
  const code = checkbox.value;
  if (checkbox.checked) {
    if (!sltOutlineSelectedClos.includes(code)) sltOutlineSelectedClos.push(code);
  } else {
    sltOutlineSelectedClos = sltOutlineSelectedClos.filter(c => c !== code);
  }
  const order = (courseModalDraft?.clos || []).map(c => c.code);
  sltOutlineSelectedClos.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  updateSltOutlineCloDisplay();
}

function toggleSltOutlineCloDropdown(event) {
  event.stopPropagation();
  const dd = document.getElementById('slt-outline-clo-dropdown');
  if (!dd) return;
  const willOpen = dd.hidden;
  closeSltOutlineCloDropdown();
  if (willOpen) dd.hidden = false;
}

function closeSltOutlineCloDropdown() {
  const dd = document.getElementById('slt-outline-clo-dropdown');
  if (dd) dd.hidden = true;
}

function getSltOutlineSelectedCloCodes() {
  return [...sltOutlineSelectedClos];
}

function readLtField(prefix) {
  const modal = document.getElementById('modal-slt-outline-form');
  const get = key => Number(modal?.querySelector(`[data-lt="${prefix}-${key}"]`)?.value) || 0;
  return { L: get('L'), T: get('T'), P: get('P'), O: get('O') };
}

function setLtField(prefix, obj) {
  const modal = document.getElementById('modal-slt-outline-form');
  ['L', 'T', 'P', 'O'].forEach(k => {
    const el = modal?.querySelector(`[data-lt="${prefix}-${k}"]`);
    if (el) el.value = obj?.[k] ?? 0;
  });
}

function updateSltOutlineLtTotal() {
  const phys = readLtField('phys');
  const online = readLtField('online');
  const nf2f = Number(document.getElementById('slt-outline-nf2f')?.value) || 0;
  const total = sumLtObj(phys) + sumLtObj(online) + nf2f;
  const el = document.getElementById('slt-outline-lt-total');
  if (el) el.textContent = total;
}

function updateSltOutlineContentCount() {
  const ta = document.getElementById('slt-outline-content');
  const el = document.getElementById('slt-outline-content-count');
  if (ta && el) el.textContent = `${ta.value.length}/100`;
}

function openSltOutlineModal(id) {
  if (versionEditReadonly) return;
  editingSltOutlineId = id || null;
  const content = document.getElementById('slt-outline-content');
  const subtopics = document.getElementById('slt-outline-subtopics');
  const nf2f = document.getElementById('slt-outline-nf2f');
  const title = document.getElementById('slt-outline-form-title');
  if (id) {
    const r = courseModalDraft.slt.outlines.find(x => x.id === id);
    if (!r) return;
    if (title) title.textContent = 'Edit Course Content Outline and Subtopics';
    if (content) content.value = r.content;
    if (subtopics) subtopics.value = (r.subtopics || []).join('\n');
    populateSltOutlineCloSelect(r.cloCodes);
    setLtField('phys', r.f2fPhysical);
    setLtField('online', r.f2fOnline);
    if (nf2f) nf2f.value = r.nf2f || 0;
  } else {
    if (title) title.textContent = 'Create Course Content Outline and Subtopics';
    if (content) content.value = '';
    if (subtopics) subtopics.value = '';
    populateSltOutlineCloSelect([]);
    setLtField('phys', { L: 0, T: 0, P: 0, O: 0 });
    setLtField('online', { L: 0, T: 0, P: 0, O: 0 });
    if (nf2f) nf2f.value = 0;
  }
  updateSltOutlineContentCount();
  updateSltOutlineLtTotal();
  openModal('modal-slt-outline-form');
}

function confirmSltOutlineForm() {
  const content = document.getElementById('slt-outline-content')?.value.trim();
  const subRaw = document.getElementById('slt-outline-subtopics')?.value || '';
  const cloCodes = getSltOutlineSelectedCloCodes();
  const nf2f = Number(document.getElementById('slt-outline-nf2f')?.value) || 0;
  if (!(courseModalDraft?.clos || []).length) {
    alert('请先在 Step 2 创建 CLO，再关联大纲条目');
    return;
  }
  if (!content || !cloCodes.length) {
    alert('请填写 Course Content 并选择 CLO');
    return;
  }
  const row = {
    content,
    subtopics: subRaw.split('\n').map(s => s.trim()).filter(Boolean),
    cloCodes,
    f2fPhysical: readLtField('phys'),
    f2fOnline: readLtField('online'),
    nf2f
  };
  if (editingSltOutlineId) {
    const r = courseModalDraft.slt.outlines.find(x => x.id === editingSltOutlineId);
    if (r) Object.assign(r, row);
  } else {
    row.id = `slt-o-${Date.now()}`;
    courseModalDraft.slt.outlines.push(row);
  }
  closeModal('modal-slt-outline-form');
  renderSltAll();
}

function deleteSltOutline(id) {
  if (versionEditReadonly) return;
  const r = courseModalDraft?.slt?.outlines?.find(x => x.id === id);
  openDeleteConfirm({
    title: '删除大纲条目',
    message: `确定删除该 Course Content Outline 条目吗？此操作不可撤销。`,
    hint: r?.content ? `内容：${r.content.slice(0, 80)}${r.content.length > 80 ? '…' : ''}` : '',
    onConfirm: () => {
      courseModalDraft.slt.outlines = courseModalDraft.slt.outlines.filter(x => x.id !== id);
      renderSltAll();
    }
  });
}

function getAssessmentPercentTotal(excludeKind, excludeId) {
  let total = 0;
  ['continuous', 'final'].forEach(kind => {
    (courseModalDraft?.slt?.[kind] || []).forEach(r => {
      if (kind === excludeKind && r.id === excludeId) return;
      total += Number(r.percent) || 0;
    });
  });
  return total;
}

function getAssessmentPercentRemaining(excludeKind, excludeId) {
  return Math.max(0, 100 - getAssessmentPercentTotal(excludeKind, excludeId));
}

function updateSltAssessmentPctHint() {
  const pctInput = document.getElementById('slt-assessment-pct');
  const hint = document.getElementById('slt-assessment-pct-hint');
  if (!pctInput || !hint) return;
  const remaining = getAssessmentPercentRemaining(sltAssessmentFormKind, editingSltAssessmentId);
  const used = 100 - remaining;
  const val = Number(pctInput.value);
  if (Number.isNaN(val) || val < 0 || val > 100) {
    hint.textContent = '百分比须在 0–100 之间';
    hint.className = 'form-hint pct-hint error';
    pctInput.classList.add('input-error');
    return;
  }
  if (val > remaining) {
    hint.textContent = `过程性考核 + 期末考核合计不得超过 100%（已用 ${used}%，最多还可填 ${remaining}%）`;
    hint.className = 'form-hint pct-hint error';
    pctInput.classList.add('input-error');
    return;
  }
  hint.textContent = `过程性考核 + 期末考核合计须为 100%（已用 ${used}%，剩余 ${remaining}%）`;
  hint.className = 'form-hint pct-hint';
  pctInput.classList.remove('input-error');
}

function validateAssessmentPercent(percent) {
  if (Number.isNaN(percent) || percent < 0 || percent > 100) {
    return '百分比须在 0–100 之间';
  }
  const remaining = getAssessmentPercentRemaining(sltAssessmentFormKind, editingSltAssessmentId);
  if (percent > remaining) {
    const used = 100 - remaining;
    return `过程性考核与期末考核合计不得超过 100%（已用 ${used}%，最多还可填 ${remaining}%）`;
  }
  return null;
}

function updateSltAssessmentLtTotal() {
  const phys = Number(document.getElementById('slt-assessment-phys')?.value) || 0;
  const online = Number(document.getElementById('slt-assessment-online')?.value) || 0;
  const nf2f = Number(document.getElementById('slt-assessment-nf2f')?.value) || 0;
  const el = document.getElementById('slt-assessment-lt-total');
  if (el) el.textContent = phys + online + nf2f;
}

function openSltAssessmentModal(kind, id) {
  if (versionEditReadonly) return;
  sltAssessmentFormKind = kind;
  editingSltAssessmentId = id || null;
  const title = document.getElementById('slt-assessment-form-title');
  const typeLabel = document.getElementById('slt-assessment-type-label');
  const typeSel = document.getElementById('slt-assessment-type-select');
  const pct = document.getElementById('slt-assessment-pct');
  const phys = document.getElementById('slt-assessment-phys');
  const online = document.getElementById('slt-assessment-online');
  const nf2f = document.getElementById('slt-assessment-nf2f');
  const types = kind === 'final' ? FINAL_ASSESSMENT_TYPES : CONTINUOUS_ASSESSMENT_TYPES;
  if (title) title.textContent = id
    ? (kind === 'final' ? 'Edit Final Assessment' : 'Edit Continuous Assessment')
    : (kind === 'final' ? 'Create Final Assessment' : 'Create Continuous Assessment');
  if (typeLabel) typeLabel.textContent = kind === 'final' ? 'Final Assessment' : 'Continuous Assessment';
  if (typeSel) typeSel.innerHTML = '<option value="">please select</option>' + types.map(t => `<option value="${t}">${t}</option>`).join('');
  if (id) {
    const r = courseModalDraft.slt[kind].find(x => x.id === id);
    if (!r) return;
    if (typeSel) typeSel.value = r.type;
    if (pct) pct.value = r.percent;
    if (phys) phys.value = r.f2fPhysical || 0;
    if (online) online.value = r.f2fOnline || 0;
    if (nf2f) nf2f.value = r.nf2f || 0;
  } else {
    if (typeSel) typeSel.value = '';
    if (pct) pct.value = 0;
    if (phys) phys.value = 0;
    if (online) online.value = 0;
    if (nf2f) nf2f.value = 0;
  }
  updateSltAssessmentLtTotal();
  updateSltAssessmentPctHint();
  openModal('modal-slt-assessment-form');
}

function confirmSltAssessmentForm() {
  const type = document.getElementById('slt-assessment-type-select')?.value;
  const percent = Number(document.getElementById('slt-assessment-pct')?.value);
  const f2fPhysical = Number(document.getElementById('slt-assessment-phys')?.value) || 0;
  const f2fOnline = Number(document.getElementById('slt-assessment-online')?.value) || 0;
  const nf2f = Number(document.getElementById('slt-assessment-nf2f')?.value) || 0;
  if (!type) {
    alert('请选择考核类型');
    return;
  }
  const pctError = validateAssessmentPercent(percent);
  if (pctError) {
    alert(pctError);
    updateSltAssessmentPctHint();
    return;
  }
  const row = { type, percent, f2fPhysical, f2fOnline, nf2f };
  const list = courseModalDraft.slt[sltAssessmentFormKind];
  if (editingSltAssessmentId) {
    const r = list.find(x => x.id === editingSltAssessmentId);
    if (r) Object.assign(r, row);
  } else {
    row.id = `slt-${sltAssessmentFormKind[0]}-${Date.now()}`;
    list.push(row);
  }
  closeModal('modal-slt-assessment-form');
  renderSltAll();
}

function deleteSltAssessment(kind, id) {
  if (versionEditReadonly) return;
  const r = courseModalDraft?.slt?.[kind]?.find(x => x.id === id);
  const kindLabel = kind === 'final' ? 'Final Assessment' : 'Continuous Assessment';
  openDeleteConfirm({
    title: `删除${kind === 'final' ? '期末' : '过程性'}考核`,
    message: `确定删除该 <strong>${kindLabel}</strong> 条目吗？此操作不可撤销。`,
    hint: r?.type ? `${r.type} · ${r.percent}%` : '',
    onConfirm: () => {
      courseModalDraft.slt[kind] = courseModalDraft.slt[kind].filter(x => x.id !== id);
      renderSltAll();
    }
  });
}

function openCourseModal(mode, programCourseId) {
  if (mode !== 'view' && versionEditReadonly) return;
  if (mode === 'add') {
    if (!hasCourseClassificationOptions()) {
      alert('请先在 TAB1 课程分类中建设分类（至少包含一级与二级），否则无法新增课程。');
      return;
    }
  }
  refreshCourseClassificationSelects();
  if (mode !== 'view' && !hasCourseClassificationOptions()) return;

  courseModalReadonly = mode === 'view';
  editingProgramCourseId = (mode === 'edit' || mode === 'view') ? programCourseId : null;
  const title = document.getElementById('modal-course-title');
  cancelCoursePicker();

  if (mode === 'edit' || mode === 'view') {
    const pc = findProgramCourse(programCourseId);
    if (!pc) return;
    if (title) title.textContent = mode === 'view' ? '查看课程' : '编辑课程';
    setCoursePickerSectionVisible(false);
    fillCourseFormFromProgramCourse(pc);
    initCourseModalDraft(pc);
    updateCourseSaveButtonState();
  } else {
    if (title) title.textContent = '新增课程';
    setCoursePickerSectionVisible(true);
    resetCoursePicker();
    initSemesterSelects();
    syncOfferingSemesterControl();
    initCourseModalDraft(null);
  }
  applyCourseModalReadonly(courseModalReadonly);
  setCourseModalStep(1);
  openModal('modal-add-course');
}

function applyCourseModalReadonly(readonly) {
  courseModalReadonly = readonly;
  const modal = document.getElementById('modal-add-course');
  if (modal) modal.classList.toggle('course-modal-readonly', readonly);
  const saveBtn = document.getElementById('btn-save-course');
  if (saveBtn) saveBtn.style.display = readonly ? 'none' : '';
  const cancelBtn = modal?.querySelector('.modal-foot .btn-ghost');
  if (cancelBtn) cancelBtn.textContent = readonly ? '关闭' : '取消';
  const cloToolbar = document.querySelector('#course-step-panel-2 .course-step-toolbar');
  if (cloToolbar) cloToolbar.style.display = readonly ? 'none' : '';
  modal?.querySelectorAll('#course-step-panel-3 .slt-section-head .btn-primary').forEach(btn => {
    btn.style.display = readonly ? 'none' : '';
  });
  modal?.querySelectorAll('#course-form-details input, #course-form-details select, #course-form-details textarea').forEach(el => {
    el.disabled = readonly;
  });
  const offeringToggle = document.getElementById('offering-semester-enabled');
  if (offeringToggle) offeringToggle.disabled = readonly;
  const offeringSelect = document.getElementById('offering-semester-select');
  if (offeringSelect && readonly) offeringSelect.disabled = true;
  modal?.querySelectorAll('#course-picker-section button, #course-form-details .input-group button').forEach(btn => {
    btn.style.display = readonly ? 'none' : '';
  });
  if (courseModalDraft) {
    if (courseModalStep === 2) renderCloTable();
    if (courseModalStep === 3) renderSltAll();
  }
}

function openAddCourseModal() {
  openCourseModal('add');
}

function openEditProgramCourse(id) {
  openCourseModal('edit', id);
}

function openViewProgramCourse(id) {
  openCourseModal('view', id);
}

function saveCourse() {
  if (courseModalReadonly) return;
  const check = validateCourseSubmit();
  if (!check.ok) {
    alert(check.message);
    return;
  }

  const { editing, h1Id, h2Id, h3Id } = check;

  if (editing) {
    readCourseFormIntoProgramCourse(editing);
    persistCourseDraftTo(editing);
    renderProgramCoursesTable();
  } else {
    const pc = createProgramCourseFromCatalog(selectedCatalogCourseId, {
      h1Id,
      h2Id,
      h3Id,
      semester: (isCourseFormCompulsory() || isOfferingSemesterEnabled())
        ? document.getElementById('offering-semester-select')?.value
        : null
    });
    if (!pc) return;
    pc.prereqIds = [...selectedPrereqCourseIds];
    pc.synopsis = document.getElementById('course-synopsis-input')?.value || pc.synopsis;
    pc.references = document.getElementById('course-refs-input')?.value || pc.references;
    pc.language = document.getElementById('course-language-select')?.value || pc.language;
    const creditsInput = document.getElementById('course-credits-input')?.value;
    if (creditsInput !== '') pc.credits = Number(creditsInput);
    persistCourseDraftTo(pc);
    PROGRAM_COURSES.push(pc);
    renderProgramCoursesTable();
  }
  editingProgramCourseId = null;
  closeModal('modal-add-course');
  alert('课程已提交（原型）');
}

function refreshBatchCourseClassificationSelects() {
  const h1 = document.getElementById('batch-course-h1-select');
  const h2 = document.getElementById('batch-course-h2-select');
  const h3 = document.getElementById('batch-course-h3-select');
  if (!h1 || !h2 || !h3) return false;

  const l1List = CLASSIFICATION_TREE.filter(l1 => l1.children?.length);
  if (!l1List.length) {
    h1.innerHTML = '<option value="">暂无分类</option>';
    h2.innerHTML = '<option value="">暂无分类</option>';
    h3.innerHTML = '<option value="">—</option>';
    h1.disabled = h2.disabled = h3.disabled = true;
    updateBatchCourseH3FieldState(false);
    return false;
  }

  h1.disabled = false;
  h1.innerHTML = l1List.map(l1 => `<option value="${l1.id}">${escapeHtml(l1.name)}</option>`).join('');
  onBatchCourseH1Change();
  return true;
}

function onBatchCourseH1Change() {
  const h1Id = document.getElementById('batch-course-h1-select')?.value;
  const h2 = document.getElementById('batch-course-h2-select');
  const l1 = findClassificationNode(h1Id);
  const l2List = l1?.children || [];
  if (!h2) return;

  if (!l2List.length) {
    h2.innerHTML = '<option value="">无二级分类</option>';
    h2.disabled = true;
  } else {
    h2.disabled = false;
    h2.innerHTML = l2List.map(l2 => `<option value="${l2.id}">${escapeHtml(l2.name)}</option>`).join('');
  }
  onBatchCourseH2Change();
  syncOfferingSemesterControl('batch');
}

function updateBatchCourseH3FieldState(hasL3) {
  const label = document.getElementById('batch-course-h3-label');
  const wrap = document.getElementById('batch-course-h3-wrap');
  const hint = document.getElementById('batch-course-h3-hint');
  if (label) label.classList.toggle('req', hasL3);
  if (wrap) wrap.classList.toggle('field-disabled', !hasL3);
  if (hint) {
    hint.textContent = hasL3 ? '该二级分类下有三级分类，请选择（必填）' : '该二级分类无三级分类，无需填写';
  }
}

function onBatchCourseH2Change() {
  const h2Id = document.getElementById('batch-course-h2-select')?.value;
  const h3 = document.getElementById('batch-course-h3-select');
  const l2 = findClassificationNode(h2Id);
  const l3List = l2?.children || [];
  if (!h3) return;

  const hasL3 = l3List.length > 0;
  updateBatchCourseH3FieldState(hasL3);

  if (!hasL3) {
    h3.innerHTML = '<option value="">—</option>';
    h3.disabled = true;
  } else {
    h3.disabled = false;
    h3.innerHTML = '<option value="">请选择</option>' +
      l3List.map(l3 => `<option value="${l3.id}">${escapeHtml(l3.name)}</option>`).join('');
  }
  updateBatchAddButtonState();
}

function isBatchCourseDisabled(id) {
  return getExistingProgramCatalogIds().has(id);
}

function formatBatchCourseDisplay(ids) {
  if (!ids.length) return '';
  const labels = ids.map(id => {
    const c = COURSE_CATALOG.find(x => x.id === id);
    return c ? `${c.code} — ${c.name}` : '';
  }).filter(Boolean);
  if (labels.length <= 3) return labels.join('；');
  return `${labels.slice(0, 2).join('；')} 等 ${labels.length} 门课程`;
}

function updateBatchCoursePickerDisplay() {
  const display = document.getElementById('batch-course-picker-display');
  const hint = document.getElementById('batch-course-picker-hint');
  if (display) display.value = formatBatchCourseDisplay(batchSelectedCatalogIds);
  if (hint) {
    hint.textContent = batchSelectedCatalogIds.length
      ? `已选 ${batchSelectedCatalogIds.length} 门课程，可点击「选择」调整`
      : '须从教务课程库选择课程；已添加至本方案的课程不可重复选择。';
  }
}

function canBatchAddCourses() {
  if (!batchSelectedCatalogIds.length) return false;
  if (!hasCourseClassificationOptions()) return false;
  const h1 = document.getElementById('batch-course-h1-select');
  const h2 = document.getElementById('batch-course-h2-select');
  const h3 = document.getElementById('batch-course-h3-select');
  if (!h1?.value || h1.disabled) return false;
  if (!h2?.value || h2.disabled) return false;
  if (h3 && !h3.disabled && !h3.value) return false;
  if (isCourseFormCompulsory('batch') || isOfferingSemesterEnabled('batch')) {
    const semester = document.getElementById('batch-offering-semester-select');
    if (!semester?.value || semester.value === '—') return false;
  }
  return true;
}

function updateBatchAddButtonState() {
  const btn = document.getElementById('btn-batch-add-course');
  if (!btn) return;
  const n = batchSelectedCatalogIds.length;
  btn.disabled = !canBatchAddCourses();
  btn.textContent = n ? `确认添加（${n} 门）` : '确认添加';
}

function openBatchAddCourseModal() {
  if (versionEditReadonly) return;
  if (!hasCourseClassificationOptions()) {
    alert('请先在 TAB1 课程分类中建设分类（至少包含一级与二级），否则无法新增课程。');
    return;
  }
  if (!refreshBatchCourseClassificationSelects()) {
    alert('请先在 TAB1 课程分类中建设分类（至少包含一级与二级），否则无法新增课程。');
    return;
  }
  batchSelectedCatalogIds = [];
  syncOfferingSemesterControl('batch');
  updateBatchCoursePickerDisplay();
  updateBatchAddButtonState();
  openModal('modal-batch-add-course');
}

function confirmBatchAddCourses() {
  if (!canBatchAddCourses()) {
    const h3 = document.getElementById('batch-course-h3-select');
    const needH3 = h3 && !h3.disabled;
    if (!batchSelectedCatalogIds.length) {
      alert('请至少选择一门课程');
    } else if (isCourseFormCompulsory('batch')) {
      alert('必修课程须指定开课学期');
    } else if (isOfferingSemesterEnabled('batch')) {
      alert(needH3 ? '请完善课程分类（H1/H2/H3）及开课学期' : '请完善课程分类（H1/H2）及开课学期');
    } else {
      alert(needH3 ? '请完善课程分类（H1/H2/H3）' : '请完善课程分类（H1/H2）');
    }
    return;
  }

  const h1Id = document.getElementById('batch-course-h1-select')?.value;
  const h2Id = document.getElementById('batch-course-h2-select')?.value;
  const h3 = document.getElementById('batch-course-h3-select');
  const h3Id = h3 && !h3.disabled && h3.value ? h3.value : null;
  const semester = (isCourseFormCompulsory('batch') || isOfferingSemesterEnabled('batch'))
    ? document.getElementById('batch-offering-semester-select')?.value
    : null;
  const existing = getExistingProgramCatalogIds();
  const toAdd = batchSelectedCatalogIds.filter(catalogId => !existing.has(catalogId));
  if (!toAdd.length) {
    alert('所选课程均已存在于本方案中。');
    return;
  }

  const batchCredits = toAdd.reduce((sum, catalogId) => {
    const cat = COURSE_CATALOG.find(c => c.id === catalogId);
    return sum + (Number(cat?.credits) || 0);
  }, 0);
  const maxCheck = validateCompulsoryCourseMaxCredits({
    h1Id,
    h2Id,
    h3Id,
    credits: batchCredits,
    excludeCourseId: null
  });
  if (!maxCheck.ok) {
    alert(maxCheck.message);
    return;
  }

  let added = 0;

  toAdd.forEach(catalogId => {
    const pc = createProgramCourseFromCatalog(catalogId, { h1Id, h2Id, h3Id, semester });
    if (!pc) return;
    PROGRAM_COURSES.push(pc);
    existing.add(catalogId);
    added++;
  });

  renderProgramCoursesTable();
  closeModal('modal-batch-add-course');
  alert(added ? `已批量添加 ${added} 门课程，可在列表中逐门编辑完善信息。` : '所选课程均已存在于本方案中。');
}

function canEditCategory(node) {
  if (node.level === 1) return false;
  return node.level === 2 || node.level === 3;
}

function canDeleteCategory(node) {
  return node.level === 2 || node.level === 3;
}

let editingCategoryId = null;
let pendingDeleteCategoryId = null;
let categoryFormMode = 'add-l2';
let parentL2CategoryId = null;

const H1_META = {
  compulsory: { id: 'l1-comp', name: 'Compulsory Courses', studyType: 'compulsory' },
  core: { id: 'l1-core', name: 'Core/Major/Specialisation', studyType: 'compulsory' },
  elective: { id: 'l1-elec', name: 'Optional/Elective Courses', studyType: 'elective', highlight: true },
  minor: { id: 'l1-minor', name: 'Minor Courses', studyType: 'elective' },
  training: { id: 'l1-training', name: 'Industrial Training/Practicum', studyType: 'compulsory' },
  others: { id: 'l1-others', name: 'Others', studyType: 'compulsory' }
};

function generateCategoryNodeId(level) {
  return `l${level}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
}

function findOrCreateL1(h1Key) {
  const meta = H1_META[h1Key];
  if (!meta) return null;
  let l1 = CLASSIFICATION_TREE.find(n => n.id === meta.id);
  if (!l1) {
    l1 = {
      id: meta.id,
      level: 1,
      name: meta.name,
      studyType: meta.studyType,
      children: [],
      highlight: meta.highlight
    };
    CLASSIFICATION_TREE.push(l1);
  }
  return l1;
}

function isCategoryL3Mode() {
  return categoryFormMode === 'add-l3' || categoryFormMode === 'edit-l3';
}

function getCategoryFormStudyType() {
  if (isCategoryL3Mode()) {
    const l2 = parentL2CategoryId
      ? findClassificationNode(parentL2CategoryId)
      : (editingCategoryId ? findL2Parent(editingCategoryId) : null);
    return l2?.studyType || 'compulsory';
  }
  return document.getElementById('study-type-select')?.value || 'compulsory';
}

function isCategoryCreditsRangeMode() {
  if (isCategoryL3Mode()) return false;
  return getCategoryFormStudyType() === 'elective';
}

function syncCategoryCreditsMaxFromMin() {
  if (isCategoryL3Mode() || isCategoryCreditsRangeMode()) return;
  const minEl = document.getElementById('category-credits-min');
  const maxEl = document.getElementById('category-credits-max');
  if (minEl && maxEl) maxEl.value = minEl.value;
}

function updateCategoryCreditsFieldsUI() {
  const panel = document.getElementById('category-form-panel');
  const minLabel = document.getElementById('category-credits-min-label');
  const maxLabel = document.getElementById('category-credits-max-label');
  const minEl = document.getElementById('category-credits-min');
  const maxEl = document.getElementById('category-credits-max');
  const isL3 = isCategoryL3Mode();
  const isRange = isCategoryCreditsRangeMode();
  const lockMax = !isL3 && !isRange;

  if (panel) {
    panel.classList.toggle('credits-range-mode', isRange);
    panel.classList.toggle('credits-locked-max-mode', lockMax);
  }
  if (minLabel) minLabel.textContent = '最低学分';
  if (maxLabel) maxLabel.textContent = '最高学分';
  if (minEl) minEl.placeholder = '最低';
  if (maxEl) {
    maxEl.placeholder = '最高';
    maxEl.disabled = lockMax;
    if (isL3) maxEl.value = '';
    else if (lockMax) syncCategoryCreditsMaxFromMin();
  }
}

function bindCategoryCreditsInputs() {
  const minEl = document.getElementById('category-credits-min');
  if (!minEl || minEl.dataset.bound) return;
  minEl.dataset.bound = '1';
  minEl.addEventListener('input', syncCategoryCreditsMaxFromMin);
}

function applyCategoryFormMode() {
  const panel = document.getElementById('category-form-panel');
  const l2Fields = document.getElementById('category-l2-fields');
  const l3Fields = document.getElementById('category-l3-fields');
  const electiveSection = document.getElementById('elective-matrix-section');
  const isL3 = isCategoryL3Mode();

  if (panel) panel.className = `category-form-panel ${isL3 ? 'mode-l3' : 'mode-l2'}`;
  if (l2Fields) l2Fields.style.display = '';
  if (l3Fields) l3Fields.style.display = '';
  if (electiveSection) {
    electiveSection.style.display = !isL3 && isElectiveStudyType() ? 'block' : 'none';
  }
  updateCategoryCreditsFieldsUI();
}

function collectElectiveMatrixRequirements() {
  const reqs = {};
  document.querySelectorAll('#elective-matrix-tbody tr[data-row]').forEach(row => {
    const semester = row.querySelector('.semester-row-select')?.value;
    const creditsMin = row.querySelector('.matrix-credit-min')?.value.trim();
    const creditsMax = row.querySelector('.matrix-credit-max')?.value.trim();
    const count = row.querySelector('.matrix-count')?.value.trim();
    if (!semester) return;
    reqs[semester] = {
      creditsMin: creditsMin !== '' ? Number(creditsMin) : '',
      creditsMax: creditsMax !== '' ? Number(creditsMax) : '',
      count: count !== '' ? Number(count) : ''
    };
  });
  return reqs;
}

function loadElectiveMatrixForCategory(categoryId) {
  resetElectiveMatrix();
  const reqs = ELECTIVE_SEMESTER_REQUIREMENTS[categoryId];
  if (!reqs) return;
  Object.entries(reqs).forEach(([semester, req]) => {
    normalizeElectiveSemesterReq(req);
    addElectiveMatrixRow({
      semester,
      creditsMin: req.creditsMin,
      creditsMax: req.creditsMax,
      count: req.count
    });
  });
}

function validateElectiveMatrixRequired() {
  const rows = document.querySelectorAll('#elective-matrix-tbody tr[data-row]');
  if (!rows.length) {
    alert('修读类型为选修时，请至少添加一条学期修读要求');
    return false;
  }
  let valid = false;
  for (const row of rows) {
    const semester = row.querySelector('.semester-row-select')?.value;
    const creditsMin = row.querySelector('.matrix-credit-min')?.value.trim();
    const creditsMax = row.querySelector('.matrix-credit-max')?.value.trim();
    const count = row.querySelector('.matrix-count')?.value.trim();
    if (!semester) {
      alert('请为每条学期要求选择对应学期');
      return false;
    }
    if (creditsMin || creditsMax || count) valid = true;
  }
  if (!valid) {
    alert('请至少填写一条学期要求的最低/最高学分或课程数量');
    return false;
  }
  return true;
}

function renderCourseCountCell(node) {
  const count = calcNodeCourseCount(node);
  const aggregated = isAggregatedCreditNode(node);
  const cls = aggregated ? 'credit-auto' : 'credit-value';
  const extra = node.level === 1 ? ' l1' : '';
  return `<td class="count-cell"><span class="${cls}${extra}">${count}</span></td>`;
}

function renderCreditCell(node) {
  const creditsMin = calcNodeCreditsMin(node);
  const creditsMax = calcNodeCreditsMax(node);
  const aggregated = isAggregatedCreditNode(node);
  const cls = aggregated ? 'credit-auto' : 'credit-value';
  const extra = node.level === 1 ? ' l1' : '';
  const title = aggregated && node.level === 1 ? ' title="自动汇总：各二级学分区间之和"' : '';
  const maxDisplay = node.level === 3 ? '—' : creditsMax;
  return `<td class="credit-cell"><span class="${cls}${extra}"${title}>${creditsMin}</span></td>
    <td class="credit-cell"><span class="${cls}${extra}"${title}>${maxDisplay}</span></td>`;
}

function clearCategoryCreditsInputs() {
  const minEl = document.getElementById('category-credits-min');
  const maxEl = document.getElementById('category-credits-max');
  if (minEl) minEl.value = '';
  if (maxEl) maxEl.value = '';
}

function setCategoryCreditsInputs(node) {
  normalizeNodeCredits(node);
  const minEl = document.getElementById('category-credits-min');
  const maxEl = document.getElementById('category-credits-max');
  if (minEl) minEl.value = node?.creditsMin ?? '';
  if (maxEl) {
    maxEl.value = (node?.level === 3 || isCategoryL3Mode()) ? '' : (node?.creditsMax ?? '');
  }
  syncCategoryCreditsMaxFromMin();
}

function readCategoryCreditsFromForm() {
  const minRaw = document.getElementById('category-credits-min')?.value.trim();
  if (isCategoryL3Mode()) {
    if (minRaw === '') return { error: '请填写最低学分' };
    const creditsMin = Number(minRaw);
    if (Number.isNaN(creditsMin) || creditsMin < 0) return { error: '学分须为非负数字' };
    return { creditsMin, creditsMax: null };
  }
  const isRange = isCategoryCreditsRangeMode();
  const maxRaw = isRange
    ? document.getElementById('category-credits-max')?.value.trim()
    : minRaw;
  if (minRaw === '') return { error: '请填写最低学分' };
  if (isRange && maxRaw === '') return { error: '请填写最高学分' };
  const creditsMin = Number(minRaw);
  const creditsMax = Number(maxRaw);
  if (Number.isNaN(creditsMin) || creditsMin < 0 || Number.isNaN(creditsMax) || creditsMax < 0) {
    return { error: '学分须为非负数字' };
  }
  if (creditsMin > creditsMax) {
    return { error: '最低学分不能大于最高学分' };
  }
  return { creditsMin, creditsMax };
}

function renderCategoryActions(node) {
  if (versionEditReadonly) return '<span class="text-muted">—</span>';
  const parts = [];
  if (node.level === 2) {
    parts.push(`<a href="#" onclick="openAddL3CategoryModal('${node.id}');return false">+子级</a>`);
  }
  if (canEditCategory(node)) {
    parts.push(`<a href="#" onclick="openEditCategory('${node.id}');return false">编辑</a>`);
  }
  if (canDeleteCategory(node)) {
    parts.push(`<a href="#" class="danger" onclick="deleteCategory('${node.id}');return false">删除</a>`);
  }
  return parts.length ? parts.join('') : '<span class="text-muted">—</span>';
}

function deleteCategory(id) {
  if (versionEditReadonly) return;
  const node = findClassificationNode(id);
  if (!node || !canDeleteCategory(node)) return;
  pendingDeleteCategoryId = id;

  const msg = document.getElementById('delete-category-msg');
  const hint = document.getElementById('delete-category-hint');
  const levelLabel = node.level === 2 ? '二级' : '三级';
  if (msg) {
    msg.innerHTML = `确定删除<strong>${levelLabel}</strong>分类「<strong>${escapeHtml(node.name)}</strong>」吗？此操作不可撤销。`;
  }
  if (hint) {
    if (node.level === 2 && node.children?.length) {
      hint.textContent = `该分类下含 ${node.children.length} 个三级子分类，将一并删除。`;
    } else if (node.level === 2) {
      const l1 = findL1Ancestor(id);
      hint.textContent = l1?.children?.length === 1
        ? '删除后其所属一级分类也将自动移除。'
        : '';
    } else {
      hint.textContent = '';
    }
  }
  openModal('modal-delete-category');
}

function cancelDeleteCategory() {
  pendingDeleteCategoryId = null;
  closeModal('modal-delete-category');
}

function confirmDeleteCategory() {
  const id = pendingDeleteCategoryId;
  if (!id) return;
  pendingDeleteCategoryId = null;
  closeModal('modal-delete-category');

  for (let i = 0; i < CLASSIFICATION_TREE.length; i++) {
    const l1 = CLASSIFICATION_TREE[i];
    const i2 = l1.children?.findIndex(c => c.id === id) ?? -1;
    if (i2 >= 0) {
      delete ELECTIVE_SEMESTER_REQUIREMENTS[id];
      l1.children.splice(i2, 1);
      if (!l1.children.length) CLASSIFICATION_TREE.splice(i, 1);
      renderClassificationTree();
      return;
    }
    for (const l2 of l1.children || []) {
      const i3 = l2.children?.findIndex(c => c.id === id) ?? -1;
      if (i3 >= 0) {
        l2.children.splice(i3, 1);
        renderClassificationTree();
        return;
      }
    }
  }
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function setCategoryFormReadonly(readonly) {
  ['h1-select', 'h2-select', 'study-type-select'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = readonly;
  });
}

function resetCategoryL2FormDefaults() {
  const h1 = document.getElementById('h1-select');
  const h2 = document.getElementById('h2-select');
  const study = document.getElementById('study-type-select');
  if (h1) h1.value = '';
  if (h2) {
    h2.innerHTML = '<option value="">请选择</option>';
    h2.value = '';
  }
  if (study) study.value = 'compulsory';
}

function openAddCategoryModal() {
  if (versionEditReadonly) return;
  categoryFormMode = 'add-l2';
  parentL2CategoryId = null;
  editingCategoryId = null;
  document.getElementById('modal-category-title').textContent = '新增二级分类';
  setCategoryFormReadonly(false);
  document.getElementById('h1-select').disabled = false;
  document.getElementById('h2-select').disabled = false;
  document.getElementById('category-l3-name').value = '';
  clearCategoryCreditsInputs();
  resetCategoryL2FormDefaults();
  openModal('modal-add-category');
}

function openAddL3CategoryModal(l2Id) {
  if (versionEditReadonly) return;
  const l2 = findClassificationNode(l2Id);
  if (!l2 || l2.level !== 2) return;
  categoryFormMode = 'add-l3';
  parentL2CategoryId = l2Id;
  editingCategoryId = null;
  document.getElementById('modal-category-title').textContent = '新增三级分类';
  document.getElementById('category-l3-parent-display').value = l2.name;
  document.getElementById('category-l3-name').value = '';
  clearCategoryCreditsInputs();
  openModal('modal-add-category');
}

function findL1Ancestor(nodeId) {
  for (const l1 of CLASSIFICATION_TREE) {
    if (l1.id === nodeId) return l1;
    for (const l2 of l1.children || []) {
      if (l2.id === nodeId) return l1;
      if (l2.children?.some(l3 => l3.id === nodeId)) return l1;
    }
  }
  return null;
}

const L1_H1_MAP = {
  'l1-comp': 'compulsory',
  'l1-core': 'core',
  'l1-elec': 'elective'
};

function findL2Parent(nodeId) {
  for (const l1 of CLASSIFICATION_TREE) {
    for (const l2 of l1.children || []) {
      if (l2.id === nodeId) return l2;
      if (l2.children?.some(l3 => l3.id === nodeId)) return l2;
    }
  }
  return null;
}

function populateCategoryFormFromNode(node) {
  const h1 = document.getElementById('h1-select');
  const h2 = document.getElementById('h2-select');
  const l1 = findL1Ancestor(node.id);
  if (h1 && l1 && L1_H1_MAP[l1.id]) h1.value = L1_H1_MAP[l1.id];
  onH1Change();
  const l2 = node.level === 3 ? findL2Parent(node.id) : (node.level === 2 ? node : null);
  if (h2 && l2) {
    const opt = Array.from(h2.options).find(o => o.text === l2.name);
    if (opt) h2.value = opt.value;
    else h2.innerHTML += `<option>${escapeHtml(l2.name)}</option>`;
    h2.value = l2.name;
  }
  if (node.level === 3) {
    document.getElementById('category-l3-parent-display').value = l2?.name || '';
    document.getElementById('category-l3-name').value = node.name;
  }
}

function openEditCategory(id) {
  if (versionEditReadonly) return;
  const node = findClassificationNode(id);
  if (!node || !canEditCategory(node)) return;
  editingCategoryId = id;
  parentL2CategoryId = node.level === 3 ? findL2Parent(node.id)?.id : null;
  categoryFormMode = node.level === 3 ? 'edit-l3' : 'edit-l2';
  document.getElementById('modal-category-title').textContent =
    node.level === 3 ? '编辑三级分类' : '编辑二级分类';
  populateCategoryFormFromNode(node);
  setCategoryFormReadonly(true);
  setCategoryCreditsInputs(node);
  document.getElementById('study-type-select').value = node.studyType || 'compulsory';
  onCategoryLevelChange();
  openModal('modal-add-category');
}

function renderTreeSummaryCreditCell(value, total = false) {
  const cls = total ? 'credit-auto l1 total-value' : 'credit-auto l1';
  return `<td class="credit-cell"><span class="${cls}">${value}</span></td>`;
}

function renderTreeSummaryCountCell(value, total = false) {
  const cls = total ? 'credit-auto l1 total-value' : 'credit-auto l1';
  return `<td class="count-cell"><span class="${cls}">${value}</span></td>`;
}

function renderClassificationTree() {
  syncClassificationStoredCredits();
  const tbody = document.getElementById('classification-tree-body');
  if (!tbody) return;

  let totalCompulsory = 0;
  let totalElective = 0;
  let totalCompulsoryMax = 0;
  let totalElectiveMax = 0;
  let totalCompulsoryCount = 0;
  let totalElectiveCount = 0;
  const rows = [];

  CLASSIFICATION_TREE.forEach(l1 => {
    const l1Min = calcNodeCreditsMin(l1);
    const l1Max = calcNodeCreditsMax(l1);
    const l1Count = calcNodeCourseCount(l1);
    if (l1.studyType === 'compulsory') {
      totalCompulsory += l1Min;
      totalCompulsoryMax += l1Max;
      totalCompulsoryCount += l1Count;
    } else {
      totalElective += l1Min;
      totalElectiveMax += l1Max;
      totalElectiveCount += l1Count;
    }

    rows.push(`<tr class="row-l1${l1.highlight ? ' highlight' : ''}">
      <td><span class="tree-toggle">▼</span> ${l1.name}</td>
      <td>${studyTypeTag(l1.studyType)}</td>
      ${renderCreditCell(l1)}
      ${renderCourseCountCell(l1)}
      <td class="actions">${renderCategoryActions(l1)}</td>
    </tr>`);

    (l1.children || []).forEach(l2 => {
      const hasL3 = !!l2.children?.length;
      rows.push(`<tr class="row-l2${hasL3 ? ' has-l3' : ''}">
        <td class="indent-1">├ ${l2.name}</td>
        <td>${studyTypeTag(l2.studyType)}</td>
        ${renderCreditCell(l2)}
        ${renderCourseCountCell(l2)}
        <td class="actions">${renderCategoryActions(l2)}</td>
      </tr>`);

      (l2.children || []).forEach(l3 => {
        rows.push(`<tr class="row-l3">
          <td class="indent-2">└ ${l3.name}</td>
          <td>${studyTypeTag(l3.studyType)}</td>
          ${renderCreditCell(l3)}
          ${renderCourseCountCell(l3)}
          <td class="actions">${renderCategoryActions(l3)}</td>
        </tr>`);
      });
    });
  });

  const totalMin = totalCompulsory + totalElective;
  const totalMax = totalCompulsoryMax + totalElectiveMax;
  const totalCourseCount = totalCompulsoryCount + totalElectiveCount;

  rows.push(`<tr class="subtotal-row">
    <td colspan="2">必修小计</td>
    ${renderTreeSummaryCreditCell(totalCompulsory)}
    ${renderTreeSummaryCreditCell(totalCompulsoryMax)}
    ${renderTreeSummaryCountCell(totalCompulsoryCount)}
    <td></td>
  </tr>`);
  rows.push(`<tr class="subtotal-row">
    <td colspan="2">选修小计</td>
    ${renderTreeSummaryCreditCell(totalElective)}
    ${renderTreeSummaryCreditCell(totalElectiveMax)}
    ${renderTreeSummaryCountCell(totalElectiveCount)}
    <td></td>
  </tr>`);
  rows.push(`<tr class="total-row">
    <td colspan="2"><strong>学分总计</strong> <span class="form-hint" style="font-weight:400">（必修 + 选修）</span></td>
    ${renderTreeSummaryCreditCell(totalMin, true)}
    ${renderTreeSummaryCreditCell(totalMax, true)}
    ${renderTreeSummaryCountCell(totalCourseCount, true)}
    <td></td>
  </tr>`);

  tbody.innerHTML = rows.join('');

  const sc = document.getElementById('sum-compulsory');
  const se = document.getElementById('sum-elective');
  const st = document.getElementById('sum-total');
  if (sc) sc.textContent = totalCompulsory;
  if (se) se.textContent = totalElective;
  if (st) st.textContent = totalMin;
  renderSemesterMatrixTable();
  refreshProgrammeStructureIfVisible();
  updateVersionEditTabStates();
}

function onCategoryLevelChange() {
  const hint = document.getElementById('category-credits-hint');
  const wrap = document.getElementById('category-credits-wrap');
  const isRange = isCategoryCreditsRangeMode();
  if (!hint) return;
  if (categoryFormMode === 'add-l3' || categoryFormMode === 'edit-l3') {
    hint.textContent = categoryFormMode === 'edit-l3'
      ? '可修改三级分类名称与最低学分（不设最高学分限制）'
      : '请填写该三级分类的最低学分（不设最高学分限制）';
    if (wrap) wrap.style.display = '';
    return;
  }
  if (editingCategoryId) {
    hint.textContent = isRange
      ? '通过本弹窗修改最低/最高学分；分类名称与层级不可变更'
      : '通过本弹窗修改最低学分；最高学分自动等于最低学分，不可单独修改';
    if (wrap) wrap.style.display = '';
    return;
  }
  hint.textContent = isRange
    ? '二级分类：请填写最低/最高学分；有三级子分类时，二级与三级学分要求分别维护，互不自动汇总'
    : '二级分类：请填写最低学分，最高学分自动同步；有三级子分类时，二级与三级学分要求分别维护';
}

function isElectiveStudyType() {
  return document.getElementById('study-type-select')?.value === 'elective';
}

function onStudyTypeChange() {
  applyCategoryFormMode();
  onCategoryLevelChange();
}

function saveCategory() {
  const creditsResult = readCategoryCreditsFromForm();
  if (creditsResult.error) {
    alert(creditsResult.error);
    return;
  }
  const { creditsMin, creditsMax } = creditsResult;

  if (categoryFormMode === 'edit-l3' || categoryFormMode === 'edit-l2') {
    const node = findClassificationNode(editingCategoryId);
    if (!node) return;
    if (categoryFormMode === 'edit-l2' && node.studyType === 'elective' && !validateElectiveMatrixRequired()) return;
    node.creditsMin = creditsMin;
    if (categoryFormMode === 'edit-l3') {
      const name = document.getElementById('category-l3-name')?.value.trim();
      if (!name) {
        alert('请填写三级分类名称');
        return;
      }
      const l2 = findL2Parent(node.id);
      if (l2 && (l2.children || []).some(c => c.id !== node.id && c.name === name)) {
        alert('该二级分类下已存在同名三级分类');
        return;
      }
      node.name = name;
      delete node.creditsMax;
    } else {
      node.creditsMax = creditsMax;
    }
    delete node.credits;
    if (categoryFormMode === 'edit-l2') {
      node.studyType = document.getElementById('study-type-select').value;
      if (node.studyType === 'elective') {
        ELECTIVE_SEMESTER_REQUIREMENTS[node.id] = collectElectiveMatrixRequirements();
      } else {
        delete ELECTIVE_SEMESTER_REQUIREMENTS[node.id];
      }
    }
    editingCategoryId = null;
    parentL2CategoryId = null;
    categoryFormMode = 'add-l2';
    setCategoryFormReadonly(false);
    closeModal('modal-add-category');
    renderClassificationTree();
    alert('分类已更新（原型）');
    return;
  }

  if (categoryFormMode === 'add-l3') {
    const name = document.getElementById('category-l3-name')?.value.trim();
    if (!name) {
      alert('请填写三级分类名称');
      return;
    }
    const l2 = findClassificationNode(parentL2CategoryId);
    if (!l2 || l2.level !== 2) return;
    if ((l2.children || []).some(c => c.name === name)) {
      alert('该二级分类下已存在同名三级分类');
      return;
    }
    if (!l2.children) l2.children = [];
    l2.children.push({
      id: generateCategoryNodeId(3),
      level: 3,
      name,
      studyType: l2.studyType,
      creditsMin,
      courseCount: 0
    });
    delete l2.courseCount;
    parentL2CategoryId = null;
    categoryFormMode = 'add-l2';
    closeModal('modal-add-category');
    renderClassificationTree();
    alert('三级分类已添加（原型）');
    return;
  }

  const h1Key = document.getElementById('h1-select')?.value;
  const h2Name = document.getElementById('h2-select')?.value;
  const studyType = document.getElementById('study-type-select')?.value || 'compulsory';
  if (!h1Key) {
    alert('请选择一级分类');
    return;
  }
  if (!h2Name) {
    alert('请选择二级分类');
    return;
  }
  if (studyType === 'elective' && !validateElectiveMatrixRequired()) return;

  const l1 = findOrCreateL1(h1Key);
  if (!l1) return;
  if ((l1.children || []).some(c => c.name === h2Name)) {
    alert('该一级分类下已存在同名二级分类');
    return;
  }
  const l2Id = generateCategoryNodeId(2);
  const l2 = {
    id: l2Id,
    level: 2,
    name: h2Name,
    studyType,
    creditsMin,
    creditsMax,
    courseCount: 0
  };
  if (!l1.children) l1.children = [];
  l1.children.push(l2);
  if (studyType === 'elective') {
    ELECTIVE_SEMESTER_REQUIREMENTS[l2Id] = collectElectiveMatrixRequirements();
  }

  categoryFormMode = 'add-l2';
  closeModal('modal-add-category');
  renderClassificationTree();
  alert('二级分类已添加（原型）');
}

// ── Programme Structure (Table 3a) ──
const PROGRAMME_STRUCTURE = {
  institution: 'Xiamen University Malaysia',
  programme: 'Bachelor of Science in Physics (Honours)',
  totalCredits: 145,
  years: [
    {
      year: 1,
      semesters: [
        {
          label: 'Semester 1', weeks: 18,
          courses: [
            { name: 'Mechanics', code: 'PHY101', cls: 'Major Core', credit: 4 },
            { name: 'Calculus I A', code: 'BSC124', cls: 'Common Core', credit: 4 },
            { name: 'Introduction to Physics Lab', code: 'PHY102', cls: 'Major Core', credit: 2 },
            { name: 'English for Academic Writing', code: 'ENG101', cls: 'Compulsory', credit: 3 },
            { name: 'Malaysian Studies 3', code: 'MPU3123', cls: 'Compulsory', credit: 3 },
            { name: 'Physics Lab I', code: 'PHY103', cls: 'Major Core', credit: 2 },
            { name: 'Linear Algebra', code: 'BSC125', cls: 'Common Core', credit: 2 }
          ]
        },
        {
          label: 'Semester 2', weeks: 18,
          courses: [
            { name: 'Electricity and Magnetism', code: 'PHY104', cls: 'Major Core', credit: 4 },
            { name: 'Calculus I B', code: 'BSC126', cls: 'Common Core', credit: 4 },
            { name: 'Waves and Optics', code: 'PHY105', cls: 'Major Core', credit: 4 },
            { name: 'Introduction to Programming', code: 'BSC127', cls: 'Common Core', credit: 3 },
            { name: 'Ethnic Relations', code: 'MPU3113', cls: 'Compulsory', credit: 3 },
            { name: 'Physics Lab II', code: 'PHY106', cls: 'Major Core', credit: 1 }
          ]
        },
        {
          label: 'Semester 3', weeks: 6,
          courses: [
            { name: 'Community Service', code: 'MPU3412', cls: 'Compulsory', credit: 2 },
            { name: 'Physics Summer Workshop', code: 'PHY107', cls: 'Major Core', credit: 3 }
          ]
        }
      ]
    },
    {
      year: 2,
      semesters: [
        {
          label: 'Semester 1', weeks: 18,
          courses: [
            { name: 'Quantum Mechanics I', code: 'PHY201', cls: 'Major Core', credit: 4 },
            { name: 'Mathematical Methods for Physics', code: 'PHY202', cls: 'Major Core', credit: 4 },
            { name: 'Thermodynamics', code: 'PHY203', cls: 'Major Core', credit: 4 },
            { name: 'Electronics', code: 'PHY204', cls: 'Major Core', credit: 3 },
            { name: 'Computational Physics', code: 'PHY205', cls: 'Major Core', credit: 3 },
            { name: 'Physics Lab III', code: 'PHY206', cls: 'Major Core', credit: 2 }
          ]
        },
        {
          label: 'Semester 2', weeks: 18,
          courses: [
            { name: 'Quantum Mechanics II', code: 'PHY207', cls: 'Major Core', credit: 4 },
            { name: 'Statistical Mechanics', code: 'PHY208', cls: 'Major Core', credit: 4 },
            { name: 'Electromagnetic Theory', code: 'PHY209', cls: 'Major Core', credit: 4 },
            { name: 'Solid State Physics I', code: 'PHY210', cls: 'Major Core', credit: 3 },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 3, elective: true }
          ]
        },
        {
          label: 'Semester 3', weeks: 6,
          courses: [
            { name: 'Research Methods in Physics', code: 'PHY211', cls: 'Major Core', credit: 3 },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 2, elective: true }
          ]
        }
      ]
    },
    {
      year: 3,
      semesters: [
        {
          label: 'Semester 1', weeks: 18,
          courses: [
            { name: 'Solid State Physics II', code: 'PHY301', cls: 'Major Core', credit: 4 },
            { name: 'Nuclear and Particle Physics', code: 'PHY302', cls: 'Major Core', credit: 4 },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 3, elective: true }
          ]
        },
        {
          label: 'Semester 2', weeks: 18,
          courses: [
            { name: 'Industrial Training / Undergraduate Research II / Capstone Project', code: 'PHY303', cls: 'Industrial Training / Major Elective', credit: 6 },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 3, elective: true }
          ]
        },
        {
          label: 'Semester 3', weeks: 6,
          courses: [
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 3, elective: true }
          ]
        }
      ]
    },
    {
      year: 4,
      semesters: [
        {
          label: 'Semester 1', weeks: 18,
          courses: [
            { name: 'Final Year Project I', code: 'PHY401', cls: 'Major Core', credit: 4 },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 3, elective: true }
          ]
        },
        {
          label: 'Semester 2', weeks: 18,
          courses: [
            { name: 'Final Year Project II', code: 'PHY402', cls: 'Major Core', credit: 6 },
            { name: 'Select from Table 2f Group 1, 2, or 3', code: '—', cls: 'Major Elective', credit: 4, elective: true },
            { name: 'Select from Table 2b', code: 'GXXXX', cls: 'General Elective', credit: 3, elective: true }
          ]
        },
        {
          label: 'Semester 3', weeks: 6,
          courses: []
        }
      ]
    }
  ]
};

function sumCredits(courses) {
  return courses.reduce((s, c) => s + (c.credit || 0), 0);
}

function getProgrammeStructureCourseCodeDisplay(code, { isPool = false } = {}) {
  if (isPool) return '';
  const value = String(code || '').trim();
  if (!value || value === '—' || value === '-' || value.toUpperCase() === 'GXXXX') return '';
  return escapeHtml(value);
}

function renderSemesterTable(sem, year, semIndex) {
  const code = semesterCode(year, semIndex);
  const total = sumCredits(sem.courses);
  const rows = sem.courses.length
    ? sem.courses.map(c => `
        <tr class="${c.elective ? 'elective-row' : ''}">
          <td>${c.name}</td>
          <td>${getProgrammeStructureCourseCodeDisplay(c.code, { isPool: c.isPool })}</td>
          <td class="ps-classification">${c.cls}</td>
          <td>${c.credit}</td>
        </tr>`).join('')
    : `<tr><td colspan="4" style="text-align:center;color:#999;padding:12px">—</td></tr>`;

  const weeks = sem.weeks || SEMESTER_WEEKS[semIndex] || 18;

  return `
    <div class="ps-semester">
      <div class="ps-sem-header">${code}<br><small>Sem ${semIndex} · ${weeks} weeks</small></div>
      <table class="ps-course-table">
        <colgroup>
          <col class="col-name">
          <col class="col-code">
          <col class="col-cls">
          <col class="col-credit">
        </colgroup>
        <thead>
          <tr>
            <th>Name of Course</th>
            <th>Course Code</th>
            <th>Classification</th>
            <th>Credit Value</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
        <tfoot>
          <tr>
            <td colspan="3">TOTAL CREDIT VALUE</td>
            <td>${total || '—'}</td>
          </tr>
        </tfoot>
      </table>
    </div>`;
}

function renderProgrammeStructure(containerId, data) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const d = data || buildProgrammeStructureFromCourses();
  const hasCourses = d.years.some(y => y.semesters.some(s => s.courses.length));

  if (!hasCourses) {
    el.innerHTML = `
      <div class="programme-structure">
        <div class="ps-meta">
          <div class="ps-meta-item"><label>Institution</label><span>${escapeHtml(d.institution)}</span></div>
          <div class="ps-meta-item"><label>Programme</label><span>${escapeHtml(d.programme)}</span></div>
          <div class="ps-meta-item"><label>Total Credit Value</label><span>—</span></div>
        </div>
        <h2 class="ps-title">Programme Structure</h2>
        <p class="ps-empty-hint">暂无已指定开课学期的课程。请在 TAB2 课程设置中为课程开启「指定学期」并保存，相关课程将按学期逐门展示于此。</p>
      </div>`;
    return;
  }

  const yearsHtml = d.years.map(y => `
    <div class="ps-year-block">
      <div class="ps-year-label">Year ${y.year}</div>
      <div class="ps-semesters">
        ${y.semesters.map((sem, idx) => renderSemesterTable(sem, y.year, idx + 1)).join('')}
      </div>
    </div>`).join('');

  el.innerHTML = `
    <div class="programme-structure">
      <div class="ps-meta">
        <div class="ps-meta-item"><label>Institution</label><span>${d.institution}</span></div>
        <div class="ps-meta-item"><label>Programme</label><span>${d.programme}</span></div>
        <div class="ps-meta-item"><label>Total Credit Value</label><span>${d.totalCredits}</span></div>
      </div>
      <h2 class="ps-title">Programme Structure</h2>
      ${yearsHtml}
    </div>`;
}

// ── Init ──
syncAllVersionEndBatches();
bindCategoryCreditsInputs();
onH1Change();
onStudyTypeChange();
onCategoryLevelChange();
resetElectiveMatrix();
initSemesterSelects();
renderClassificationTree();
renderProgramCoursesTable();
filterVersions();
renderExecList();
renderApprovalList();
renderChangeReviewList();
initExecMajorSelect();
rebuildExecIntakeBatchSelect('finance');
onExecBatchInput();
renderProgrammeStructure('programme-structure-root');

// ── Data Statistics (Alignment / Bloom's Taxonomy Charts) ──
const STATS_PLO_HEADERS = [
  { code: 'PLO1', desc: 'Knowledge and Understanding' },
  { code: 'PLO2', desc: 'Cognitive Skills' },
  { code: 'PLO3', desc: 'Practical Skills' },
  { code: 'PLO4', desc: 'Interpersonal Skills' },
  { code: 'PLO5', desc: 'Communication Skills' },
  { code: 'PLO6', desc: 'Ethics and Professionalism' },
  { code: 'PLO7', desc: 'Personal Skills' },
  { code: 'PLO8', desc: 'Leadership Skills' },
  { code: 'PLO9', desc: 'Entrepreneurial skills' },
  { code: 'PLO10', desc: 'Digital Literacy' },
  { code: 'PLO11', desc: 'Teamwork skills' }
];

const STATS_TREE = [
  {
    id: 'school-comm',
    label: 'School of Communication',
    children: [
      {
        id: 'ibu',
        label: 'IBU',
        children: [
          {
            id: 'ibu-2025',
            label: '2025',
            children: INTAKE_BATCH_TYPES.map(type => ({
              id: `ibu-2025${type}`,
              batchCode: formatIntakeBatch(2025, type),
              leaf: true,
              programme: 'Bachelor of Communication (Honours)',
            }))
          },
          {
            id: 'ibu-2024',
            label: '2024',
            children: INTAKE_BATCH_TYPES.map(type => ({
              id: `ibu-2024${type}`,
              batchCode: formatIntakeBatch(2024, type),
              leaf: true,
              programme: 'Bachelor of Communication (Honours)',
            }))
          }
        ]
      }
    ]
  },
  {
    id: 'school-arts',
    label: 'School of Arts',
    children: [
      {
        id: 'mct',
        label: 'MCT',
        children: [
          {
            id: 'mct-2025',
            label: '2025',
            children: INTAKE_BATCH_TYPES.map(type => ({
              id: `mct-2025${type}`,
              batchCode: formatIntakeBatch(2025, type),
              leaf: true,
              programme: 'Bachelor of Media Arts (Honours)',
            }))
          }
        ]
      },
      {
        id: 'phy',
        label: 'Physics (Honours)',
        children: [
          {
            id: 'phy-2025',
            label: '2025',
            children: INTAKE_BATCH_TYPES.map(type => ({
              id: `phy-2025${type}`,
              batchCode: formatIntakeBatch(2025, type),
              leaf: true,
              programme: 'Bachelor of Science in Physics (Honours)',
            }))
          },
          {
            id: 'phy-2024',
            label: '2024',
            children: INTAKE_BATCH_TYPES.map(type => ({
              id: `phy-2024${type}`,
              batchCode: formatIntakeBatch(2024, type),
              leaf: true,
              programme: 'Bachelor of Science in Physics (Honours)',
            }))
          }
        ]
      }
    ]
  }
];

const STATS_DATA = {
  'phy-202502': {
    alignment: {
      contribution: [35, 59, 10, 9, 9, 12, 12, 8, 13, 12, 8],
      domains: ['C', 'C', 'P', 'A', 'A', 'P', 'C', 'P', 'A', 'A', 'A']
    },
    bloom: {
      matrix: {
        cognitive: [4, 31, 37, 58, 41, 37, null, 228],
        affective: [25, 36, 0, 29, 39, null, null, 119],
        psychomotor: [12, 24, 23, 32, 50, 20, 17, 228]
      },
      summary: {
        cognitive: [4, 31, 37, 58, 41, 37],
        affective: [25, 36, 0, 29, 39],
        psychomotor: [12, 24, 23, 32, 50, 20, 17]
      },
      byYear: [
        { year: 1, cognitive: 25, affective: 17, psychomotor: 17, cLevels: [4, 8, 5, 4, 2, 2], aLevels: [5, 4, 3, 2, 3], pLevels: [2, 3, 4, 3, 2, 2, 1] },
        { year: 2, cognitive: 33, affective: 22, psychomotor: 31, cLevels: [5, 10, 6, 5, 4, 3], aLevels: [6, 5, 4, 3, 4], pLevels: [3, 4, 5, 4, 5, 5, 5] },
        { year: 3, cognitive: 41, affective: 28, psychomotor: 38, cLevels: [6, 12, 8, 6, 5, 4], aLevels: [7, 6, 5, 4, 6], pLevels: [4, 5, 6, 5, 6, 6, 6] },
        { year: 4, cognitive: 48, affective: 32, psychomotor: 45, cLevels: [7, 14, 9, 8, 6, 4], aLevels: [8, 7, 6, 5, 6], pLevels: [5, 6, 7, 6, 7, 7, 7] },
        { year: 5, cognitive: 52, affective: 35, psychomotor: 48, cLevels: [8, 15, 10, 9, 6, 4], aLevels: [9, 8, 6, 6, 6], pLevels: [5, 6, 7, 7, 8, 7, 8] }
      ]
    }
  },
  'phy-202402': {
    alignment: {
      contribution: [32, 54, 12, 8, 10, 11, 10, 9, 11, 10, 9],
      domains: ['C', 'C', 'P', 'A', 'A', 'P', 'C', 'P', 'A', 'A', 'C']
    },
    bloom: {
      matrix: {
        cognitive: [3, 28, 35, 55, 38, 35, null, 214],
        affective: [22, 34, 0, 27, 36, null, null, 112],
        psychomotor: [10, 22, 21, 30, 48, 18, 16, 215]
      },
      summary: {
        cognitive: [3, 28, 35, 55, 38, 35],
        affective: [22, 34, 0, 27, 36],
        psychomotor: [10, 22, 21, 30, 48, 18, 16]
      },
      byYear: [
        { year: 1, cognitive: 22, affective: 15, psychomotor: 15, cLevels: [3, 7, 4, 3, 2, 3], aLevels: [4, 3, 3, 2, 3], pLevels: [2, 2, 3, 2, 2, 2, 2] },
        { year: 2, cognitive: 30, affective: 20, psychomotor: 28, cLevels: [4, 9, 5, 4, 4, 4], aLevels: [5, 4, 4, 3, 4], pLevels: [3, 3, 4, 4, 4, 5, 5] },
        { year: 3, cognitive: 38, affective: 26, psychomotor: 35, cLevels: [5, 11, 7, 5, 5, 5], aLevels: [6, 5, 5, 4, 6], pLevels: [4, 4, 5, 5, 5, 6, 6] },
        { year: 4, cognitive: 45, affective: 30, psychomotor: 42, cLevels: [6, 13, 8, 7, 6, 5], aLevels: [7, 6, 5, 5, 7], pLevels: [4, 5, 6, 6, 7, 7, 7] },
        { year: 5, cognitive: 49, affective: 33, psychomotor: 45, cLevels: [7, 14, 9, 8, 6, 5], aLevels: [8, 7, 6, 5, 7], pLevels: [5, 6, 6, 7, 8, 7, 6] }
      ]
    }
  }
};

let statsSelectedLeafId = 'phy-202502';
let statsTreeFilter = { alignment: '', bloom: '' };
let statsTreeExpanded = new Set(['school-comm', 'school-arts', 'phy', 'phy-2025']);

function findStatsLeafNode(id, nodes = STATS_TREE) {
  for (const node of nodes) {
    if (node.id === id && node.leaf) return node;
    if (node.children) {
      const found = findStatsLeafNode(id, node.children);
      if (found) return found;
    }
  }
  return null;
}

function getStatsDataset(leafId) {
  return STATS_DATA[leafId] || STATS_DATA['phy-202502'];
}

function getStatsNodeLabel(node) {
  if (node.batchCode) return formatBatchDisplay(node.batchCode);
  return node.label || '';
}

function getStatsContextHtml(leafId) {
  const leaf = findStatsLeafNode(leafId) || findStatsLeafNode('phy-202502');
  if (!leaf) return '';
  const batch = formatBatchDisplay(leaf.batchCode);
  return `<strong>Programme:</strong> ${escapeHtml(leaf.programme)} &nbsp;&nbsp; <strong>Intake:</strong> ${escapeHtml(batch)}`;
}

function renderStatsTree(mode) {
  const container = document.getElementById(`stats-tree-${mode}`);
  if (!container) return;
  const filter = (statsTreeFilter[mode] || '').trim().toLowerCase();

  function nodeMatches(node) {
    if (!filter) return true;
    const label = getStatsNodeLabel(node).toLowerCase();
    if (label.includes(filter)) return true;
    if (node.label?.toLowerCase().includes(filter)) return true;
    if (node.programme?.toLowerCase().includes(filter)) return true;
    return node.children?.some(nodeMatches);
  }

  function renderNode(node, depth = 0) {
    if (!nodeMatches(node)) return '';
    const hasChildren = node.children?.length;
    const expanded = statsTreeExpanded.has(node.id);
    const isLeaf = !!node.leaf;
    const active = isLeaf && node.id === statsSelectedLeafId;
    const toggle = hasChildren
      ? `<span class="tree-toggle">${expanded ? '▾' : '▸'}</span>`
      : '<span class="tree-toggle empty">·</span>';
    let html = `
      <div class="stats-tree-node${active ? ' active' : ''}${hasChildren && !expanded ? ' collapsed' : ''}"
           data-node-id="${node.id}"
           onclick="onStatsTreeNodeClick('${node.id}', ${hasChildren ? 'true' : 'false'}, ${isLeaf ? 'true' : 'false'}, '${mode}')">
        ${toggle}<span>${escapeHtml(getStatsNodeLabel(node))}</span>
      </div>`;
    if (hasChildren && expanded) {
      html += `<div class="stats-tree-children">${node.children.map(child => renderNode(child, depth + 1)).join('')}</div>`;
    }
    return html;
  }

  container.innerHTML = STATS_TREE.map(node => `<div class="stats-tree-group">${renderNode(node)}</div>`).join('');
}

function onStatsTreeNodeClick(nodeId, hasChildren, isLeaf, mode) {
  if (isLeaf) {
    statsSelectedLeafId = nodeId;
    renderStatsTree('alignment');
    renderStatsTree('bloom');
    if (mode === 'alignment') renderStatsAlignmentPage(false);
    else renderStatsBloomPage(false);
    return;
  }
  if (hasChildren) {
    if (statsTreeExpanded.has(nodeId)) statsTreeExpanded.delete(nodeId);
    else statsTreeExpanded.add(nodeId);
    renderStatsTree(mode);
  }
}

function filterStatsTree(mode) {
  const input = document.getElementById(`stats-tree-search-${mode}`);
  statsTreeFilter[mode] = input?.value || '';
  renderStatsTree(mode);
}

function exportStatsPage(mode) {
  alert(`Export ${mode === 'alignment' ? 'Alignment Charts' : "Bloom's Taxonomy Charts"}（原型）`);
}

function renderStatsLineChart(values, { width = 720, height = 220, yMax = 70, xLabels = null } = {}) {
  const pad = { top: 24, right: 16, bottom: 28, left: 36 };
  const innerW = width - pad.left - pad.right;
  const innerH = height - pad.top - pad.bottom;
  const max = yMax || Math.max(...values, 1);
  const step = values.length > 1 ? innerW / (values.length - 1) : innerW;
  const points = values.map((v, i) => {
    const x = pad.left + i * step;
    const y = pad.top + innerH - (v / max) * innerH;
    return { x, y, v, label: xLabels ? xLabels[i] : String(i + 1) };
  });
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const gridLines = [0, 10, 20, 30, 40, 50, 60, 70].filter(v => v <= max).map(v => {
    const y = pad.top + innerH - (v / max) * innerH;
    return `<line x1="${pad.left}" y1="${y}" x2="${width - pad.right}" y2="${y}" class="stats-chart-grid"/>`;
  }).join('');
  const dots = points.map(p =>
    `<circle cx="${p.x}" cy="${p.y}" r="3.5" class="stats-chart-dot"/>
     <text x="${p.x}" y="${p.y - 8}" text-anchor="middle" class="stats-chart-value">${p.v}</text>
     <text x="${p.x}" y="${height - 8}" text-anchor="middle" class="stats-chart-label">${escapeHtml(p.label)}</text>`
  ).join('');
  return `<svg viewBox="0 0 ${width} ${height}" class="stats-chart-svg" preserveAspectRatio="xMidYMid meet">
    ${gridLines}
    <path d="${path}" class="stats-chart-line"/>
    ${dots}
  </svg>`;
}

function renderAlignmentContent(leafId) {
  const data = getStatsDataset(leafId).alignment;
  const ploHeads = STATS_PLO_HEADERS.map(h =>
    `<th class="plo-head"><div class="plo-desc">${escapeHtml(h.desc)}</div><div>${h.code}</div></th>`
  ).join('');
  const contributionCells = data.contribution.map(v => `<td>${v}</td>`).join('');
  const domainCells = data.domains.map(v => `<td class="domain-cell">${v}</td>`).join('');

  return `
    <div class="stats-section">
      <div class="alignment-wrap">
        <table class="alignment-table">
          <thead>
            <tr><th class="row-label"></th>${ploHeads}</tr>
          </thead>
          <tbody>
            <tr>
              <td class="row-label">Contribution of CLO to PLO</td>
              ${contributionCells}
            </tr>
            <tr>
              <td class="row-label">Bloom's Taxonomy Domain</td>
              ${domainCells}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="stats-section">
      <div class="stats-chart-card">
        <div class="stats-chart-title">Contribution of CLO to PLO</div>
        ${renderStatsLineChart(data.contribution, { yMax: 70 })}
      </div>
    </div>`;
}

function renderBloomMatrixCell(value) {
  if (value == null) return '<td class="cell-na"></td>';
  return `<td>${value}</td>`;
}

function renderBloomMatrixTable(matrix) {
  const rows = [
    { key: 'cognitive', label: 'Cognitive (C)' },
    { key: 'affective', label: 'Affective (A)' },
    { key: 'psychomotor', label: 'Psychomotor (P)' }
  ];
  const body = rows.map(row => {
    const vals = matrix[row.key];
    return `<tr>
      <td class="matrix-row-label">${row.label}</td>
      ${vals.slice(0, 7).map(renderBloomMatrixCell).join('')}
      <td class="total-col">${vals[7] ?? '—'}</td>
    </tr>`;
  }).join('');

  return `
    <div class="bloom-matrix-wrap">
      <table class="bloom-matrix">
        <thead>
          <tr>
            <th rowspan="2"></th>
            <th colspan="2" class="order-lower">Lower Order</th>
            <th colspan="2" class="order-inter">Intermediate Order</th>
            <th colspan="3" class="order-higher">Higher Order</th>
            <th rowspan="2">Total</th>
          </tr>
          <tr>
            <th class="order-lower">1</th><th class="order-lower">2</th>
            <th class="order-inter">3</th><th class="order-inter">4</th>
            <th class="order-higher">5</th><th class="order-higher">6</th><th class="order-higher">7</th>
          </tr>
        </thead>
        <tbody>${body}</tbody>
      </table>
    </div>`;
}

function renderYearSummaryPair(rows, levelKeys, levelPrefix) {
  const totals = rows.reduce((acc, r) => {
    acc.cognitive += r.cognitive;
    acc.affective += r.affective;
    acc.psychomotor += r.psychomotor;
    levelKeys.forEach((k, i) => { acc.levels[i] += r[k] || 0; });
    return acc;
  }, { cognitive: 0, affective: 0, psychomotor: 0, levels: levelKeys.map(() => 0) });
  const grand = totals.cognitive + totals.affective + totals.psychomotor;
  const pct = n => grand ? `${Math.round(n / grand * 100)}%` : '0%';

  const countHead = levelKeys.length
    ? `<th>Year</th>${levelKeys.map((_, i) => `<th>${levelPrefix}${i + 1}</th>`).join('')}<th>Total</th>`
    : `<th>Year</th><th>Cognitive</th><th>Affective</th><th>Psychomotor</th><th>Total</th>`;

  const countRows = rows.map(r => {
    const rowTotal = levelKeys.length
      ? levelKeys.reduce((s, k) => s + (r[k] || 0), 0)
      : r.cognitive + r.affective + r.psychomotor;
    const cells = levelKeys.length
      ? levelKeys.map(k => `<td>${r[k] ?? 0}</td>`).join('')
      : `<td>${r.cognitive}</td><td>${r.affective}</td><td>${r.psychomotor}</td>`;
    return `<tr><td class="year-col">${r.year}</td>${cells}<td>${rowTotal}</td></tr>`;
  }).join('');

  const countFoot = levelKeys.length
    ? `<tr><td class="year-col">Total</td>${totals.levels.map(v => `<td>${v}</td>`).join('')}<td>${totals.levels.reduce((a, b) => a + b, 0)}</td></tr>`
    : `<tr><td class="year-col">Total</td><td>${totals.cognitive}</td><td>${totals.affective}</td><td>${totals.psychomotor}</td><td>${grand}</td></tr>`;

  const pctRows = rows.map(r => {
    const rowTotal = levelKeys.length
      ? levelKeys.reduce((s, k) => s + (r[k] || 0), 0)
      : r.cognitive + r.affective + r.psychomotor;
    const cells = levelKeys.length
      ? levelKeys.map(k => `<td>${pct(r[k] || 0)}</td>`).join('')
      : `<td>${pct(r.cognitive)}</td><td>${pct(r.affective)}</td><td>${pct(r.psychomotor)}</td>`;
    return `<tr><td class="year-col">${r.year}</td>${cells}<td>${pct(rowTotal)}</td></tr>`;
  }).join('');

  const pctFoot = levelKeys.length
    ? `<tr><td class="year-col">Total</td>${totals.levels.map(v => `<td>${pct(v)}</td>`).join('')}<td>100%</td></tr>`
    : `<tr><td class="year-col">Total</td><td>${pct(totals.cognitive)}</td><td>${pct(totals.affective)}</td><td>${pct(totals.psychomotor)}</td><td>100%</td></tr>`;

  return `
    <table class="stats-year-table">
      <thead><tr>${countHead}</tr></thead>
      <tbody>${countRows}</tbody>
      <tfoot>${countFoot}</tfoot>
    </table>
    <table class="stats-year-table">
      <thead><tr>${countHead}</tr></thead>
      <tbody>${pctRows}</tbody>
      <tfoot>${pctFoot}</tfoot>
    </table>`;
}

function renderBloomContent(leafId) {
  const bloom = getStatsDataset(leafId).bloom;
  const rows = bloom.byYear.map(r => ({
    year: r.year,
    cognitive: r.cognitive,
    affective: r.affective,
    psychomotor: r.psychomotor,
    cLevels: r.cLevels,
    aLevels: r.aLevels,
    pLevels: r.pLevels
  }));

  const summaryCharts = [
    { title: 'Cognitive', values: bloom.summary.cognitive },
    { title: 'Affective', values: bloom.summary.affective },
    { title: 'Psychomotor', values: bloom.summary.psychomotor }
  ].map(item => `
    <div class="stats-chart-card stats-mini-chart">
      <div class="stats-chart-title">${item.title}</div>
      ${renderStatsLineChart(item.values, { width: 360, height: 180, yMax: Math.max(...item.values, 10) + 10 })}
    </div>`).join('');

  const cognitiveRows = rows.map(r => {
    const o = { year: r.year };
    r.cLevels.forEach((v, i) => { o[`c${i + 1}`] = v; });
    return o;
  });
  const affectiveRows = rows.map(r => {
    const o = { year: r.year };
    r.aLevels.forEach((v, i) => { o[`a${i + 1}`] = v; });
    return o;
  });
  const psychomotorRows = rows.map(r => {
    const o = { year: r.year };
    r.pLevels.forEach((v, i) => { o[`p${i + 1}`] = v; });
    return o;
  });

  return `
    <div class="stats-section">${renderBloomMatrixTable(bloom.matrix)}</div>
    <div class="stats-section">
      <div class="stats-section-head"><span class="stats-section-icon">▦</span> Summary</div>
      <div class="stats-chart-row">${summaryCharts}</div>
    </div>
    <div class="stats-section">
      <div class="stats-section-head"><span class="stats-section-icon">▦</span> Summary by Year</div>
      <div class="stats-table-pair">${renderYearSummaryPair(rows, [], '')}</div>
    </div>
    <div class="stats-section">
      <div class="stats-section-head"><span class="stats-section-icon">▦</span> Summary by Year [COGNITIVE]</div>
      <div class="stats-table-pair">${renderYearSummaryPair(cognitiveRows, ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'], 'C')}</div>
    </div>
    <div class="stats-section">
      <div class="stats-section-head"><span class="stats-section-icon">▦</span> Summary by Year [AFFECTIVE]</div>
      <div class="stats-table-pair">${renderYearSummaryPair(affectiveRows, ['a1', 'a2', 'a3', 'a4', 'a5'], 'A')}</div>
    </div>
    <div class="stats-section">
      <div class="stats-section-head"><span class="stats-section-icon">▦</span> Summary by Year [PSYCHOMOTOR]</div>
      <div class="stats-table-pair">${renderYearSummaryPair(psychomotorRows, ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7'], 'P')}</div>
    </div>`;
}

function renderStatsAlignmentPage(renderTree = true) {
  if (renderTree) renderStatsTree('alignment');
  const ctx = document.getElementById('stats-alignment-context');
  const content = document.getElementById('stats-alignment-content');
  if (ctx) ctx.innerHTML = getStatsContextHtml(statsSelectedLeafId);
  if (content) content.innerHTML = renderAlignmentContent(statsSelectedLeafId);
}

function renderStatsBloomPage(renderTree = true) {
  if (renderTree) renderStatsTree('bloom');
  const ctx = document.getElementById('stats-bloom-context');
  const content = document.getElementById('stats-bloom-content');
  if (ctx) ctx.innerHTML = getStatsContextHtml(statsSelectedLeafId);
  if (content) content.innerHTML = renderBloomContent(statsSelectedLeafId);
}

const queryMajor = document.getElementById('query-major');
if (queryMajor) {
  Object.entries(MAJORS).forEach(([key, m]) => {
    queryMajor.innerHTML += `<option value="${key}">${m.name} ${m.nameZh}</option>`;
  });
}
